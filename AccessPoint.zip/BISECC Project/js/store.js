// Account, access preferences, and everything users contribute.
//
// In this prototype all contributions live in localStorage on the one device —
// there is no server, so nothing is shared between people yet. The shape below
// is what a real backend would store, so swapping localStorage for an API is a
// change to this file only.

import { VENUES } from './data/venues.js';
import { migrateNeeds } from './data/needs.js';
import { REVIEWS, sortReviewsForProfile } from './data/reviews.js';

const KEY = 'accessmap.bkk.v1';

const DEFAULT_STATE = {
  account: null,       // { name, needs: [], custom: [] }
  contributions: {},   // { [venueId]: { [attrId]: value } }  — what YOU answered
  reports: {},         // { [venueId]: { [attrId]: [ { value, by, at } ] } } — what everyone answered
  confirmations: {},   // { [venueId]: { [attrId]: 'YYYY-MM-DD' } }
  features: {},        // { [venueId]: [ { id, kind, name, detail, lat, lng, added } ] }
  reviews: [],         // [ { id, venueId, author, needs, stars, body, date } ]
  places: [],          // places discovered via search or added by hand
};

let state = load();
const listeners = new Set();

/**
 * Is somebody signed in?
 *
 * Read straight from the token supabase-js keeps in localStorage, because this
 * has to be answerable synchronously at boot — before the auth library has
 * finished waking up.
 */
function hasSession() {
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k?.startsWith('sb-') && k.endsWith('-auth-token') && localStorage.getItem(k)) return true;
    }
  } catch { /* storage blocked — treat as guest */ }
  return false;
}

/**
 * Where a profile is kept depends on whether it belongs to anybody.
 *
 *   signed in — localStorage, so it survives closing the browser, and syncs.
 *   guest     — sessionStorage, which is exactly the right lifetime: a reload
 *               or coming back to the tab keeps everything, and closing the
 *               tab forgets it. Nobody returns days later to stale access
 *               needs they set once to have a look around, and nobody loses
 *               their work to an accidental refresh either.
 *
 * Signing in is what makes a profile outlive the tab, which is also the
 * clearest answer to "why would I make an account".
 */
// A function declaration, not a const arrow: load() runs while the module is
// still initialising, and a const would still be in its temporal dead zone —
// the ReferenceError then vanishes into load()'s catch and every visit looks
// like a first visit.
function store$() {
  return hasSession() ? localStorage : sessionStorage;
}

function load() {
  try {
    // A guest's tab-local copy wins while they are still in that tab.
    const raw = store$().getItem(KEY);
    if (raw) return { ...structuredClone(DEFAULT_STATE), ...JSON.parse(raw) };

    // Signed out since last time: do not leave the old profile lying around.
    if (!hasSession()) localStorage.removeItem(KEY);
  } catch { /* corrupt or blocked storage — fall through to defaults */ }
  return structuredClone(DEFAULT_STATE);
}

function save() {
  try {
    store$().setItem(KEY, JSON.stringify(state));
  } catch { /* private browsing — the app still works, it just won't persist */ }
}

/**
 * Called when a sign-in completes: move what the guest built in this tab into
 * permanent storage, so signing up never costs someone the work they just did.
 */
export function persistNow() {
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
    sessionStorage.removeItem(KEY);
  } catch { /* nothing more we can do */ }
}

function emit() {
  save();
  for (const fn of listeners) fn(state);
}

export const subscribe = fn => { listeners.add(fn); return () => listeners.delete(fn); };

// ---- optional cloud adapter ---------------------------------------------
// app.js injects this once Supabase is configured and signed in. The store
// never imports auth.js, so local-only mode has no cloud code in its path.

let cloud = null;
export function connectCloud(adapter) { cloud = adapter; }
export const isCloudConnected = () => Boolean(cloud);

const push = (kind, placeId, payload, place) => {
  try { cloud?.push({ kind, placeId, payload, place }); } catch (e) { console.warn('cloud push failed', e); }
};

/**
 * Fold everyone's contributions (from the shared table) into local state.
 * Remote rows lose their `mine` flag unless they were written by this user, so
 * the UI only offers deletion of your own.
 */
export function applyRemote(rows, myUserId) {
  for (const row of rows) {
    const mine = row.user_id === myUserId;
    const id = row.place_id;

    if (row.place && !state.places.some(p => p.id === id)) {
      state.places.push({ ...row.place, id, attrs: {}, features: [], mine: false });
    }

    if (row.kind === 'fact') {
      // Keep every report rather than letting the newest overwrite the rest —
      // agreement between people is the whole basis of the confidence rating.
      recordReport(id, row.payload.attrId, row.payload.value, row.user_id, row.created_at);
      if (mine) {
        state.contributions[id] ??= {};
        state.contributions[id][row.payload.attrId] = row.payload.value;
      }
    } else if (row.kind === 'feature') {
      state.features[id] ??= [];
      if (!state.features[id].some(f => f.id === row.payload.id)) {
        state.features[id].push({ ...row.payload, mine });
      }
    } else if (row.kind === 'review') {
      if (!state.reviews.some(r => r.id === row.payload.id)) {
        state.reviews.push({ ...row.payload, venueId: id, mine });
      }
    }
  }
  emit();
}

const today = () => new Date().toISOString().slice(0, 10);
const uid = prefix => `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;

// ---- account -------------------------------------------------------------

export const getState = () => state;
export const getAccount = () => state.account;
export const getNeeds = () => state.account?.needs ?? [];
export const isSignedIn = () => Boolean(state.account);

export function signIn(name, needs, custom = []) {
  state.account = { name: name.trim() || 'Guest', needs: [...needs], custom: [...custom] };
  emit();
}

export function signOut() {
  state = structuredClone(DEFAULT_STATE);
  // Clear both copies: emit() only writes to whichever one is current, which
  // would leave the other behind for the next visit to pick up.
  try {
    localStorage.removeItem(KEY);
    sessionStorage.removeItem(KEY);
  } catch { /* storage blocked */ }
  emit();
}

/** Rename the current profile — used when a guest signs up. */
export function setName(name) {
  state.account ??= { name: 'You', needs: [], custom: [] };
  state.account.name = name || state.account.name;
  emit();
}

export function setNeeds(needs, custom) {
  if (!state.account) return;
  state.account.needs = [...needs];
  if (custom) state.account.custom = [...custom];
  emit();
}

export const getCustomNeeds = () => state.account?.custom ?? [];

/** Replace local state wholesale — used when a signed-in profile arrives from the cloud. */
export function hydrate(patch) {
  state = { ...state, ...patch };
  emit();
}

// ---- facts ---------------------------------------------------------------

/** Record (or change) a fact a user reported about a venue. */
export function contribute(venueId, attrId, value) {
  state.contributions[venueId] ??= {};

  if (value === null) {
    delete state.contributions[venueId][attrId];
    const list = state.reports[venueId]?.[attrId];
    if (list) {
      const rest = list.filter(r => r.by !== 'me');
      if (rest.length) state.reports[venueId][attrId] = rest;
      else delete state.reports[venueId][attrId];
    }
  } else {
    const already = (state.reports[venueId]?.[attrId] ?? [])
      .filter(r => r.by !== 'me' && r.value === value).length;

    state.contributions[venueId][attrId] = value;
    recordReport(venueId, attrId, value, 'me');
    push('fact', venueId, { attrId, value }, placeIdentity(venueId));

  }

  emit();
}

/** Re-confirm an existing fact that had gone stale. */
export function confirmFact(venueId, attrId) {
  state.confirmations[venueId] ??= {};
  state.confirmations[venueId][attrId] = today();
  emit();
}

export const myAnswer = (venueId, attrId) => state.contributions[venueId]?.[attrId] ?? null;

export const hasContributed = (venueId, attrId) =>
  Boolean(state.contributions[venueId]?.[attrId] || state.confirmations[venueId]?.[attrId]);

export const contributionCount = () =>
  Object.values(state.contributions).reduce((n, o) => n + Object.keys(o).length, 0)
  + Object.values(state.features).reduce((n, a) => n + a.length, 0)
  + state.reviews.length
  + state.places.length;

// ---- located features ----------------------------------------------------

/** Add an entrance / lift / toilet / obstacle at its own coordinates. */
export function addFeature(venueId, { kind, name, detail, lat, lng }) {
  state.features[venueId] ??= [];
  const feature = {
    id: uid('f'), kind, name: name.trim(), detail: detail.trim(),
    lat: Number(lat), lng: Number(lng), added: today(), mine: true,
  };
  state.features[venueId].push(feature);
  push('feature', venueId, feature, placeIdentity(venueId));
  emit();
  return feature;
}

export function removeFeature(venueId, featureId) {
  state.features[venueId] = (state.features[venueId] ?? []).filter(f => f.id !== featureId);
  emit();
}

// ---- reviews -------------------------------------------------------------

export function addReview(venueId, { stars, body }) {
  const review = {
    id: uid('r'), venueId,
    author: state.account?.name ?? 'Anonymous',
    needs: [...(state.account?.needs ?? [])],
    custom: [...(state.account?.custom ?? [])],
    stars: Number(stars), body: body.trim(), date: today(), mine: true,
  };
  state.reviews.unshift(review);
  push('review', venueId, review, placeIdentity(venueId));
  emit();
  return review;
}

export function removeReview(reviewId) {
  state.reviews = state.reviews.filter(r => r.id !== reviewId);
  emit();
}

/** Seeded reviews plus everything written here, most relevant to you first. */
export function reviewsFor(venueId) {
  const all = [...REVIEWS, ...state.reviews].filter(r => r.venueId === venueId);
  return sortReviewsForProfile(all, getNeeds());
}

// ---- places --------------------------------------------------------------

/**
 * Keep a place found through search, so it survives a reload and shows on the
 * map. Called as soon as someone opens a search result — the record is just an
 * identity until they add facts to it.
 */
export function rememberPlace(place) {
  const existing = state.places.find(p => p.id === place.id);
  if (existing) return existing;
  const saved = { ...place, fromSearch: true, seen: today() };
  state.places.push(saved);
  emit();
  return saved;
}

/** Places worth showing on the map: anything with information recorded on it. */
export function placesWithData() {
  const touched = p =>
    Object.keys(state.contributions[p.id] ?? {}).length > 0
    || (state.features[p.id] ?? []).length > 0
    || state.reviews.some(r => r.venueId === p.id)
    || p.mine;

  const seeded = VENUES.filter(p => Object.keys(p.attrs).length > 0 || p.features.length > 0 || touched(p));
  const added = state.places.filter(p => touched(p) && !seeded.some(s => s.id === p.id));
  return [...seeded, ...added].map(withContributions);
}

/** Add a place that search could not find. */
export function addPlace({ name, category, address, lat, lng }) {
  const place = {
    id: uid('p'), name: name.trim(), category,
    address: address.trim() || 'Added by a user',
    lat: Number(lat), lng: Number(lng),
    attrs: {}, features: [], updated: today(), source: 'community', mine: true,
  };
  state.places.push(place);
  push('place', place.id, { added: place.updated }, placeIdentity(place.id));
  emit();
  return place;
}

export function removePlace(placeId) {
  state.places = state.places.filter(p => p.id !== placeId);
  delete state.contributions[placeId];
  delete state.features[placeId];
  state.reviews = state.reviews.filter(r => r.venueId !== placeId);
  emit();
}

/** The bare identity of a place, sent alongside a contribution so others can find it. */
function placeIdentity(id) {
  const p = state.places.find(x => x.id === id) ?? VENUES.find(x => x.id === id);
  if (!p) return null;
  const { name, category, address, lat, lng } = p;
  return { name, category, address, lat, lng };
}

// ---- reading venues back with contributions merged in --------------------

/**
 * A venue with this user's contributions folded in, so a fact they add on the
 * venue page immediately changes the score and the map colour.
 */
/** Log one person's answer about one fact. Re-answering replaces their own. */
function recordReport(placeId, attrId, value, by = 'me', at = today()) {
  state.reports[placeId] ??= {};
  const list = (state.reports[placeId][attrId] ??= []);
  const existing = list.findIndex(r => r.by === by);
  const entry = { value, by, at: typeof at === 'string' ? at.slice(0, 10) : today() };
  if (existing >= 0) list[existing] = entry; else list.push(entry);
}

/**
 * What everyone says about one fact, and how much to trust it.
 *
 * The value most people report wins; ties go to the most recent. Confidence
 * comes from how many independently said the same thing, and drops the moment
 * anyone contradicts it — a fact two people disagree about is exactly the fact
 * a reader needs warning about.
 */
export function consensusFor(placeId, attrId) {
  const list = state.reports[placeId]?.[attrId] ?? [];
  if (!list.length) return null;

  const tally = new Map();
  for (const r of list) tally.set(r.value, (tally.get(r.value) ?? 0) + 1);

  let best = null;
  for (const [value, count] of tally) {
    const latest = list.filter(r => r.value === value).map(r => r.at).sort().pop();
    if (!best || count > best.count || (count === best.count && latest > best.latest)) {
      best = { value, count, latest };
    }
  }

  const total = list.length;
  const disagree = total - best.count;
  const level = disagree > 0 && best.count <= disagree ? 'disputed'
    : disagree > 0 ? 'mixed'
    : best.count >= 3 ? 'strong'
    : best.count === 2 ? 'confirmed'
    : 'single';

  return { value: best.value, agree: best.count, disagree, total, level, verified: best.latest };
}

export const CONFIDENCE = {
  single:    { label: 'One report',        note: 'Only one person has said this.' },
  confirmed: { label: 'Two agree',         note: 'Two people independently reported the same thing.' },
  strong:    { label: 'Well confirmed',    note: 'Three or more people agree.' },
  mixed:     { label: 'Some disagreement', note: 'Most people say this, but not everyone.' },
  disputed:  { label: 'Disputed',          note: 'People report different things — check for yourself.' },
  imported:  { label: 'Imported',          note: 'From OpenStreetMap, not confirmed by a visitor.' },
};

export function withContributions(venue) {
  const added = state.contributions[venue.id];
  const confirmed = state.confirmations[venue.id];
  const extraFeatures = state.features[venue.id];
  const reported = state.reports[venue.id];
  if (!added && !confirmed && !extraFeatures && !reported) return venue;

  const attrs = { ...venue.attrs };

  // Anything people have reported overrides the import, using the consensus
  // value and carrying its confidence along for display.
  for (const attrId of Object.keys(state.reports[venue.id] ?? {})) {
    const c = consensusFor(venue.id, attrId);
    if (c) attrs[attrId] = [c.value, c.verified, 'community', c];
  }

  for (const [attrId, value] of Object.entries(added ?? {})) {
    if (!state.reports[venue.id]?.[attrId]) attrs[attrId] = [value, today(), 'community'];
  }
  for (const attrId of Object.keys(confirmed ?? {})) {
    const raw = attrs[attrId];
    const value = Array.isArray(raw) ? raw[0] : raw;
    if (value !== undefined) attrs[attrId] = [value, confirmed[attrId], 'community'];
  }

  return { ...venue, attrs, features: [...venue.features, ...(extraFeatures ?? [])] };
}

export const allVenues = () => [...VENUES, ...state.places].map(withContributions);

/**
 * Has this place had anything recorded about it — by anyone, or by the import?
 *
 * This used to count only the current user's own contributions, so every
 * imported place looked empty and its card rendered without a score at all.
 */



export const hasData = id => {
  const venue = VENUES.find(v => v.id === id) ?? state.places.find(v => v.id === id);
  return Object.keys(venue?.attrs ?? {}).length > 0
    || (venue?.features ?? []).length > 0
    || Object.keys(state.contributions[id] ?? {}).length > 0
    || Object.keys(state.reports[id] ?? {}).length > 0
    || (state.features[id] ?? []).length > 0
    || state.reviews.some(r => r.venueId === id);
};

export function venueById(id) {
  const v = VENUES.find(x => x.id === id) ?? state.places.find(x => x.id === id);
  return v ? withContributions(v) : null;
}
