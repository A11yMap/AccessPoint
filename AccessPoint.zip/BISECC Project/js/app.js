// App shell: hash routing, re-rendering, and optional cloud sync.

import * as store from './store.js';
import * as auth from './auth.js';
import {
  renderOnboarding, renderMapScreen, renderVenueScreen,
  renderTopbar, renderBrand, openProfileDialog,
} from './views.js';
import { toast } from './ui.js';

const screens = {
  onboarding: document.querySelector('#screen-onboarding'),
  map: document.querySelector('#screen-map'),
  venue: document.querySelector('#screen-venue'),
};

document.querySelector('#profile-btn').addEventListener('click', openProfileDialog);

const goto = hash => { location.hash = hash; };
const show = name => {
  for (const [key, node] of Object.entries(screens)) node.hidden = key !== name;
};

/**
 * Saving a contribution notifies subscribers AND the caller asks for a repaint,
 * so a naive render() would run several times per tap — rebuilding the detail
 * map each time. Coalesce the requests into a single paint.
 *
 * Deliberately a microtask, not requestAnimationFrame: rAF does not fire in a
 * background or hidden tab, so a page opened in one would sit there blank until
 * it was looked at.
 */
let queued = false;
function render() {
  if (queued) return;
  queued = true;
  queueMicrotask(() => { queued = false; paint(); });
}

function paint() {
  renderBrand();
  renderTopbar();

  if (!store.isSignedIn()) {
    show('onboarding');
    renderOnboarding(screens.onboarding);
    return;
  }

  const match = location.hash.match(/^#\/v\/(.+)$/);
  if (match) {
    show('venue');
    renderVenueScreen(screens.venue, decodeURIComponent(match[1]), {
      onBack: () => goto('#/'),
      rerender: render,
    });
    return;
  }

  show('map');
  renderMapScreen(screens.map, {
    onOpenVenue: id => goto(`#/v/${encodeURIComponent(id)}`),
  });
}

// ---- cloud sync ----------------------------------------------------------

/** Pull the shared data down and wire local writes back up. */
async function syncWithCloud(user) {
  if (!user) return;

  store.connectCloud({
    push: ({ kind, placeId, payload, place }) =>
      auth.pushContribution({ kind, placeId, payload, place }),
  });

  const [profile, rows] = await Promise.all([auth.loadProfile(), auth.loadContributions()]);

  if (profile?.needs?.length || profile?.name) {
    // The cloud profile wins on a fresh device; otherwise keep what is here.
    store.hydrate({ account: { name: profile.name ?? 'You', needs: profile.needs ?? [], custom: profile.custom ?? [] } });
  } else if (store.getAccount()) {
    await auth.saveProfile({ ...store.getAccount() });
  }

  if (rows.length) {
    store.applyRemote(rows, user.id);
    toast(`Synced ${rows.length} contribution${rows.length === 1 ? '' : 's'} from everyone`);
  }
}

// Keep the cloud profile in step with local edits.
let lastProfile = JSON.stringify(store.getAccount());
store.subscribe(() => {
  const now = JSON.stringify(store.getAccount());
  if (now !== lastProfile && auth.getUser() && store.getAccount()) {
    lastProfile = now;
    auth.saveProfile({ ...store.getAccount() });
  }
});

/**
 * Testing helper. Run in the browser console:
 *
 *     await resetEverything()
 *
 * Deletes everything that was contributed — in this browser AND, if you are
 * signed in, your rows in the shared database. What it cannot touch is the
 * imported OpenStreetMap data, because that is compiled into the app rather
 * than stored anywhere, so it always comes back exactly as it was.
 *
 * Wiping only one of the two copies used to be easy to do by accident, and
 * left the app looking like the reset had failed.
 */
window.resetEverything = async () => {
  let removed = 0;
  try {
    removed = await auth.deleteAllMyContributions();
  } catch (err) {
    console.warn('Could not clear the shared copy:', err.message);
    return `Local data cleared, but the shared copy failed: ${err.message}. Imported places are unaffected either way.`;
  }
  store.signOut();
  location.hash = '';
  setTimeout(() => location.reload(), 60);
  return `Cleared this browser${removed ? ` and ${removed} row${removed === 1 ? '' : 's'} from the database` : ''}. Imported places are untouched.`;
};

// Older name, kept so a habit does not break.
window.resetLocal = () => window.resetEverything();

window.addEventListener('hashchange', render);
store.subscribe(render);
render();

auth.onAuthChange(user => { render(); syncWithCloud(user); });
auth.initAuth().then(user => { if (user) syncWithCloud(user); }).catch(err => {
  console.warn('auth init failed — staying local-only:', err.message);
});
