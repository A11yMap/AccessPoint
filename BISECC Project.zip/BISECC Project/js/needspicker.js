// Describing how you get around, in your own words.
//
// A fixed list of nine tick-boxes cannot describe a person. So this is a
// type-ahead: you write what is true for you ("I use a walking stick",
// "cochlear implant", "รถเข็น") and it matches that to the access needs the
// scoring engine understands. Anything it cannot match is still kept, as a
// free-text note — clearly marked, because the engine has no weights for it and
// pretending otherwise would be dishonest.

import { NEEDS, NEED_BY_ID, NEED_GROUPS, interpret } from './data/needs.js';
import { h } from './ui.js';

export function needsPicker({ needs = [], custom = [], onChange = () => {} } = {}) {
  const chosen = new Set(needs);
  const notes = [...custom];

  const chips = h('div', { class: 'picked' });
  const suggestions = h('div', { class: 'suggestions', role: 'listbox', hidden: true });

  const input = h('input', {
    class: 'field', type: 'text', id: 'needs-input',
    role: 'combobox', 'aria-expanded': 'false', 'aria-controls': 'needs-suggestions',
    autocomplete: 'off',
    placeholder: 'Describe it: "I use a power chair", "fibromyalgia", "cochlear implant"…',
    oninput: () => paintSuggestions(),
    onkeydown: e => {
      if (e.key === 'Enter') {
        e.preventDefault();
        const first = suggestions.querySelector('.suggestion');
        first?.click();
      } else if (e.key === 'Escape') {
        input.value = '';
        paintSuggestions();
      } else if (e.key === 'Backspace' && !input.value) {
        const last = [...chosen].pop() ?? null;
        if (last) toggleNeed(last);
        else if (notes.length) removeNote(notes[notes.length - 1]);
      }
    },
  });
  suggestions.id = 'needs-suggestions';

  function emit() { onChange({ needs: [...chosen], custom: [...notes] }); }

  function toggleNeed(id) {
    chosen.has(id) ? chosen.delete(id) : chosen.add(id);
    input.value = '';
    paintChips(); paintSuggestions(); emit();
    input.focus();
  }

  function addNote(text) {
    const value = text.trim();
    if (!value || notes.some(n => n.toLowerCase() === value.toLowerCase())) return;
    notes.push(value);
    input.value = '';
    paintChips(); paintSuggestions(); emit();
    input.focus();
  }

  function removeNote(text) {
    const i = notes.indexOf(text);
    if (i >= 0) notes.splice(i, 1);
    paintChips(); emit();
  }

  function paintChips() {
    chips.replaceChildren(
      ...[...chosen].map(id => {
        const need = NEED_BY_ID[id];
        return h('button', {
          class: 'picked__chip', type: 'button',
          'aria-label': `Remove ${need.label}`,
          onclick: () => toggleNeed(id),
        }, [
          h('span', { 'aria-hidden': 'true', text: need.icon }),
          need.label,
          h('span', { class: 'picked__x', 'aria-hidden': 'true', text: '✕' }),
        ]);
      }),
      ...notes.map(note => h('button', {
        class: 'picked__chip picked__chip--note', type: 'button',
        'aria-label': `Remove note: ${note}`,
        onclick: () => removeNote(note),
      }, [
        h('span', { 'aria-hidden': 'true', text: '✎' }),
        note,
        h('span', { class: 'picked__x', 'aria-hidden': 'true', text: '✕' }),
      ])),
      chosen.size === 0 && notes.length === 0
        ? h('p', { class: 'hint picked__empty', text: 'Nothing added yet — you can also skip this and add it later.' })
        : null,
    );
  }

  function paintSuggestions() {
    const text = input.value.trim();

    if (!text) {
      // Nothing typed: browse everything, grouped, so the range is visible.
      const rows = [];
      for (const group of NEED_GROUPS) {
        const inGroup = NEEDS.filter(n => n.group === group && !chosen.has(n.id));
        if (!inGroup.length) continue;
        rows.push(h('p', { class: 'suggest-group', text: group }));
        rows.push(...inGroup.map(need => needRow(need)));
      }
      suggestions.replaceChildren(...rows);
      suggestions.hidden = rows.length === 0;
      input.setAttribute('aria-expanded', String(rows.length > 0));
      return;
    }

    const matches = interpret(text).filter(n => !chosen.has(n.id));
    const strong = matches.filter(n => n.matchScore >= 55);
    const weak = matches.filter(n => n.matchScore < 55).slice(0, 3);

    const rows = [
      ...strong.slice(0, 6).map(need => needRow(need)),
      weak.length ? h('p', { class: 'suggest-group', text: 'Did you mean' }) : null,
      ...weak.map(need => needRow(need)),
    ].filter(Boolean);

    // Anything can be kept in the user's own words, matched or not.
    if (text.length >= 2) {
      rows.push(h('button', {
        class: 'suggestion suggestion--note', type: 'button', role: 'option',
        onclick: () => addNote(text),
      }, [
        h('span', { class: 'suggestion__icon', 'aria-hidden': 'true', text: '✎' }),
        h('span', {}, [
          h('span', { class: 'suggestion__label', text: `Keep “${text}” in my own words` }),
          h('span', { class: 'suggestion__why', text: matches.length
            ? 'saved on your profile and shown on your reviews'
            : 'nothing matched — it will not change your scores, but people will see it' }),
        ]),
      ]));
    }

    suggestions.replaceChildren(...rows);
    suggestions.hidden = rows.length === 0;
    input.setAttribute('aria-expanded', String(rows.length > 0));
  }

  /** One suggestion, explaining itself when the match was not the obvious one. */
  function needRow(need) {
    const explain = need.matchedOn
      ? `matched “${need.matchedOn}”${need.why ? ' — ' + need.why : ''}`
      : need.why ?? '';
    return h('button', {
      class: 'suggestion', type: 'button', role: 'option',
      onclick: () => toggleNeed(need.id),
    }, [
      h('span', { class: 'suggestion__icon', 'aria-hidden': 'true', text: need.icon }),
      h('span', {}, [
        h('span', { class: 'suggestion__label', text: need.label }),
        explain ? h('span', { class: 'suggestion__why', text: explain }) : null,
      ]),
    ]);
  }

  paintChips();
  paintSuggestions();

  const root = h('div', { class: 'needs-picker' }, [
    chips,
    input,
    suggestions,
    notes.length || chosen.size
      ? null
      : null,
  ]);

  root.getValue = () => ({ needs: [...chosen], custom: [...notes] });
  return root;
}
