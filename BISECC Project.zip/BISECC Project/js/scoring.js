// The scoring engine.
//
// A venue does not have an accessibility score. A venue + a person has a score.
// Everything here takes the viewer's access needs as an argument.

import { ATTRIBUTES, ATTR_BY_ID, appliesToVenue } from './data/attributes.js';
import { readAttr } from './data/venues.js';
import { NEEDS, NEED_BY_ID, needLabel, needShort } from './data/needs.js';

/** The nine weight profiles attributes.js is written against. */
const ALL_DIMENSIONS = ['wheelchair', 'mobility', 'blind', 'lowvision', 'deaf', 'hoh', 'mute', 'sensory', 'cognitive'];

/**
 * Turn the granular needs someone picked into the dimensions the attribute
 * registry understands, plus per-attribute boosts.
 *
 * Factors are combined with max(), not sum: someone who is both a manual and a
 * powerchair user is not twice as affected by a step.
 */
export function profileFor(needIds) {
  const dims = {};
  const boosts = {};
  const credit = {};   // dimension/attribute -> which needs asked for it

  const ids = needIds?.length ? needIds : null;
  if (!ids) {
    for (const d of ALL_DIMENSIONS) dims[d] = 1;
    return { dims, boosts, credit, generic: true };
  }

  for (const id of ids) {
    const need = NEED_BY_ID[id];
    if (!need) continue;
    for (const [dim, factor] of Object.entries(need.dimensions ?? {})) {
      dims[dim] = Math.max(dims[dim] ?? 0, factor);
      (credit[dim] ??= new Set()).add(id);
    }
    for (const [attrId, extra] of Object.entries(need.boosts ?? {})) {
      boosts[attrId] = Math.max(boosts[attrId] ?? 0, extra);
      (credit[attrId] ??= new Set()).add(id);
    }
  }
  return { dims, boosts, credit, generic: false };
}

/** Where a boosted attribute takes its good/bad judgement from. */
function ratingSource(attr, dims) {
  for (const dim of Object.keys(dims)) {
    if (attr.needs[dim]) return attr.needs[dim];
  }
  const all = Object.values(attr.needs);
  return all.sort((a, b) => b.w - a.w)[0] ?? null;
}
const STALE_AFTER_MONTHS = 18;

export function monthsSince(dateStr) {
  const then = new Date(dateStr + 'T00:00:00');
  const now = new Date();
  return (now.getFullYear() - then.getFullYear()) * 12 + (now.getMonth() - then.getMonth());
}

export const isStale = dateStr => monthsSince(dateStr) >= STALE_AFTER_MONTHS;

export function formatVerified(dateStr) {
  const months = monthsSince(dateStr);
  if (months < 1) return 'checked this month';
  if (months === 1) return 'checked last month';
  if (months < 12) return `checked ${months} months ago`;
  const years = Math.floor(months / 12);
  return `checked over ${years} year${years > 1 ? 's' : ''} ago`;
}

const SOURCE_LABEL = {
  community: 'Reported by visitors',
  venue: 'Provided by the venue',
  audit: 'Independent access audit',
  osm: 'Imported from OpenStreetMap',
};
export const sourceLabel = s => SOURCE_LABEL[s] ?? s;

/**
 * Score a venue for one person's set of access needs.
 * An empty profile falls back to "everyone", which is the honest answer to
 * "how accessible is this in general" — an average over every need.
 */
export function scoreVenue(venue, needIds) {
  const profile = profileFor(needIds);

  const rows = [];      // relevant to this person, sorted by relevance below
  const otherRows = []; // known, but irrelevant to this person
  const problems = [];
  let weighted = 0;
  let totalWeight = 0;
  let known = 0;
  let relevantCount = 0;

  for (const attr of ATTRIBUTES) {
    if (!appliesToVenue(attr, venue)) continue;

    const fact = readAttr(venue, attr.id);

    // How much this attribute matters to this person, and who asked for it.
    let weight = 0;
    const contributors = new Set();
    for (const [dim, factor] of Object.entries(profile.dims)) {
      const spec = attr.needs[dim];
      if (!spec) continue;
      weight += spec.w * factor;
      for (const id of profile.credit[dim] ?? []) contributors.add(id);
    }
    const boost = profile.boosts[attr.id] ?? 0;
    if (boost) {
      weight += boost;
      for (const id of profile.credit[attr.id] ?? []) contributors.add(id);
    }

    if (weight <= 0) {
      if (fact) otherRows.push(buildRow(attr, fact, [], 0, null));
      continue;
    }

    relevantCount++;

    if (!fact) {
      // An unknown is NOT a pass. It counts against coverage and shows as a gap.
      rows.push(buildRow(attr, null, [...contributors], weight, null));
      continue;
    }

    known++;

    let attrWeighted = 0;
    let attrWeight = 0;

    for (const [dim, factor] of Object.entries(profile.dims)) {
      const spec = attr.needs[dim];
      if (!spec) continue;
      const rating = spec.rate?.[fact.value] ?? 0.5;
      const w = spec.w * factor;
      attrWeighted += w * rating;
      attrWeight += w;

      // A gate is personal: a step is a serious problem for someone who cannot
      // climb it, and merely a step for everyone else. With no profile set we
      // are averaging over everybody, so nothing is a serious problem for the
      // reader in particular — it would be absurd to warn someone with no
      // access needs away from a temple because it has stairs.
      if (!profile.generic && spec.gate?.includes(fact.value) && factor >= 0.5) {
        for (const id of profile.credit[dim] ?? []) {
          problems.push({
            attrId: attr.id, label: attr.label, text: attr.values[fact.value],
            needId: id, needLabel: needShort(id),
          });
        }
      }
    }

    if (boost) {
      const src = ratingSource(attr, profile.dims);
      const rating = src?.rate?.[fact.value] ?? 0.5;
      attrWeighted += boost * rating;
      attrWeight += boost;
    }

    weighted += attrWeighted;
    totalWeight += attrWeight;

    rows.push(buildRow(attr, fact, [...contributors], attrWeight, attrWeighted / attrWeight));
  }

  // Most relevant first; within equal relevance, surface the problems.
  rows.sort((a, b) => b.relevance - a.relevance || (a.rating ?? 2) - (b.rating ?? 2));
  otherRows.sort((a, b) => a.group.localeCompare(b.group));

  const seen = new Set();
  const unique = problems.filter(b => !seen.has(b.attrId) && seen.add(b.attrId));
  problems.length = 0;
  problems.push(...unique);

  const hasData = known > 0;
  const ratio = totalWeight > 0 ? weighted / totalWeight : null;
  const status = statusFor(problems.length > 0, hasData, ratio, known, relevantCount);

  // Show a score for anything at all is known about.
  //
  // Withholding it below a coverage threshold was too strict in practice: most
  // imported places have two or three facts out of eleven, so nearly every
  // place showed a blank — which reads as "broken", not as "we are unsure".
  // The number is shown, and the coverage line next to it carries the caveat
  // honestly: "based on 2 of 11 things that matter to you".
  const confident = hasData;

  // A severe problem caps the score inside the bottom star. Nothing claims you
  // cannot go — people judge that for themselves, and someone with a companion
  // or a portable ramp may manage what the data calls impossible. But a place
  // with steps at every door is never a 3, and the remaining strengths only
  // move it between 0 and 1.
  const ceiling = problems.length ? 1 : 5;

  return {
    venue,
    needIds: needIds ?? [],
    usingFallbackProfile: !needIds?.length,
    severe: problems.length > 0,
    problems,
    confident,
    stars: confident ? Math.round(ratio * ceiling * 10) / 10 : null,
    coverage: {
      known,
      total: relevantCount,
      pct: relevantCount ? Math.round((known / relevantCount) * 100) : 0,
    },

    // How GOOD a place is and how much is KNOWN about it are separate
    // questions. A station with a step-free entrance and a lift really is good
    // for a wheelchair user, even if nobody has said anything about its toilets
    // yet — so it stays green, and the thinness is said in words instead of
    // being disguised as a middling grey score.
    thin: relevantCount > 0 && known / relevantCount < 0.5,
    rows,
    otherRows,
    status,
  };
}

function buildRow(attr, fact, needIds, relevance, rating) {
  return {
    attrId: attr.id,
    group: attr.group,
    label: attr.label,
    value: fact?.value ?? null,
    text: fact ? attr.values[fact.value] : null,
    verified: fact?.verified ?? null,
    source: fact?.source ?? null,
    confidence: fact?.confidence ?? null,
    stale: fact ? isStale(fact.verified) : false,
    relevance,
    rating,
    needs: needIds,
    tone: toneFor(rating),
  };
}

function toneFor(rating) {
  if (rating === null || rating === undefined) return 'unknown';
  if (rating >= 0.75) return 'good';
  if (rating >= 0.45) return 'ok';
  return 'bad';
}

function statusFor(severe, hasData, ratio, known, total) {
  if (severe) return 'avoid';
  if (!hasData) return 'unknown';
  if (ratio >= 0.7) return 'good';
  if (ratio >= 0.45) return 'ok';
  return 'poor';
}

export const STATUS_META = {
  good:    { label: 'Works for you',      pin: '#1f8a5f' },
  ok:      { label: 'Partly works',       pin: '#c98211' },
  poor:    { label: 'Difficult for you',  pin: '#d2622e' },
  avoid:   { label: 'Strongly not recommended', pin: '#c2352f' },
  unknown: { label: 'No data yet',        pin: '#7a8091' },
};

/** Which of this person's needs does the venue serve worst? */
export function weakestNeed(result) {
  const byNeed = new Map();
  for (const row of result.rows) {
    if (row.rating === null) continue;
    for (const id of row.needs) {
      const cur = byNeed.get(id) ?? { sum: 0, w: 0 };
      cur.sum += row.relevance * row.rating;
      cur.w += row.relevance;
      byNeed.set(id, cur);
    }
  }
  let worst = null;
  for (const [id, { sum, w }] of byNeed) {
    if (!w) continue;
    const score = sum / w;
    if (!worst || score < worst.score) worst = { id, score };
  }
  return worst;
}
