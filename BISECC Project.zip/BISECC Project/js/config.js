// ---------------------------------------------------------------------------
// APP NAME — not chosen yet. Type it between the quotes and it appears
// everywhere: the tab title, the header and the welcome screen.
// While it is empty the header shows a dashed "name goes here" placeholder.
// ---------------------------------------------------------------------------
export const APP_NAME = '';

/** The district the sample venues sit in. */
export const DISTRICT = 'Bristol Harbourside';

/** Where the map opens. */
export const MAP_VIEW = {
  center: [-2.5966, 51.4496], // [lng, lat]
  zoom: 16,
  minZoom: 13,
  maxZoom: 19,
};

/**
 * Basemap tiles.
 *
 * Esri's World Street Map: a light, realistic street basemap, free to use and —
 * crucially — it does NOT require an API key and does not care where the page is
 * served from, so this works when you open the file directly.
 *
 * Why not OpenStreetMap's own tiles? Their volunteer servers enforce a usage
 * policy that needs a real identifying Referer/User-Agent, and they return
 * "403 Access blocked" for a page opened from file:// or an unidentified app.
 * The `osm` entry below is kept for when this is properly hosted under its own
 * domain — read https://operations.osmfoundation.org/policies/tiles/ first.
 */
export const BASEMAP = {
  tiles: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}',
  attribution: 'Tiles &copy; <a href="https://www.esri.com/">Esri</a> &mdash; Esri, HERE, Garmin, &copy; OpenStreetMap contributors',

  osm: {
    tiles: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
  },
};
