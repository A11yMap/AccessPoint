// ---------------------------------------------------------------------------
// APP NAME — not chosen yet. Type it between the quotes and it appears
// everywhere: the tab title, the header and the welcome screen.
// While it is empty the header shows a dashed "name goes here" placeholder.
// ---------------------------------------------------------------------------
export const APP_NAME = '';

/**
 * SIGN-IN AND CLOUD SYNC (optional).
 *
 * Paste your Supabase project URL and anon key here, and run supabase-schema.sql
 * in that project. People can then sign in by email and their profile and
 * contributions follow them between devices — and everyone's contributions are
 * shared, which is the point of a crowdsourced map.
 *
 * Leave these blank and the app runs local-only: everything works, but it is
 * kept in this one browser. The anon key is a public key; it is meant to be in
 * the page, and Row Level Security (in the schema file) is what protects data.
 */
export const SUPABASE = {
  url: 'https://givpgrfpniifqlvaefnh.supabase.co',  // Project Settings → API → Project URL
  anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdpdnBncmZwbmlpZnFsdmFlZm5oIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk0MTcyODMsImV4cCI6MjEwNDk5MzI4M30.R2n1L1GY3BZ9XeoZw2jYPmhSo8oafHuCYqo8DCJ0_OY',  // the "anon public" key from Project Settings → API
};

/** The area the app covers. */
export const DISTRICT = 'Bangkok & around';

/**
 * Search is limited to this box so a query for "paragon" returns the Bangkok one
 * rather than a hotel in Illinois. Covers Bangkok, Nonthaburi, Pathum Thani,
 * Samut Prakan, Samut Sakhon and the near edges of Nakhon Pathom and Ayutthaya.
 * [minLng, minLat, maxLng, maxLat]
 */
export const SEARCH_BBOX = [99.80, 13.20, 101.20, 14.30];

/**
 * Place search runs against Photon, an open-source geocoder over the full
 * OpenStreetMap database. Free, no API key, and it autocompletes as you type.
 */
export const SEARCH_API = 'https://photon.komoot.io/api/';

/** Where the map opens. */
export const MAP_VIEW = {
  center: [100.5350, 13.7500], // [lng, lat] — central Bangkok
  zoom: 11,                    // wide enough to include Nonthaburi, Samut Prakan, Rangsit
  minZoom: 9,
  maxZoom: 19,
};

/**
 * Basemap tiles.
 *
 * Esri's World Street Map: a light, realistic street basemap, free to use and —
 * crucially — it does NOT require an API key and does not care where the page is
 * served from, so this works when you open the file directly.
 *
 * Why not OpenStreetMap's own tiles? Their volunteer servers enforce a usage
 * policy that needs a real identifying Referer/User-Agent, and they return
 * "403 Access blocked" for a page opened from file:// or an unidentified app.
 * The `osm` entry below is kept for when this is properly hosted under its own
 * domain — read https://operations.osmfoundation.org/policies/tiles/ first.
 */
export const BASEMAP = {
  tiles: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}',
  attribution: 'Tiles &copy; <a href="https://www.esri.com/">Esri</a> &mdash; Esri, HERE, Garmin, &copy; OpenStreetMap contributors',

  osm: {
    tiles: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
  },
};
