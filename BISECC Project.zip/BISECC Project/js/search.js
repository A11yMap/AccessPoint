// Place search over the real OpenStreetMap database.
//
// There is no hand-written list of places in this app. You search for anywhere
// in and around Bangkok exactly as you would in a maps app, and whatever you
// pick becomes a place you can record accessibility information about.
//
// Photon is an open-source geocoder run over OSM data: free, no API key,
// built for autocomplete. Results are constrained to the Bangkok bounding box.

import { SEARCH_API, SEARCH_BBOX, MAP_VIEW } from './config.js';

/**
 * OSM tags → the app's categories. OSM has thousands of tag combinations; this
 * covers what people actually search for, and anything unmatched falls back to
 * a generic place rather than being dropped.
 */
const CATEGORY_MAP = {
  'shop/mall': 'mall',
  'shop/department_store': 'mall',
  'shop/supermarket': 'shop',
  'shop/convenience': 'shop',
  'amenity/marketplace': 'market',
  'amenity/place_of_worship': 'temple',
  'historic/temple': 'temple',
  'tourism/museum': 'museum',
  'tourism/gallery': 'museum',
  'tourism/attraction': 'attraction',
  'tourism/viewpoint': 'attraction',
  'tourism/theme_park': 'attraction',
  'tourism/zoo': 'attraction',
  'tourism/hotel': 'hotel',
  'tourism/hostel': 'hotel',
  'leisure/park': 'park',
  'leisure/garden': 'park',
  'leisure/nature_reserve': 'park',
  'leisure/sports_centre': 'sports',
  'leisure/fitness_centre': 'sports',
  'leisure/stadium': 'sports',
  'leisure/swimming_pool': 'sports',
  'railway/station': 'transport',
  'railway/halt': 'transport',
  'railway/subway_entrance': 'transport',
  'public_transport/station': 'transport',
  'amenity/bus_station': 'transport',
  'highway/bus_stop': 'transport',
  'aeroway/aerodrome': 'airport',
  'aeroway/terminal': 'airport',
  'amenity/ferry_terminal': 'pier',
  'amenity/hospital': 'hospital',
  'amenity/clinic': 'hospital',
  'amenity/doctors': 'hospital',
  'amenity/pharmacy': 'pharmacy',
  'amenity/university': 'university',
  'amenity/college': 'university',
  'amenity/school': 'school',
  'amenity/kindergarten': 'school',
  'amenity/library': 'library',
  'amenity/cinema': 'cinema',
  'amenity/theatre': 'cinema',
  'amenity/cafe': 'cafe',
  'amenity/restaurant': 'restaurant',
  'amenity/fast_food': 'restaurant',
  'amenity/food_court': 'restaurant',
  'amenity/bar': 'restaurant',
  'amenity/pub': 'restaurant',
  'amenity/bank': 'bank',
  'amenity/townhall': 'government',
  'amenity/police': 'government',
  'amenity/post_office': 'government',
  'amenity/community_centre': 'government',
  'amenity/conference_centre': 'convention',
  'office/government': 'government',
};

const categoryFor = p => CATEGORY_MAP[`${p.osm_key}/${p.osm_value}`]
  ?? (p.osm_key === 'shop' ? 'shop' : p.osm_key === 'tourism' ? 'attraction' : 'place');

/** Build a readable Thai/English address out of whatever OSM has. */
function addressOf(p) {
  const parts = [p.street, p.locality, p.district, p.city].filter(Boolean);
  const seen = new Set();
  const unique = parts.filter(x => !seen.has(x) && seen.add(x));
  return unique.slice(0, 3).join(', ') || p.country || 'Bangkok';
}

/** Photon feature → the venue shape the rest of the app expects. */
function toPlace(feature) {
  const p = feature.properties;
  const [lng, lat] = feature.geometry.coordinates;
  return {
    id: `osm:${p.osm_type}${p.osm_id}`,
    name: p.name || addressOf(p),
    category: categoryFor(p),
    address: addressOf(p),
    lat, lng,
    attrs: {},
    features: [],
    updated: null,
    source: 'community',
    fromSearch: true,
  };
}

/**
 * Search for places. Returns [] for short queries rather than hammering the API.
 * Pass an AbortSignal so a newer keystroke cancels the previous request.
 */
export async function searchPlaces(query, { signal, near } = {}) {
  const q = query.trim();
  if (q.length < 2) return [];

  const centre = near ?? { lat: MAP_VIEW.center[1], lng: MAP_VIEW.center[0] };
  const url = new URL(SEARCH_API);
  url.searchParams.set('q', q);
  url.searchParams.set('limit', '25');
  url.searchParams.set('lang', 'en');
  url.searchParams.set('bbox', SEARCH_BBOX.join(','));
  url.searchParams.set('lat', String(centre.lat));
  url.searchParams.set('lon', String(centre.lng));

  const res = await fetch(url, { signal });
  if (!res.ok) throw new Error(`Search failed (${res.status})`);
  const data = await res.json();

  return rankResults(dedupe((data.features ?? []).map(toPlace)), q).slice(0, 12);
}

/**
 * OSM ranks purely by text match and distance, so a bus stop named "Wat Pho"
 * outranks the temple itself. Prefer destinations people actually go to, and
 * push minor street furniture down.
 */
const MINOR = new Set(['place']);
const WEAK_CATEGORIES = { transport: 0.4, place: 0.2, shop: 0.9 };

function rankResults(places, query) {
  const q = query.toLowerCase();
  return [...places].sort((a, b) => score(b) - score(a));

  function score(p) {
    const name = p.name.toLowerCase();
    let s = 1;
    if (name === q) s += 3;              // exact name match
    else if (name.startsWith(q)) s += 2; // "Wat Pho" for "wat pho"
    if (name.length > q.length * 3) s -= 0.5;  // long names are usually sub-features
    s *= WEAK_CATEGORIES[p.category] ?? 1.2;
    if (MINOR.has(p.category)) s -= 0.5;
    return s;
  }
}

/**
 * OSM often holds the same place as both a node and a way (a point and the
 * building outline). Collapse those into one result.
 */
function dedupe(places) {
  const seen = new Map();
  for (const place of places) {
    const key = `${place.name.toLowerCase()}@${place.lat.toFixed(3)},${place.lng.toFixed(3)}`;
    if (!seen.has(key)) seen.set(key, place);
  }
  return [...seen.values()];
}

/** Debounce wrapper that cancels the in-flight request when you keep typing. */
export function createSearcher({ onResults, onError, onBusy, delay = 280 }) {
  let timer = null;
  let controller = null;

  return {
    run(query, near) {
      clearTimeout(timer);
      controller?.abort();

      if (query.trim().length < 2) {
        onBusy?.(false);
        onResults([], query);
        return;
      }

      onBusy?.(true);
      timer = setTimeout(async () => {
        controller = new AbortController();
        try {
          const results = await searchPlaces(query, { signal: controller.signal, near });
          onBusy?.(false);
          onResults(results, query);
        } catch (err) {
          if (err.name === 'AbortError') return; // superseded by a newer keystroke
          onBusy?.(false);
          onError?.(err);
        }
      }, delay);
    },
    cancel() { clearTimeout(timer); controller?.abort(); onBusy?.(false); },
  };
}

/** A few starting points so the first screen is not a blank search box. */
export const SUGGESTIONS = [
  'Siam Paragon', 'Chatuchak Market', 'Wat Pho', 'Suvarnabhumi Airport',
  'Lumphini Park', 'Terminal 21', 'Hua Lamphong', 'ICONSIAM',
];
