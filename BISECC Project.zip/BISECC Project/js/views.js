// Screen rendering.

import { NEEDS, NEED_BY_ID, needLabel, needShort } from './data/needs.js';
import { CATEGORIES, FEATURE_KINDS } from './data/venues.js';
import { ATTR_BY_ID } from './data/attributes.js';
import * as store from './store.js';
import { createMap } from './map.js';
import { scoreVenue, STATUS_META, formatVerified, sourceLabel, weakestNeed } from './scoring.js';
import { APP_NAME, DISTRICT } from './config.js';
import { h, $, stars, toast, dialogShell } from './ui.js';
import { openContribute, openAddPlace, quickQuestions } from './contribute.js';
import { createSearcher, SUGGESTIONS } from './search.js';
import { needsPicker } from './needspicker.js';
import * as auth from './auth.js';

/**
 * The app has no name yet. Until APP_NAME is filled in (js/config.js) the header
 * shows a dashed, clearly-empty slot rather than inventing a placeholder name.
 */
export function renderBrand() {
  const name = APP_NAME.trim();
  const slot = $('#brand-name');
  const sub = $('#brand-sub');

  slot.className = name ? 'brand__name' : 'brand__name brand__name--empty';
  slot.textContent = name || 'Your app name';
  slot.title = name ? '' : 'Set APP_NAME in js/config.js';
  sub.textContent = DISTRICT;
  document.title = name ? `${name} — ${DISTRICT}` : `Accessibility map — ${DISTRICT}`;
}

// ---- shared bits ---------------------------------------------------------

const statusBadge = status =>
  h('span', { class: `badge badge--${status}`, text: STATUS_META[status].label });

const needChips = (ids, extra = '') =>
  h('span', { class: 'need-chips' }, ids.map(id =>
    h('span', { class: `need-chip ${extra}`, text: needShort(id) })));

// ---- onboarding ----------------------------------------------------------

export function renderOnboarding(root) {
  const picker = needsPicker({});

  const name = h('input', {
    class: 'field', id: 'name-input', type: 'text',
    placeholder: 'e.g. Ploy', autocomplete: 'given-name',
  });

  const start = () => {
    const { needs, custom } = picker.getValue();
    store.signIn(name.value, needs, custom);
  };

  root.replaceChildren(
    h('div', { class: 'onboarding' }, [
      h('p', { class: 'eyebrow', text: DISTRICT }),
      h('h1', { text: 'Accessibility is not one number.' }),
      h('p', { class: 'lede', text: 'A mall with a ramp can still be unusable if you are blind, and the touchscreen that shuts one person out is the reason another can order at all. So tell us how you get around, and every place gets a score out of 5 for you — not for an average person who does not exist.' }),
      h('p', { class: 'lede', text: 'Every place in and around Bangkok is here, straight from OpenStreetMap. What is not here yet is what any of them are actually like to get into — that part comes from people who go there.' }),

      h('label', { class: 'label', for: 'name-input', text: 'What should we call you?' }),
      name,

      h('label', { class: 'label', for: 'needs-input', text: 'How do you get around?' }),
      h('p', { class: 'hint', text: 'Type it in your own words — “wheelchair”, “I use a walking stick”, “cochlear implant”, “ผู้ใช้รถเข็น”. Pick from the list, or keep your own wording. Nobody else sees this unless you write a review.' }),
      picker,

      h('div', { class: 'onboarding__actions' }, [
        h('button', { class: 'btn btn--primary', type: 'button', text: 'Start', onclick: start }),
        h('button', {
          class: 'btn btn--ghost', type: 'button', text: 'Skip for now',
          onclick: () => store.signIn('Guest', [], []),
        }),
      ]),

      auth.isConfigured() ? h('div', { class: 'signin-note' }, [
        h('h2', { class: 'signin-note__head', text: 'Use it on your phone too' }),
        h('p', { class: 'hint', text: 'Create an account and your profile — and everything you contribute — follows you between devices.' }),
        h('div', { class: 'signin-note__actions' }, [
          h('button', { class: 'btn btn--signin', type: 'button', text: 'Create an account', onclick: () => openSignIn('signup') }),
          h('button', { class: 'btn btn--signin btn--signin-alt', type: 'button', text: 'Sign in', onclick: () => openSignIn('signin') }),
        ]),
      ]) : h('p', { class: 'hint signin-note', text: 'Running in local-only mode — your profile stays in this browser. Add Supabase keys in js/config.js to enable email sign-in and sync.' }),
    ]),
  );
}

// ---- sign in -------------------------------------------------------------

export function openSignIn(mode = 'signin') {
  const email = h('input', {
    class: 'field', type: 'email', id: 'email-input',
    placeholder: 'you@example.com', autocomplete: 'email', inputmode: 'email',
  });

  const password = h('input', {
    class: 'field', type: 'password', id: 'password-input',
    placeholder: 'At least 6 characters',
    autocomplete: mode === 'signup' ? 'new-password' : 'current-password',
  });

  // Showing the password is an accessibility feature, not a security hole:
  // typing a long password blind is hard with a tremor, low vision or dyslexia.
  const reveal = h('button', {
    class: 'reveal', type: 'button', text: 'Show', 'aria-label': 'Show password',
    onclick: () => {
      const hidden = password.type === 'password';
      password.type = hidden ? 'text' : 'password';
      reveal.textContent = hidden ? 'Hide' : 'Show';
      reveal.setAttribute('aria-label', hidden ? 'Hide password' : 'Show password');
      password.focus();
    },
  });

  const status = h('p', { class: 'auth-status', 'aria-live': 'polite' });
  const submit = h('button', { class: 'btn btn--primary', type: 'button' });

  const tabs = h('div', { class: 'tabs tabs--auth', role: 'tablist' }, [
    h('button', { class: 'tab', type: 'button', role: 'tab', text: 'Sign in', dataset: { mode: 'signin' } }),
    h('button', { class: 'tab', type: 'button', role: 'tab', text: 'Create account', dataset: { mode: 'signup' } }),
  ]);

  const forgot = h('button', {
    class: 'link-btn', type: 'button', text: 'Forgot your password?',
    onclick: async () => {
      if (!email.value.includes('@')) { email.focus(); setStatus('Enter your email address first.', 'error'); return; }
      try {
        await auth.sendPasswordReset(email.value);
        setStatus(`Reset link sent to ${email.value}.`, 'ok');
      } catch (err) {
        setStatus(err.message ?? 'Could not send the reset link.', 'error');
      }
    },
  });

  function setStatus(text, kind = '') {
    status.textContent = text;
    status.className = `auth-status${kind ? ' auth-status--' + kind : ''}`;
  }

  function setMode(next) {
    mode = next;
    for (const tab of tabs.children) {
      const on = tab.dataset.mode === mode;
      tab.classList.toggle('is-on', on);
      tab.setAttribute('aria-selected', String(on));
    }
    submit.textContent = mode === 'signup' ? 'Create my account' : 'Sign in';
    password.autocomplete = mode === 'signup' ? 'new-password' : 'current-password';
    password.placeholder = mode === 'signup' ? 'At least 6 characters' : 'Your password';
    forgot.hidden = mode === 'signup';
    setStatus('');
  }

  for (const tab of tabs.children) {
    tab.addEventListener('click', () => setMode(tab.dataset.mode));
  }

  const { close } = dialogShell({
    title: 'Sign in',
    subtitle: 'So your profile and what you contribute follow you between devices',
    content: [h('div', { class: 'cform dialog__body' }, [
      tabs,
      h('label', { class: 'label', for: 'email-input', text: 'Email address' }),
      email,
      h('label', { class: 'label', for: 'password-input', text: 'Password' }),
      h('div', { class: 'field-row' }, [password, reveal]),
      forgot,
      status,
    ])],
    footer: [submit],
  });

  const run = async () => {
    const mail = email.value.trim();
    const pass = password.value;

    if (!mail.includes('@')) { email.focus(); setStatus('That does not look like an email address.', 'error'); return; }
    if (pass.length < 6) { password.focus(); setStatus('Passwords need to be at least 6 characters.', 'error'); return; }

    submit.disabled = true;
    setStatus(mode === 'signup' ? 'Creating your account…' : 'Signing in…');

    try {
      if (mode === 'signup') {
        const { needsConfirmation } = await auth.signUpWithPassword(mail, pass);
        if (needsConfirmation) {
          setStatus(`Account created. Confirm it from the email sent to ${mail}, then sign in — after that it is password only.`, 'ok');
          submit.disabled = false;
          setMode('signin');
          return;
        }
      } else {
        await auth.signInWithPassword(mail, pass);
      }
      setStatus('Signed in.', 'ok');
      close();
      toast('Signed in — your contributions now sync');
    } catch (err) {
      setStatus(friendlyAuthError(err), 'error');
      submit.disabled = false;
    }
  };

  submit.addEventListener('click', run);
  password.addEventListener('keydown', e => { if (e.key === 'Enter') run(); });
  email.addEventListener('keydown', e => { if (e.key === 'Enter') password.focus(); });

  setMode(mode);
  email.focus();
}

/** Supabase's messages are terse; say what to actually do about it. */
function friendlyAuthError(err) {
  const msg = (err?.message ?? '').toLowerCase();
  if (msg.includes('invalid login credentials')) return 'That email and password do not match. Check the password, or create an account if you have not yet.';
  if (msg.includes('already registered') || msg.includes('already been registered')) return 'That email already has an account — switch to Sign in.';
  if (msg.includes('email not confirmed')) return 'Confirm your email first: check your inbox for the link we sent when you signed up.';
  if (msg.includes('rate limit') || msg.includes('too many')) return 'Too many attempts just now. Wait a minute and try again.';
  if (msg.includes('password')) return err.message;
  return err?.message ?? 'Something went wrong. Try again.';
}

// ---- map screen ----------------------------------------------------------

let mapInstance = null;
let query = '';
let results = [];
let searching = false;
let searchError = null;
let searcher = null;
let openVenue = () => {};

/**
 * The search field is created ONCE and never replaced.
 *
 * It used to be rebuilt on every render, which meant that the moment results
 * came back — about 300ms after you stopped typing — the input you were typing
 * into was destroyed and swapped for a new one. Focus and caret went with it,
 * so you had to click the box again for every word. Only #results-area and a
 * couple of text nodes are repainted now.
 */
export function renderMapScreen(root, { onOpenVenue }) {
  openVenue = id => {
    const found = results.find(r => r.id === id);
    if (found) store.rememberPlace(found);  // keep it before routing to it
    onOpenVenue(id);
  };

  if (!root.dataset.built) buildMapScreen(root);

  const needs = store.getNeeds();
  const hint = root.querySelector('#profile-hint');
  if (hint) {
    hint.textContent = needs.length
      ? `Scored for ${needs.map(needShort).join(', ').toLowerCase()}`
      : 'No profile set — set one to get your own scores';
  }

  refreshResults({ force: true });
}

function buildMapScreen(root) {
  const searchField = h('input', {
    class: 'field field--search', type: 'search', value: query,
    placeholder: 'Search any place in Bangkok — mall, temple, station, hospital…',
    'aria-label': 'Search for a place',
    autocomplete: 'off',
    oninput: e => {
      query = e.target.value;
      if (!query.trim()) results = [];
      searcher.run(query, mapCentre());
      setStatus(query.trim().length >= 2 ? 'Searching…' : '');
      refreshResults();
    },
  });

  root.replaceChildren(
    h('div', { class: 'map-wrap' }, [
      h('div', { id: 'map', class: 'map', role: 'application', 'aria-label': `Map of ${DISTRICT}` }),
      h('div', { class: 'map-tools' }, [
        h('button', { class: 'map-reset', type: 'button', text: 'Reset view', onclick: () => mapInstance.reset() }),
      ]),
      h('div', { class: 'map-legend' }, Object.entries(STATUS_META)
        .filter(([k]) => k !== 'sparse')
        .map(([, m]) => h('span', { class: 'legend-item' }, [
          h('i', { style: `background:${m.pin}` }), m.label,
        ]))),
    ]),

    h('div', { class: 'list-pane', id: 'venue-list' }, [
      h('div', { class: 'list-head' }, [
        h('div', {}, [
          h('h2', { text: 'Find a place' }),
          h('p', { class: 'hint', id: 'profile-hint' }),
        ]),
        h('button', {
          class: 'btn btn--ghost btn--small', type: 'button', text: '＋ Add a missing place',
          onclick: () => openAddPlace(mapCentre(), place => { refreshResults(); openVenue(place.id); }),
        }),
      ]),
      searchField,
      h('p', { class: 'hint', id: 'search-status', 'aria-live': 'polite' }),
      h('div', { id: 'results-area' }),
    ]),
  );

  mapInstance = createMap(root.querySelector('#map'), { onSelectVenue: id => openVenue(id) });

  searcher = createSearcher({
    onResults: (list, forQuery) => {
      if (forQuery.trim() !== query.trim()) return;  // a later keystroke won
      results = list;
      searchError = null;
      refreshResults();
      if (list.length) mapInstance?.fitTo(list, 60);
    },
    onError: err => { searchError = err.message; searching = false; setStatus(''); refreshResults(); },
    onBusy: busy => {
      searching = busy;
      setStatus(busy ? 'Searching…' : '');
    },
  });

  root.dataset.built = '1';
}

const setStatus = text => {
  const el = document.querySelector('#search-status');
  if (el) el.textContent = text;
};

/** Repaint the pins and the result list — never the search field. */
let lastPaint = '';

function refreshResults({ force = false } = {}) {
  const area = document.querySelector('#results-area');
  if (!area) return;

  const needs = store.getNeeds();
  const saved = store.placesWithData();
  const source = query.trim().length >= 2 ? results : saved;

  // Score each place once per paint, not once for the map and again for the list.
  const scored = new Map(source.map(v => [v.id, scoreVenue(v, needs)]));
  const score = v => scored.get(v.id) ?? scoreVenue(v, needs);

  // Typing "s", "si", "sia" does not change what is on screen until results come
  // back, and repainting 50+ markers and cards per keystroke is what made this
  // feel sluggish. Skip the work when the outcome would be identical.
  const signature = [
    query.trim().length >= 2 ? 'search' : 'saved',
    searching, searchError ?? '',
    source.map(v => `${v.id}:${scored.get(v.id)?.status}`).join(','),
  ].join('|');

  if (!force && signature === lastPaint) return;
  lastPaint = signature;

  mapInstance?.render(source, score);

  const listed = source
    .map(v => ({ v, r: score(v) }))
    .sort((a, b) => rank(b.r) - rank(a.r));

  area.replaceChildren(...resultsArea(saved, listed, openVenue));
}

function resultsArea(saved, listed, open) {
  const isSearching = query.trim().length >= 2;

  if (searchError) {
    return [h('div', { class: 'callout' }, [
      h('h3', { text: 'Search is unavailable' }),
      h('p', { text: `${searchError}. Check your connection — place search needs to reach OpenStreetMap.` }),
    ])];
  }

  if (!isSearching) {
    return [
      h('div', { class: 'callout' }, [
        h('h3', { text: 'Search for anywhere in Bangkok' }),
        h('p', { text: 'Every place in and around the city is here, straight from OpenStreetMap — malls, temples, BTS and MRT stations, hospitals, markets, universities. Find one you know and record what getting into it is actually like.' }),
        h('div', { class: 'suggests' }, SUGGESTIONS.map(name =>
          h('button', {
            class: 'suggest', type: 'button', text: name,
            onclick: () => {
              query = name;
              const field = document.querySelector('.field--search');
              if (field) { field.value = name; field.focus(); }
              setStatus('Searching…');
              searcher.run(query, mapCentre());
            },
          }))),
      ]),

      saved.length ? h('h3', { class: 'list-sub', text: `${saved.length} places with accessibility information` }) : null,
      saved.length ? h('p', { class: 'hint list-sub-note', text: 'Most of this is imported from OpenStreetMap and is thin — a step-free entrance recorded, nothing about toilets, lighting or staff. Open one and fill in what you know.' }) : null,
      ...listed.map(({ v, r }) => venueCard(v, r, open)),
    ];
  }

  return [
    listed.length
      ? h('p', { class: 'hint list-sub', text: `${listed.length} result${listed.length === 1 ? '' : 's'} near the map` })
      : h('div', { class: 'callout' }, [
          h('h3', { text: searching ? 'Searching…' : 'Nothing found' }),
          h('p', { text: searching ? 'Looking through OpenStreetMap.' : 'Try a shorter or differently spelled name — or add the place yourself if OpenStreetMap does not have it.' }),
        ]),
    ...listed.map(({ v, r }) => venueCard(v, r, open)),
  ];
}

const mapCentre = () => {
  const c = mapInstance?.map?.getCenter?.();
  return c ? { lat: c.lat, lng: c.lng } : { lat: MAP_VIEW.center[1], lng: MAP_VIEW.center[0] };
};

const rank = r => (r.status === 'blocked' ? -1 : r.stars ?? (r.coverage.known ? -0.4 : -0.5));

function venueCard(v, r, open) {
  const known = store.hasData(v.id);
  return h('button', {
    class: 'vcard', type: 'button',
    onclick: () => open(v.id),
    onmouseenter: () => mapInstance?.setSelected(v.id),
    onfocus: () => mapInstance?.setSelected(v.id),
  }, [
    h('span', { class: 'vcard__icon', 'aria-hidden': 'true', text: CATEGORIES[v.category]?.icon ?? '📍' }),
    h('span', { class: 'vcard__body' }, [
      h('span', { class: 'vcard__name' }, [
        v.name,
        v.mine ? h('span', { class: 'tag', text: 'added by you' }) : null,
      ]),
      h('span', { class: 'vcard__meta', text: `${CATEGORIES[v.category]?.label ?? 'Place'} · ${v.address}` }),
      known ? h('span', { class: 'vcard__score' }, [
        r.stars !== null ? stars(r.stars) : null,
        r.stars !== null ? h('b', { text: r.stars.toFixed(1) }) : null,
        statusBadge(r.status),
      ]) : null,
      known && r.stars === null
        ? h('span', { class: 'vcard__why', text: r.blocked
            ? r.blockers.map(b => b.text).join(' · ')
            : `Only ${r.coverage.known} of ${r.coverage.total} things known — not enough to rate` })
        : null,
      !known ? h('span', { class: 'vcard__why', text: 'Nothing recorded yet — tap to be the first' }) : null,
    ]),
  ]);
}

// ---- venue detail --------------------------------------------------------

let detailMap = null;
let detailVenueId = null;

/**
 * One Leaflet instance for the whole detail screen, reused across places.
 *
 * The page is rebuilt on every repaint, and the map used to be destroyed and
 * recreated with it — new panes, new tile layer, every tile fetched again — on
 * each place you opened and after every single question you answered. Keeping
 * one element and moving it into the fresh page avoids all of that; the tiles
 * are already there and only the pins change.
 */
let detailMapBox = null;

function detailMapElement() {
  detailMapBox ??= h('div', { class: 'map map--detail', role: 'application' });
  return detailMapBox;
}

export function renderVenueScreen(root, venueId, { onBack, rerender }) {
  const venue = store.venueById(venueId);
  if (!venue) { onBack(); return; }

  const needs = store.getNeeds();
  const r = scoreVenue(venue, needs);
  const cat = CATEGORIES[venue.category] ?? { label: '', icon: '📍' };
  const reviews = store.reviewsFor(venue.id);

  const mapBox = detailMapElement();
  mapBox.setAttribute('aria-label', `Map of ${venue.name} and its recorded features`);

  root.replaceChildren(
    h('div', { class: 'detail' }, [
      h('button', { class: 'btn btn--back', type: 'button', text: '← All places', onclick: onBack }),

      h('header', { class: 'detail__head' }, [
        h('p', { class: 'eyebrow', text: `${cat.icon} ${cat.label} · ${venue.address}` }),
        h('h1', { text: venue.name }),
      ]),

      scoreCard(r, needs),
      r.blocked ? blockerPanel(r) : null,

      contributeBar(venue, r, rerender),

      quickSection(venue, r, rerender),

      featuresSection(venue, mapBox, rerender),

      r.coverage.known > 0 ? section(`What is known so far${needs.length ? ', most relevant to you first' : ''}`, [
        h('ul', { class: 'rows' }, r.rows.filter(row => row.value).map(row => detailRow(row))),
      ]) : null,

      staleSection(venue, r, rerender),

      r.otherRows.length ? h('details', { class: 'other' }, [
        h('summary', { text: `Other details (${r.otherRows.length}) — not relevant to your profile` }),
        h('ul', { class: 'rows' }, r.otherRows.map(row => detailRow(row, true))),
      ]) : null,

      reviewsSection(venue, reviews, needs, rerender),
    ]),
  );

  const sameVenue = detailVenueId === venue.id;

  detailMap ??= createMap(mapBox, {
    onSelectVenue: () => {},
    onSelectFeature: (_v, f) => focusFeature(f),
  });
  detailMap.resize();                    // the element was just re-parented
  detailMap.render([venue], () => r);
  detailMap.setFocus(venue);
  if (!sameVenue) detailMap.fitTo([venue, ...venue.features], 70);
  detailVenueId = venue.id;

  // Only jump back to the top when you have actually arrived at a new place —
  // not every time you answer a question part-way down the page.
  if (!sameVenue) {
    root.scrollTop = 0;
    window.scrollTo(0, 0);
  }
}

function section(title, kids) {
  return h('section', { class: 'block' }, [h('h2', { text: title }), ...[].concat(kids)]);
}

function scoreCard(r, needs) {
  const worst = weakestNeed(r);
  const nothing = r.coverage.known === 0;

  return h('div', { class: `score-card score-card--${r.status}`, 'aria-live': 'polite' }, [
    h('div', { class: 'score-card__main' }, [
      h('div', { class: 'score-card__number' }, [
        r.stars === null ? h('span', { class: 'score-card__dash', text: '—' })
          : h('span', { class: 'score-card__value', text: r.stars.toFixed(1) }),
        h('span', { class: 'score-card__outof', text: '/ 5' }),
      ]),
      h('div', {}, [
        r.stars === null ? null : stars(r.stars),
        h('p', { class: 'score-card__label', text: nothing ? 'Nothing known yet' : r.blocked ? "You can't get in" : STATUS_META[r.status].label }),
        h('p', { class: 'score-card__for', text: needs.length
          ? `for ${needs.map(needShort).join(' · ').toLowerCase()}`
          : 'set your access needs to get your own score' }),
      ]),
    ]),
    h('div', { class: 'coverage' }, [
      h('div', { class: 'coverage__bar' }, [h('span', { style: `width:${r.coverage.pct}%` })]),
      h('p', { class: 'coverage__text', text: nothing
        ? `Nobody has recorded any of the ${r.coverage.total} things that matter to you here. An unknown is counted as unknown — never as fine.`
        : `We know ${r.coverage.known} of ${r.coverage.total} things that matter to you (${r.coverage.pct}% covered). Anything unknown is counted as unknown, never as fine.` }),
    ]),
    worst && !r.blocked && worst.score < 0.6
      ? h('p', { class: 'score-card__note', text: `Weakest for you: ${needShort(worst.id).toLowerCase()}.` })
      : null,
  ]);
}

function blockerPanel(r) {
  return h('div', { class: 'blockers' }, [
    h('h2', { text: r.blockers.length === 1 ? 'One thing stops you here' : `${r.blockers.length} things stop you here` }),
    h('p', { class: 'blockers__why', text: 'These are not low scores — they are hard stops, so no star rating is worth showing on its own.' }),
    h('ul', {}, r.blockers.map(b => h('li', {}, [
      h('b', { text: b.label + ': ' }), b.text,
      h('span', { class: 'need-chip need-chip--warn', text: `blocks ${needShort(b.needId).toLowerCase()}` }),
    ]))),
  ]);
}

/** The main way in to contributing — deliberately hard to miss. */
function contributeBar(venue, r, rerender) {
  const open = tab => openContribute(venue.id, tab, rerender);
  return h('div', { class: 'contribute-bar' }, [
    h('div', {}, [
      h('h2', { text: r.coverage.known === 0 ? 'Be the first to add something' : 'Add what you know' }),
      h('p', { class: 'hint', text: 'You do not have to know everything. One fact helps the next person.' }),
    ]),
    h('div', { class: 'contribute-bar__actions' }, [
      h('button', { class: 'btn btn--primary', type: 'button', text: 'Answer questions', onclick: () => open('facts') }),
      h('button', { class: 'btn btn--ghost', type: 'button', text: '📍 Add a detail to the map', onclick: () => open('feature') }),
      h('button', { class: 'btn btn--ghost', type: 'button', text: '✎ Write a review', onclick: () => open('review') }),
    ]),
  ]);
}

/** Two or three of the highest-impact unknowns, answerable inline. */
function quickSection(venue, r, rerender) {
  const gaps = r.rows.filter(row => !row.value).slice(0, 3);
  if (!gaps.length) return null;

  return h('div', { class: 'gaps', id: 'gaps' }, [
    h('h2', { text: 'Quick questions' }),
    h('p', { class: 'hint', text: 'The unknowns that affect your profile most. One tap each, and your score updates immediately.' }),
    ...quickQuestions(venue, gaps.map(g => g.attrId), rerender),
  ]);
}

function featuresSection(venue, mapBox, rerender) {
  const list = venue.features.length
    ? h('ul', { class: 'features' }, venue.features.map(f => featureRow(venue, f, rerender)))
    : h('div', { class: 'callout callout--quiet' }, [
        h('p', { text: 'No entrances, lifts or toilets have been placed here yet. If you know where the step-free way in is, put a pin on it — that single detail is often the difference between a wasted journey and a good one.' }),
        h('button', {
          class: 'btn btn--small', type: 'button', text: '📍 Add the first one',
          onclick: () => openContribute(venue.id, 'feature', rerender),
        }),
      ]);

  return section('Where exactly to go', [
    h('p', { class: 'hint', text: 'Entrances, toilets and lifts each get their own point, because “the building is accessible” is not directions.' }),
    h('div', { class: 'detail-map' }, [mapBox]),
    list,
  ]);
}

function focusFeature(f) {
  detailMap?.flyTo(f.lng, f.lat, 19);
  detailMap?.highlightFeature(f.name);
  document.querySelector('.detail-map')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function featureRow(venue, f, rerender) {
  const meta = FEATURE_KINDS[f.kind] ?? { label: f.kind, icon: '📍' };
  return h('li', { class: 'feature' }, [
    h('button', { class: 'feature__btn', type: 'button', onclick: () => focusFeature(f) }, [
      h('span', { class: 'feature__icon', 'aria-hidden': 'true', text: meta.icon }),
      h('span', {}, [
        h('span', { class: 'feature__name' }, [f.name, f.mine ? h('span', { class: 'tag', text: 'yours' }) : null]),
        h('span', { class: 'feature__kind', text: meta.label }),
        f.detail ? h('span', { class: 'feature__detail', text: f.detail }) : null,
        h('span', { class: 'feature__locate', text: 'Show me where ↗' }),
      ]),
    ]),
    f.mine ? h('button', {
      class: 'link-btn', type: 'button', text: 'Remove',
      onclick: () => { store.removeFeature(venue.id, f.id); toast('Removed'); rerender(); },
    }) : null,
  ]);
}

function detailRow(row, muted = false) {
  return h('li', { class: `row row--${row.tone}${muted ? ' row--muted' : ''}` }, [
    h('span', { class: 'row__dot', 'aria-hidden': 'true' }),
    h('span', { class: 'row__body' }, [
      h('span', { class: 'row__label', text: row.label }),
      h('span', { class: 'row__value', text: row.text ?? 'Not known yet' }),
      h('span', { class: 'row__foot' }, [
        row.needs.length ? needChips(row.needs) : null,
        row.verified ? h('span', {
          class: `row__verified${row.stale ? ' is-stale' : ''}`,
          text: `${sourceLabel(row.source)} · ${formatVerified(row.verified)}`,
        }) : null,
      ]),
    ]),
  ]);
}

function staleSection(venue, r, rerender) {
  const stale = r.rows.filter(row => row.stale && row.value);
  if (!stale.length) return null;
  return h('div', { class: 'stale' }, [
    h('h2', { text: 'Is this still true?' }),
    h('p', { class: 'hint', text: 'Accessibility data rots. Lifts break, ramps get removed in refits. These have not been checked in over a year — if you are here, you can settle it in one tap.' }),
    ...stale.map(row => h('div', { class: 'stale__item' }, [
      h('p', {}, [h('b', { text: row.label + ': ' }), row.text]),
      h('p', { class: 'hint', text: formatVerified(row.verified) }),
      h('div', { class: 'stale__actions' }, [
        h('button', {
          class: 'btn btn--small', type: 'button', text: 'Yes, still true',
          onclick: () => { store.confirmFact(venue.id, row.attrId); toast('Confirmed — thank you'); rerender(); },
        }),
        h('button', {
          class: 'btn btn--small btn--ghost', type: 'button', text: "No, it's changed",
          onclick: () => openContribute(venue.id, 'facts', rerender),
        }),
      ]),
    ])),
  ]);
}

function reviewsSection(venue, reviews, needs, rerender) {
  const mine = new Set(needs);

  return section(`Reviews${reviews.length ? ` (${reviews.length})` : ''}`, [
    reviews.length
      ? h('p', { class: 'hint', text: 'Every review says who wrote it. Reviews from people who share your access needs come first — four stars means nothing until you know whose four stars it is.' })
      : h('div', { class: 'callout callout--quiet' }, [
          h('p', { text: 'No reviews yet. If you have been here, say what getting in was actually like — and your review will be signed with your access needs so readers know whose experience it is.' }),
          h('button', {
            class: 'btn btn--small', type: 'button', text: '✎ Write the first review',
            onclick: () => openContribute(venue.id, 'review', rerender),
          }),
        ]),

    h('ul', { class: 'reviews' }, reviews.map(rev => {
      const shared = rev.needs.filter(n => mine.has(n));
      return h('li', { class: `review${shared.length ? ' review--match' : ''}` }, [
        h('div', { class: 'review__head' }, [
          h('div', {}, [
            h('b', { text: rev.author }),
            rev.needs.length ? needChips(rev.needs) : h('span', { class: 'hint', text: 'no access needs listed' }),
          ]),
          stars(rev.stars),
        ]),
        shared.length ? h('p', { class: 'review__match', text: `Shares your ${shared.map(needShort).join(' and ').toLowerCase()}` }) : null,
        h('p', { class: 'review__body', text: rev.body }),
        rev.mine ? h('button', {
          class: 'link-btn', type: 'button', text: 'Delete my review',
          onclick: () => { store.removeReview(rev.id); toast('Review deleted'); rerender(); },
        }) : null,
      ]);
    })),
  ]);
}

// ---- profile dialog ------------------------------------------------------

export function openProfileDialog() {
  const account = store.getAccount();
  const picker = needsPicker({ needs: account?.needs ?? [], custom: account?.custom ?? [] });
  const user = auth.getUser();

  const save = h('button', { class: 'btn btn--primary', type: 'button', text: 'Save profile' });

  const { close } = dialogShell({
    title: 'Your access profile',
    subtitle: 'Change this and every score is recalculated for the new you',
    content: [h('div', { class: 'cform dialog__body' }, [
      h('p', { class: 'cform__lead', text: 'Type how you get around. The same places, scored differently — that is the whole idea.' }),
      picker,

      h('div', { class: 'profile-meta' }, [
        h('p', { class: 'hint', text: `You have contributed ${store.contributionCount()} things so far.` }),
        auth.isConfigured()
          ? (user
            ? h('p', { class: 'hint', text: `Signed in as ${user.email} — your contributions sync to the cloud.` })
            : h('p', { class: 'hint' }, [
                'Not signed in — this stays in this browser. ',
                h('button', { class: 'link-btn', type: 'button', text: 'Sign in', onclick: () => { close(); openSignIn('signin'); } }),
              ]))
          : h('p', { class: 'hint', text: 'Local-only mode: add Supabase keys in js/config.js to sync between devices.' }),
      ]),

      h('div', { class: 'dialog__actions' }, [
        h('button', {
          class: 'btn btn--ghost', type: 'button', text: user ? 'Sign out' : 'Reset everything',
          onclick: async () => { close(); if (user) await auth.signOutCloud(); store.signOut(); },
        }),
      ]),
    ])],
    footer: [save],
  });

  save.addEventListener('click', () => {
    const { needs, custom } = picker.getValue();
    store.setNeeds(needs, custom);
    close();
  });
}

export function renderTopbar() {
  const account = store.getAccount();
  const btn = $('#profile-btn');
  if (!account) { btn.hidden = true; return; }
  btn.hidden = false;
  btn.replaceChildren(
    h('span', { class: 'avatar', 'aria-hidden': 'true', text: (account.name[0] ?? '?').toUpperCase() }),
    h('span', { class: 'profile-btn__text' }, [
      h('b', { text: account.name }),
      h('span', { text: account.needs.length ? account.needs.map(needShort).join(' · ') : 'No needs set' }),
    ]),
    h('span', { 'aria-hidden': 'true', text: '▾' }),
  );
  btn.setAttribute('aria-label', `Your profile: ${account.name}. ${account.needs.map(n => NEED_BY_ID[n]?.label ?? n).join(', ') || 'No access needs set'}. Change profile.`);
}
