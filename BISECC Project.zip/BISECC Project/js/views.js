// Screen rendering.

import { NEEDS, NEED_BY_ID, needLabel } from './data/needs.js';
import { CATEGORIES, FEATURE_KINDS } from './data/venues.js';
import { ATTR_BY_ID } from './data/attributes.js';
import * as store from './store.js';
import { createMap } from './map.js';
import { scoreVenue, STATUS_META, formatVerified, sourceLabel, weakestNeed } from './scoring.js';
import { APP_NAME, DISTRICT } from './config.js';
import { h, $, stars, toast, dialogShell } from './ui.js';
import { openContribute, openAddPlace, quickQuestions } from './contribute.js';
import { createSearcher, SUGGESTIONS } from './search.js';
import { needsPicker } from './needspicker.js';
import * as auth from './auth.js';

/**
 * The app has no name yet. Until APP_NAME is filled in (js/config.js) the header
 * shows a dashed, clearly-empty slot rather than inventing a placeholder name.
 */
export function renderBrand() {
  const name = APP_NAME.trim();
  const slot = $('#brand-name');
  const sub = $('#brand-sub');

  slot.className = name ? 'brand__name' : 'brand__name brand__name--empty';
  slot.textContent = name || 'Your app name';
  slot.title = name ? '' : 'Set APP_NAME in js/config.js';
  sub.textContent = DISTRICT;
  document.title = name ? `${name} — ${DISTRICT}` : `Accessibility map — ${DISTRICT}`;
}

// ---- shared bits ---------------------------------------------------------

const statusBadge = status =>
  h('span', { class: `badge badge--${status}`, text: STATUS_META[status].label });

const needChips = (ids, extra = '') =>
  h('span', { class: 'need-chips' }, ids.map(id =>
    h('span', { class: `need-chip ${extra}`, text: needLabel(id) })));

// ---- onboarding ----------------------------------------------------------

export function renderOnboarding(root) {
  const picker = needsPicker({});

  const name = h('input', {
    class: 'field', id: 'name-input', type: 'text',
    placeholder: 'e.g. Ploy', autocomplete: 'given-name',
  });

  const start = () => {
    const { needs, custom } = picker.getValue();
    store.signIn(name.value, needs, custom);
  };

  root.replaceChildren(
    h('div', { class: 'onboarding' }, [
      h('p', { class: 'eyebrow', text: DISTRICT }),
      h('h1', { text: 'Accessibility is not one number.' }),
      h('p', { class: 'lede', text: 'A mall with a ramp can still be unusable if you are blind, and the touchscreen that shuts one person out is the reason another can order at all. So tell us how you get around, and every place gets a score out of 5 for you — not for an average person who does not exist.' }),
      h('p', { class: 'lede', text: 'Every place in and around Bangkok is here, straight from OpenStreetMap. What is not here yet is what any of them are actually like to get into — that part comes from people who go there.' }),

      h('label', { class: 'label', for: 'name-input', text: 'What should we call you?' }),
      name,

      h('label', { class: 'label', for: 'needs-input', text: 'How do you get around?' }),
      h('p', { class: 'hint', text: 'Type it in your own words — “wheelchair”, “I use a walking stick”, “cochlear implant”, “ผู้ใช้รถเข็น”. Pick from the list, or keep your own wording. Nobody else sees this unless you write a review.' }),
      picker,

      h('div', { class: 'onboarding__actions' }, [
        h('button', { class: 'btn btn--primary', type: 'button', text: 'Start', onclick: start }),
        h('button', {
          class: 'btn btn--ghost', type: 'button', text: 'Skip for now',
          onclick: () => store.signIn('Guest', [], []),
        }),
      ]),

      auth.isConfigured() ? h('div', { class: 'signin-note' }, [
        h('p', { class: 'hint', text: 'Want your profile and contributions on all your devices?' }),
        h('button', { class: 'btn btn--small btn--ghost', type: 'button', text: '✉ Sign in by email', onclick: openSignIn }),
      ]) : h('p', { class: 'hint signin-note', text: 'Running in local-only mode — your profile stays in this browser. Add Supabase keys in js/config.js to enable email sign-in and sync.' }),
    ]),
  );
}

// ---- sign in -------------------------------------------------------------

export function openSignIn() {
  const email = h('input', {
    class: 'field', type: 'email', id: 'email-input',
    placeholder: 'you@example.com', autocomplete: 'email',
  });
  const status = h('p', { class: 'hint', 'aria-live': 'polite' });

  const send = h('button', { class: 'btn btn--primary', type: 'button', text: 'Email me a sign-in link' });

  const { close } = dialogShell({
    title: 'Sign in',
    subtitle: 'So your profile and what you contribute follow you between devices',
    content: [h('div', { class: 'cform dialog__body' }, [
      h('p', { class: 'cform__lead', text: 'We send a one-time link to your email. There is no password to choose or type — this app never handles one.' }),
      h('label', { class: 'label', for: 'email-input', text: 'Email address' }),
      email,
      status,
    ])],
    footer: [send],
  });

  send.addEventListener('click', async () => {
    const value = email.value.trim();
    if (!value.includes('@')) { email.focus(); status.textContent = 'That does not look like an email address.'; return; }
    send.disabled = true;
    status.textContent = 'Sending…';
    try {
      await auth.sendMagicLink(value);
      status.textContent = `Check ${value} — the link signs you straight in.`;
      send.textContent = 'Link sent';
      setTimeout(close, 2600);
    } catch (err) {
      status.textContent = err.message ?? 'Could not send the link.';
      send.disabled = false;
    }
  });
}

// ---- map screen ----------------------------------------------------------

let mapInstance = null;
let onlyWorkingForMe = false;
let query = '';
let results = [];
let searching = false;
let searchError = null;
let searcher = null;
let rerenderMap = () => {};

export function renderMapScreen(root, { onOpenVenue }) {
  rerenderMap = () => renderMapScreen(root, { onOpenVenue });

  const needs = store.getNeeds();
  const saved = store.placesWithData();
  const score = v => scoreVenue(v, needs);

  if (!root.dataset.built) {
    root.replaceChildren(
      h('div', { class: 'map-wrap' }, [
        h('div', { id: 'map', class: 'map', role: 'application', 'aria-label': `Map of ${DISTRICT}` }),
        h('div', { class: 'map-tools' }, [
          h('button', { class: 'map-reset', type: 'button', text: 'Reset view', onclick: () => mapInstance.reset() }),
        ]),
        h('div', { class: 'map-legend' }, Object.entries(STATUS_META)
          .filter(([k]) => k !== 'sparse')
          .map(([, m]) => h('span', { class: 'legend-item' }, [
            h('i', { style: `background:${m.pin}` }), m.label,
          ]))),
      ]),
      h('div', { class: 'list-pane', id: 'venue-list' }),
    );
    mapInstance = createMap(root.querySelector('#map'), { onSelectVenue: id => open(id) });
    root.dataset.built = '1';
  }

  function open(id) {
    const found = results.find(r => r.id === id);
    if (found) store.rememberPlace(found);   // keep it before routing to it
    onOpenVenue(id);
  }

  searcher ??= createSearcher({
    onResults: (list, forQuery) => {
      if (forQuery.trim() !== query.trim()) return;  // a later keystroke won
      results = list;
      searchError = null;
      rerenderMap();
      if (list.length) mapInstance?.fitTo(list, 60);
    },
    onError: err => { searchError = err.message; searching = false; rerenderMap(); },
    onBusy: busy => {
      if (busy === searching) return;
      searching = busy;
      const el = document.querySelector('#search-status');
      if (el) el.textContent = busy ? 'Searching…' : '';
    },
  });

  // The map shows search results while you are searching, your own places otherwise.
  const onMap = query.trim().length >= 2 ? results : saved;
  mapInstance.render(onMap, score);

  const listed = (query.trim().length >= 2 ? results : saved)
    .map(v => ({ v, r: score(v) }))
    .sort((a, b) => rank(b.r) - rank(a.r))
    .filter(({ r }) => !onlyWorkingForMe || r.status === 'good' || r.status === 'ok');

  const search = h('input', {
    class: 'field field--search', type: 'search', value: query,
    placeholder: 'Search any place in Bangkok — mall, temple, station, hospital…',
    'aria-label': 'Search for a place',
    autocomplete: 'off',
    oninput: e => {
      query = e.target.value;
      searcher.run(query, mapCentre());
      if (!query.trim()) { results = []; }
      const status = document.querySelector('#search-status');
      if (status) status.textContent = query.trim().length >= 2 ? 'Searching…' : '';
      updateResultsOnly(root, onOpenVenue);
    },
  });

  const list = root.querySelector('#venue-list');
  list.replaceChildren(
    h('div', { class: 'list-head' }, [
      h('div', {}, [
        h('h2', { text: 'Find a place' }),
        h('p', { class: 'hint', text: needs.length
          ? `Scored for ${needs.map(needLabel).join(', ').toLowerCase()}`
          : 'No profile set — set one to get your own scores' }),
      ]),
      h('button', {
        class: 'btn btn--ghost btn--small', type: 'button', text: '＋ Add a missing place',
        onclick: () => openAddPlace(mapCentre(), place => { rerenderMap(); onOpenVenue(place.id); }),
      }),
    ]),

    search,
    h('p', { class: 'hint', id: 'search-status' }),
    h('div', { id: 'results-area' }, resultsArea(saved, listed, open)),
  );
}

/** Repaint just the results, so typing never rebuilds the map. */
function updateResultsOnly(root, onOpenVenue) {
  const area = root.querySelector('#results-area');
  if (!area) return;
  const needs = store.getNeeds();
  const saved = store.placesWithData();
  const score = v => scoreVenue(v, needs);
  const listed = (query.trim().length >= 2 ? results : saved)
    .map(v => ({ v, r: score(v) }))
    .sort((a, b) => rank(b.r) - rank(a.r))
    .filter(({ r }) => !onlyWorkingForMe || r.status === 'good' || r.status === 'ok');

  area.replaceChildren(...resultsArea(saved, listed, id => {
    const found = results.find(r => r.id === id);
    if (found) store.rememberPlace(found);
    onOpenVenue(id);
  }));
}

function resultsArea(saved, listed, open) {
  const isSearching = query.trim().length >= 2;

  if (searchError) {
    return [h('div', { class: 'callout' }, [
      h('h3', { text: 'Search is unavailable' }),
      h('p', { text: `${searchError}. Check your connection — place search needs to reach OpenStreetMap.` }),
    ])];
  }

  if (!isSearching) {
    return [
      h('div', { class: 'callout' }, [
        h('h3', { text: 'Search for anywhere in Bangkok' }),
        h('p', { text: 'Every place in and around the city is here, straight from OpenStreetMap — malls, temples, BTS and MRT stations, hospitals, markets, universities. Find one you know and record what getting into it is actually like.' }),
        h('div', { class: 'suggests' }, SUGGESTIONS.map(name =>
          h('button', {
            class: 'suggest', type: 'button', text: name,
            onclick: () => {
              query = name;
              const field = document.querySelector('.field--search');
              if (field) field.value = name;
              searcher.run(query, mapCentre());
            },
          }))),
      ]),

      saved.length ? h('h3', { class: 'list-sub', text: `Places you have contributed to (${saved.length})` }) : null,
      ...listed.map(({ v, r }) => venueCard(v, r, open)),
    ];
  }

  return [
    listed.length
      ? h('p', { class: 'hint list-sub', text: `${listed.length} result${listed.length === 1 ? '' : 's'} near the map` })
      : h('div', { class: 'callout' }, [
          h('h3', { text: searching ? 'Searching…' : 'Nothing found' }),
          h('p', { text: searching ? 'Looking through OpenStreetMap.' : 'Try a shorter or differently spelled name — or add the place yourself if OpenStreetMap does not have it.' }),
        ]),
    ...listed.map(({ v, r }) => venueCard(v, r, open)),
  ];
}

const mapCentre = () => {
  const c = mapInstance?.map?.getCenter?.();
  return c ? { lat: c.lat, lng: c.lng } : { lat: MAP_VIEW.center[1], lng: MAP_VIEW.center[0] };
};

const rank = r => (r.status === 'blocked' ? -1 : r.stars ?? (r.coverage.known ? -0.4 : -0.5));

function venueCard(v, r, open) {
  const known = store.hasData(v.id);
  return h('button', {
    class: 'vcard', type: 'button',
    onclick: () => open(v.id),
    onmouseenter: () => mapInstance?.setSelected(v.id),
    onfocus: () => mapInstance?.setSelected(v.id),
  }, [
    h('span', { class: 'vcard__icon', 'aria-hidden': 'true', text: CATEGORIES[v.category]?.icon ?? '📍' }),
    h('span', { class: 'vcard__body' }, [
      h('span', { class: 'vcard__name' }, [
        v.name,
        v.mine ? h('span', { class: 'tag', text: 'added by you' }) : null,
      ]),
      h('span', { class: 'vcard__meta', text: `${CATEGORIES[v.category]?.label ?? 'Place'} · ${v.address}` }),
      known ? h('span', { class: 'vcard__score' }, [
        r.stars !== null ? stars(r.stars) : null,
        r.stars !== null ? h('b', { text: r.stars.toFixed(1) }) : null,
        statusBadge(r.status),
      ]) : null,
      known && r.stars === null
        ? h('span', { class: 'vcard__why', text: r.blocked
            ? r.blockers.map(b => b.text).join(' · ')
            : `Only ${r.coverage.known} of ${r.coverage.total} things known — not enough to rate` })
        : null,
      !known ? h('span', { class: 'vcard__why', text: 'Nothing recorded yet — tap to be the first' }) : null,
    ]),
  ]);
}

// ---- venue detail --------------------------------------------------------

let detailMap = null;
let detailVenueId = null;

export function renderVenueScreen(root, venueId, { onBack, rerender }) {
  const venue = store.venueById(venueId);
  if (!venue) { onBack(); return; }

  const needs = store.getNeeds();
  const r = scoreVenue(venue, needs);
  const cat = CATEGORIES[venue.category] ?? { label: '', icon: '📍' };
  const reviews = store.reviewsFor(venue.id);

  const mapBox = h('div', {
    class: 'map map--detail', role: 'application',
    'aria-label': `Map of ${venue.name} and its recorded features`,
  });

  root.replaceChildren(
    h('div', { class: 'detail' }, [
      h('button', { class: 'btn btn--back', type: 'button', text: '← All places', onclick: onBack }),

      h('header', { class: 'detail__head' }, [
        h('p', { class: 'eyebrow', text: `${cat.icon} ${cat.label} · ${venue.address}` }),
        h('h1', { text: venue.name }),
      ]),

      scoreCard(r, needs),
      r.blocked ? blockerPanel(r) : null,

      contributeBar(venue, r, rerender),

      quickSection(venue, r, rerender),

      featuresSection(venue, mapBox, rerender),

      r.coverage.known > 0 ? section(`What is known so far${needs.length ? ', most relevant to you first' : ''}`, [
        h('ul', { class: 'rows' }, r.rows.filter(row => row.value).map(row => detailRow(row))),
      ]) : null,

      staleSection(venue, r, rerender),

      r.otherRows.length ? h('details', { class: 'other' }, [
        h('summary', { text: `Other details (${r.otherRows.length}) — not relevant to your profile` }),
        h('ul', { class: 'rows' }, r.otherRows.map(row => detailRow(row, true))),
      ]) : null,

      reviewsSection(venue, reviews, needs, rerender),
    ]),
  );

  const sameVenue = detailVenueId === venue.id;
  detailMap?.destroy();
  detailMap = createMap(mapBox, {
    onSelectVenue: () => {},
    onSelectFeature: (_v, f) => focusFeature(f),
  });
  detailMap.render([venue], () => r);
  detailMap.setFocus(venue);
  detailMap.fitTo([venue, ...venue.features], 70);
  detailVenueId = venue.id;

  // Only jump back to the top when you have actually arrived at a new place —
  // not every time you answer a question part-way down the page.
  if (!sameVenue) {
    root.scrollTop = 0;
    window.scrollTo(0, 0);
  }
}

function section(title, kids) {
  return h('section', { class: 'block' }, [h('h2', { text: title }), ...[].concat(kids)]);
}

function scoreCard(r, needs) {
  const worst = weakestNeed(r);
  const nothing = r.coverage.known === 0;

  return h('div', { class: `score-card score-card--${r.status}`, 'aria-live': 'polite' }, [
    h('div', { class: 'score-card__main' }, [
      h('div', { class: 'score-card__number' }, [
        r.stars === null ? h('span', { class: 'score-card__dash', text: '—' })
          : h('span', { class: 'score-card__value', text: r.stars.toFixed(1) }),
        h('span', { class: 'score-card__outof', text: '/ 5' }),
      ]),
      h('div', {}, [
        r.stars === null ? null : stars(r.stars),
        h('p', { class: 'score-card__label', text: nothing ? 'Nothing known yet' : r.blocked ? "You can't get in" : STATUS_META[r.status].label }),
        h('p', { class: 'score-card__for', text: needs.length
          ? `for ${needs.map(needLabel).join(' · ').toLowerCase()}`
          : 'set your access needs to get your own score' }),
      ]),
    ]),
    h('div', { class: 'coverage' }, [
      h('div', { class: 'coverage__bar' }, [h('span', { style: `width:${r.coverage.pct}%` })]),
      h('p', { class: 'coverage__text', text: nothing
        ? `Nobody has recorded any of the ${r.coverage.total} things that matter to you here. An unknown is counted as unknown — never as fine.`
        : `We know ${r.coverage.known} of ${r.coverage.total} things that matter to you (${r.coverage.pct}% covered). Anything unknown is counted as unknown, never as fine.` }),
    ]),
    worst && !r.blocked && worst.score < 0.6
      ? h('p', { class: 'score-card__note', text: `Weakest for you: ${needLabel(worst.id).toLowerCase()}.` })
      : null,
  ]);
}

function blockerPanel(r) {
  return h('div', { class: 'blockers' }, [
    h('h2', { text: r.blockers.length === 1 ? 'One thing stops you here' : `${r.blockers.length} things stop you here` }),
    h('p', { class: 'blockers__why', text: 'These are not low scores — they are hard stops, so no star rating is worth showing on its own.' }),
    h('ul', {}, r.blockers.map(b => h('li', {}, [
      h('b', { text: b.label + ': ' }), b.text,
      h('span', { class: 'need-chip need-chip--warn', text: `blocks ${needLabel(b.needId).toLowerCase()}` }),
    ]))),
  ]);
}

/** The main way in to contributing — deliberately hard to miss. */
function contributeBar(venue, r, rerender) {
  const open = tab => openContribute(venue.id, tab, rerender);
  return h('div', { class: 'contribute-bar' }, [
    h('div', {}, [
      h('h2', { text: r.coverage.known === 0 ? 'Be the first to add something' : 'Add what you know' }),
      h('p', { class: 'hint', text: 'You do not have to know everything. One fact helps the next person.' }),
    ]),
    h('div', { class: 'contribute-bar__actions' }, [
      h('button', { class: 'btn btn--primary', type: 'button', text: 'Answer questions', onclick: () => open('facts') }),
      h('button', { class: 'btn btn--ghost', type: 'button', text: '📍 Add a detail to the map', onclick: () => open('feature') }),
      h('button', { class: 'btn btn--ghost', type: 'button', text: '✎ Write a review', onclick: () => open('review') }),
    ]),
  ]);
}

/** Two or three of the highest-impact unknowns, answerable inline. */
function quickSection(venue, r, rerender) {
  const gaps = r.rows.filter(row => !row.value).slice(0, 3);
  if (!gaps.length) return null;

  return h('div', { class: 'gaps', id: 'gaps' }, [
    h('h2', { text: 'Quick questions' }),
    h('p', { class: 'hint', text: 'The unknowns that affect your profile most. One tap each, and your score updates immediately.' }),
    ...quickQuestions(venue, gaps.map(g => g.attrId), rerender),
  ]);
}

function featuresSection(venue, mapBox, rerender) {
  const list = venue.features.length
    ? h('ul', { class: 'features' }, venue.features.map(f => featureRow(venue, f, rerender)))
    : h('div', { class: 'callout callout--quiet' }, [
        h('p', { text: 'No entrances, lifts or toilets have been placed here yet. If you know where the step-free way in is, put a pin on it — that single detail is often the difference between a wasted journey and a good one.' }),
        h('button', {
          class: 'btn btn--small', type: 'button', text: '📍 Add the first one',
          onclick: () => openContribute(venue.id, 'feature', rerender),
        }),
      ]);

  return section('Where exactly to go', [
    h('p', { class: 'hint', text: 'Entrances, toilets and lifts each get their own point, because “the building is accessible” is not directions.' }),
    h('div', { class: 'detail-map' }, [mapBox]),
    list,
  ]);
}

function focusFeature(f) {
  detailMap?.flyTo(f.lng, f.lat, 19);
  detailMap?.highlightFeature(f.name);
  document.querySelector('.detail-map')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function featureRow(venue, f, rerender) {
  const meta = FEATURE_KINDS[f.kind] ?? { label: f.kind, icon: '📍' };
  return h('li', { class: 'feature' }, [
    h('button', { class: 'feature__btn', type: 'button', onclick: () => focusFeature(f) }, [
      h('span', { class: 'feature__icon', 'aria-hidden': 'true', text: meta.icon }),
      h('span', {}, [
        h('span', { class: 'feature__name' }, [f.name, f.mine ? h('span', { class: 'tag', text: 'yours' }) : null]),
        h('span', { class: 'feature__kind', text: meta.label }),
        f.detail ? h('span', { class: 'feature__detail', text: f.detail }) : null,
        h('span', { class: 'feature__locate', text: 'Show me where ↗' }),
      ]),
    ]),
    f.mine ? h('button', {
      class: 'link-btn', type: 'button', text: 'Remove',
      onclick: () => { store.removeFeature(venue.id, f.id); toast('Removed'); rerender(); },
    }) : null,
  ]);
}

function detailRow(row, muted = false) {
  return h('li', { class: `row row--${row.tone}${muted ? ' row--muted' : ''}` }, [
    h('span', { class: 'row__dot', 'aria-hidden': 'true' }),
    h('span', { class: 'row__body' }, [
      h('span', { class: 'row__label', text: row.label }),
      h('span', { class: 'row__value', text: row.text ?? 'Not known yet' }),
      h('span', { class: 'row__foot' }, [
        row.needs.length ? needChips(row.needs.map(n => n.id)) : null,
        row.verified ? h('span', {
          class: `row__verified${row.stale ? ' is-stale' : ''}`,
          text: `${sourceLabel(row.source)} · ${formatVerified(row.verified)}`,
        }) : null,
      ]),
    ]),
  ]);
}

function staleSection(venue, r, rerender) {
  const stale = r.rows.filter(row => row.stale && row.value);
  if (!stale.length) return null;
  return h('div', { class: 'stale' }, [
    h('h2', { text: 'Is this still true?' }),
    h('p', { class: 'hint', text: 'Accessibility data rots. Lifts break, ramps get removed in refits. These have not been checked in over a year — if you are here, you can settle it in one tap.' }),
    ...stale.map(row => h('div', { class: 'stale__item' }, [
      h('p', {}, [h('b', { text: row.label + ': ' }), row.text]),
      h('p', { class: 'hint', text: formatVerified(row.verified) }),
      h('div', { class: 'stale__actions' }, [
        h('button', {
          class: 'btn btn--small', type: 'button', text: 'Yes, still true',
          onclick: () => { store.confirmFact(venue.id, row.attrId); toast('Confirmed — thank you'); rerender(); },
        }),
        h('button', {
          class: 'btn btn--small btn--ghost', type: 'button', text: "No, it's changed",
          onclick: () => openContribute(venue.id, 'facts', rerender),
        }),
      ]),
    ])),
  ]);
}

function reviewsSection(venue, reviews, needs, rerender) {
  const mine = new Set(needs);

  return section(`Reviews${reviews.length ? ` (${reviews.length})` : ''}`, [
    reviews.length
      ? h('p', { class: 'hint', text: 'Every review says who wrote it. Reviews from people who share your access needs come first — four stars means nothing until you know whose four stars it is.' })
      : h('div', { class: 'callout callout--quiet' }, [
          h('p', { text: 'No reviews yet. If you have been here, say what getting in was actually like — and your review will be signed with your access needs so readers know whose experience it is.' }),
          h('button', {
            class: 'btn btn--small', type: 'button', text: '✎ Write the first review',
            onclick: () => openContribute(venue.id, 'review', rerender),
          }),
        ]),

    h('ul', { class: 'reviews' }, reviews.map(rev => {
      const shared = rev.needs.filter(n => mine.has(n));
      return h('li', { class: `review${shared.length ? ' review--match' : ''}` }, [
        h('div', { class: 'review__head' }, [
          h('div', {}, [
            h('b', { text: rev.author }),
            rev.needs.length ? needChips(rev.needs) : h('span', { class: 'hint', text: 'no access needs listed' }),
          ]),
          stars(rev.stars),
        ]),
        shared.length ? h('p', { class: 'review__match', text: `Shares your ${shared.map(needLabel).join(' and ').toLowerCase()}` }) : null,
        h('p', { class: 'review__body', text: rev.body }),
        rev.mine ? h('button', {
          class: 'link-btn', type: 'button', text: 'Delete my review',
          onclick: () => { store.removeReview(rev.id); toast('Review deleted'); rerender(); },
        }) : null,
      ]);
    })),
  ]);
}

// ---- profile dialog ------------------------------------------------------

export function openProfileDialog() {
  const account = store.getAccount();
  const picker = needsPicker({ needs: account?.needs ?? [], custom: account?.custom ?? [] });
  const user = auth.getUser();

  const save = h('button', { class: 'btn btn--primary', type: 'button', text: 'Save profile' });

  const { close } = dialogShell({
    title: 'Your access profile',
    subtitle: 'Change this and every score is recalculated for the new you',
    content: [h('div', { class: 'cform dialog__body' }, [
      h('p', { class: 'cform__lead', text: 'Type how you get around. The same places, scored differently — that is the whole idea.' }),
      picker,

      h('div', { class: 'profile-meta' }, [
        h('p', { class: 'hint', text: `You have contributed ${store.contributionCount()} things so far.` }),
        auth.isConfigured()
          ? (user
            ? h('p', { class: 'hint', text: `Signed in as ${user.email} — your contributions sync to the cloud.` })
            : h('p', { class: 'hint' }, [
                'Not signed in — this stays in this browser. ',
                h('button', { class: 'link-btn', type: 'button', text: 'Sign in by email', onclick: () => { close(); openSignIn(); } }),
              ]))
          : h('p', { class: 'hint', text: 'Local-only mode: add Supabase keys in js/config.js to sync between devices.' }),
      ]),

      h('div', { class: 'dialog__actions' }, [
        h('button', {
          class: 'btn btn--ghost', type: 'button', text: user ? 'Sign out' : 'Reset everything',
          onclick: async () => { close(); if (user) await auth.signOutCloud(); store.signOut(); },
        }),
      ]),
    ])],
    footer: [save],
  });

  save.addEventListener('click', () => {
    const { needs, custom } = picker.getValue();
    store.setNeeds(needs, custom);
    close();
  });
}

export function renderTopbar() {
  const account = store.getAccount();
  const btn = $('#profile-btn');
  if (!account) { btn.hidden = true; return; }
  btn.hidden = false;
  btn.replaceChildren(
    h('span', { class: 'avatar', 'aria-hidden': 'true', text: (account.name[0] ?? '?').toUpperCase() }),
    h('span', { class: 'profile-btn__text' }, [
      h('b', { text: account.name }),
      h('span', { text: account.needs.length ? account.needs.map(needLabel).join(' · ') : 'No needs set' }),
    ]),
    h('span', { 'aria-hidden': 'true', text: '▾' }),
  );
  btn.setAttribute('aria-label', `Your profile: ${account.name}. ${account.needs.map(n => NEED_BY_ID[n].label).join(', ') || 'No access needs set'}. Change profile.`);
}
