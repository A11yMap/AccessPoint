// Account, access preferences, and everything users contribute.
//
// In this prototype all contributions live in localStorage on the one device —
// there is no server, so nothing is shared between people yet. The shape below
// is what a real backend would store, so swapping localStorage for an API is a
// change to this file only.

import { VENUES } from './data/venues.js';
import { REVIEWS, sortReviewsForProfile } from './data/reviews.js';

const KEY = 'accessmap.bkk.v1';

const DEFAULT_STATE = {
  account: null,       // { name, needs: [], custom: [] }
  contributions: {},   // { [venueId]: { [attrId]: value } }
  confirmations: {},   // { [venueId]: { [attrId]: 'YYYY-MM-DD' } }
  features: {},        // { [venueId]: [ { id, kind, name, detail, lat, lng, added } ] }
  reviews: [],         // [ { id, venueId, author, needs, stars, body, date } ]
  places: [],          // places discovered via search or added by hand
};

let state = load();
const listeners = new Set();

function load() {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return { ...structuredClone(DEFAULT_STATE), ...JSON.parse(raw) };
  } catch { /* corrupt or blocked storage — fall through to defaults */ }
  return structuredClone(DEFAULT_STATE);
}

function save() {
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
  } catch { /* private browsing — the app still works, it just won't persist */ }
}

function emit() {
  save();
  for (const fn of listeners) fn(state);
}

export const subscribe = fn => { listeners.add(fn); return () => listeners.delete(fn); };

// ---- optional cloud adapter ---------------------------------------------
// app.js injects this once Supabase is configured and signed in. The store
// never imports auth.js, so local-only mode has no cloud code in its path.

let cloud = null;
export function connectCloud(adapter) { cloud = adapter; }
export const isCloudConnected = () => Boolean(cloud);

const push = (kind, placeId, payload, place) => {
  try { cloud?.push({ kind, placeId, payload, place }); } catch (e) { console.warn('cloud push failed', e); }
};

/**
 * Fold everyone's contributions (from the shared table) into local state.
 * Remote rows lose their `mine` flag unless they were written by this user, so
 * the UI only offers deletion of your own.
 */
export function applyRemote(rows, myUserId) {
  for (const row of rows) {
    const mine = row.user_id === myUserId;
    const id = row.place_id;

    if (row.place && !state.places.some(p => p.id === id)) {
      state.places.push({ ...row.place, id, attrs: {}, features: [], mine: false });
    }

    if (row.kind === 'fact') {
      state.contributions[id] ??= {};
      // Last write wins; rows arrive newest-first, so do not overwrite.
      state.contributions[id][row.payload.attrId] ??= row.payload.value;
    } else if (row.kind === 'feature') {
      state.features[id] ??= [];
      if (!state.features[id].some(f => f.id === row.payload.id)) {
        state.features[id].push({ ...row.payload, mine });
      }
    } else if (row.kind === 'review') {
      if (!state.reviews.some(r => r.id === row.payload.id)) {
        state.reviews.push({ ...row.payload, venueId: id, mine });
      }
    }
  }
  emit();
}

const today = () => new Date().toISOString().slice(0, 10);
const uid = prefix => `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;

// ---- account -------------------------------------------------------------

export const getState = () => state;
export const getAccount = () => state.account;
export const getNeeds = () => state.account?.needs ?? [];
export const isSignedIn = () => Boolean(state.account);

export function signIn(name, needs, custom = []) {
  state.account = { name: name.trim() || 'Guest', needs: [...needs], custom: [...custom] };
  emit();
}

export function signOut() {
  state = structuredClone(DEFAULT_STATE);
  emit();
}

export function setNeeds(needs, custom) {
  if (!state.account) return;
  state.account.needs = [...needs];
  if (custom) state.account.custom = [...custom];
  emit();
}

export const getCustomNeeds = () => state.account?.custom ?? [];

/** Replace local state wholesale — used when a signed-in profile arrives from the cloud. */
export function hydrate(patch) {
  state = { ...state, ...patch };
  emit();
}

// ---- facts ---------------------------------------------------------------

/** Record (or change) a fact a user reported about a venue. */
export function contribute(venueId, attrId, value) {
  state.contributions[venueId] ??= {};
  if (value === null) delete state.contributions[venueId][attrId];
  else state.contributions[venueId][attrId] = value;
  if (value !== null) push('fact', venueId, { attrId, value }, placeIdentity(venueId));
  emit();
}

/** Re-confirm an existing fact that had gone stale. */
export function confirmFact(venueId, attrId) {
  state.confirmations[venueId] ??= {};
  state.confirmations[venueId][attrId] = today();
  emit();
}

export const myAnswer = (venueId, attrId) => state.contributions[venueId]?.[attrId] ?? null;

export const hasContributed = (venueId, attrId) =>
  Boolean(state.contributions[venueId]?.[attrId] || state.confirmations[venueId]?.[attrId]);

export const contributionCount = () =>
  Object.values(state.contributions).reduce((n, o) => n + Object.keys(o).length, 0)
  + Object.values(state.features).reduce((n, a) => n + a.length, 0)
  + state.reviews.length
  + state.places.length;

// ---- located features ----------------------------------------------------

/** Add an entrance / lift / toilet / obstacle at its own coordinates. */
export function addFeature(venueId, { kind, name, detail, lat, lng }) {
  state.features[venueId] ??= [];
  const feature = {
    id: uid('f'), kind, name: name.trim(), detail: detail.trim(),
    lat: Number(lat), lng: Number(lng), added: today(), mine: true,
  };
  state.features[venueId].push(feature);
  push('feature', venueId, feature, placeIdentity(venueId));
  emit();
  return feature;
}

export function removeFeature(venueId, featureId) {
  state.features[venueId] = (state.features[venueId] ?? []).filter(f => f.id !== featureId);
  emit();
}

// ---- reviews -------------------------------------------------------------

export function addReview(venueId, { stars, body }) {
  const review = {
    id: uid('r'), venueId,
    author: state.account?.name ?? 'Anonymous',
    needs: [...(state.account?.needs ?? [])],
    custom: [...(state.account?.custom ?? [])],
    stars: Number(stars), body: body.trim(), date: today(), mine: true,
  };
  state.reviews.unshift(review);
  push('review', venueId, review, placeIdentity(venueId));
  emit();
  return review;
}

export function removeReview(reviewId) {
  state.reviews = state.reviews.filter(r => r.id !== reviewId);
  emit();
}

/** Seeded reviews plus everything written here, most relevant to you first. */
export function reviewsFor(venueId) {
  const all = [...REVIEWS, ...state.reviews].filter(r => r.venueId === venueId);
  return sortReviewsForProfile(all, getNeeds());
}

// ---- places --------------------------------------------------------------

/**
 * Keep a place found through search, so it survives a reload and shows on the
 * map. Called as soon as someone opens a search result — the record is just an
 * identity until they add facts to it.
 */
export function rememberPlace(place) {
  const existing = state.places.find(p => p.id === place.id);
  if (existing) return existing;
  const saved = { ...place, fromSearch: true, seen: today() };
  state.places.push(saved);
  emit();
  return saved;
}

/** Places worth showing on the map: anything with information recorded on it. */
export function placesWithData() {
  const touched = p =>
    Object.keys(state.contributions[p.id] ?? {}).length > 0
    || (state.features[p.id] ?? []).length > 0
    || state.reviews.some(r => r.venueId === p.id)
    || p.mine;

  const seeded = VENUES.filter(p => Object.keys(p.attrs).length > 0 || p.features.length > 0 || touched(p));
  const added = state.places.filter(p => touched(p) && !seeded.some(s => s.id === p.id));
  return [...seeded, ...added].map(withContributions);
}

/** Add a place that search could not find. */
export function addPlace({ name, category, address, lat, lng }) {
  const place = {
    id: uid('p'), name: name.trim(), category,
    address: address.trim() || 'Added by a user',
    lat: Number(lat), lng: Number(lng),
    attrs: {}, features: [], updated: today(), source: 'community', mine: true,
  };
  state.places.push(place);
  push('place', place.id, { added: place.updated }, placeIdentity(place.id));
  emit();
  return place;
}

export function removePlace(placeId) {
  state.places = state.places.filter(p => p.id !== placeId);
  delete state.contributions[placeId];
  delete state.features[placeId];
  state.reviews = state.reviews.filter(r => r.venueId !== placeId);
  emit();
}

/** The bare identity of a place, sent alongside a contribution so others can find it. */
function placeIdentity(id) {
  const p = state.places.find(x => x.id === id) ?? VENUES.find(x => x.id === id);
  if (!p) return null;
  const { name, category, address, lat, lng } = p;
  return { name, category, address, lat, lng };
}

// ---- reading venues back with contributions merged in --------------------

/**
 * A venue with this user's contributions folded in, so a fact they add on the
 * venue page immediately changes the score and the map colour.
 */
export function withContributions(venue) {
  const added = state.contributions[venue.id];
  const confirmed = state.confirmations[venue.id];
  const extraFeatures = state.features[venue.id];
  if (!added && !confirmed && !extraFeatures) return venue;

  const attrs = { ...venue.attrs };
  for (const [attrId, value] of Object.entries(added ?? {})) {
    attrs[attrId] = [value, today(), 'community'];
  }
  for (const attrId of Object.keys(confirmed ?? {})) {
    const raw = attrs[attrId];
    const value = Array.isArray(raw) ? raw[0] : raw;
    if (value !== undefined) attrs[attrId] = [value, confirmed[attrId], 'community'];
  }

  return { ...venue, attrs, features: [...venue.features, ...(extraFeatures ?? [])] };
}

export const allVenues = () => [...VENUES, ...state.places].map(withContributions);

/** Has this place had anything recorded about it? */
export const hasData = id =>
  Object.keys(state.contributions[id] ?? {}).length > 0
  || (state.features[id] ?? []).length > 0
  || state.reviews.some(r => r.venueId === id);

export function venueById(id) {
  const v = VENUES.find(x => x.id === id) ?? state.places.find(x => x.id === id);
  return v ? withContributions(v) : null;
}
