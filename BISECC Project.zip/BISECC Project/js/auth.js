// Sign-in and cloud sync, via Supabase.
//
// CONFIGURE IT in js/config.js (SUPABASE.url and SUPABASE.anonKey), and run the
// SQL in supabase-schema.sql against your project. Until then the app runs in
// local-only mode: everything still works, it is just kept in this browser and
// nothing is shared between people.
//
// Sign-in is a magic link by email — no password is ever typed into this app,
// and the anon key is a public key, safe to ship in the page.

import { SUPABASE } from './config.js';

let client = null;
let currentUser = null;
const authListeners = new Set();

export const isConfigured = () =>
  Boolean(SUPABASE.url && SUPABASE.anonKey && !SUPABASE.url.includes('YOUR-PROJECT'));

export const getUser = () => currentUser;
export const onAuthChange = fn => { authListeners.add(fn); return () => authListeners.delete(fn); };
const emitAuth = () => { for (const fn of authListeners) fn(currentUser); };

/** Boot the client and pick up an existing session. Safe to call when unconfigured. */
export async function initAuth() {
  if (!isConfigured()) return null;

  const lib = window.supabase;
  if (!lib?.createClient) {
    console.warn('Supabase library did not load — staying in local-only mode.');
    return null;
  }

  client = lib.createClient(SUPABASE.url, SUPABASE.anonKey);

  const { data } = await client.auth.getSession();
  currentUser = data?.session?.user ?? null;

  client.auth.onAuthStateChange((_event, session) => {
    currentUser = session?.user ?? null;
    emitAuth();
  });

  emitAuth();
  return currentUser;
}

/** Email a one-time sign-in link. Resolves when the mail is on its way. */
export async function sendMagicLink(email) {
  if (!client) throw new Error('Cloud sign-in is not configured yet.');
  const { error } = await client.auth.signInWithOtp({
    email: email.trim(),
    options: { emailRedirectTo: location.href.split('#')[0] },
  });
  if (error) throw error;
}

export async function signOutCloud() {
  await client?.auth.signOut();
  currentUser = null;
  emitAuth();
}

// ---- profile + contributions --------------------------------------------

/** Read this user's saved profile. */
export async function loadProfile() {
  if (!client || !currentUser) return null;
  const { data, error } = await client
    .from('profiles').select('name, needs, custom_needs')
    .eq('id', currentUser.id).maybeSingle();
  if (error) { console.warn('profile load failed:', error.message); return null; }
  return data ? { name: data.name, needs: data.needs ?? [], custom: data.custom_needs ?? [] } : null;
}

export async function saveProfile({ name, needs, custom }) {
  if (!client || !currentUser) return;
  const { error } = await client.from('profiles').upsert({
    id: currentUser.id,
    name,
    needs,
    custom_needs: custom ?? [],
    updated_at: new Date().toISOString(),
  });
  if (error) console.warn('profile save failed:', error.message);
}

/**
 * Everyone's contributions, not just this user's — that is the point of putting
 * them in a shared database rather than localStorage.
 */
export async function loadContributions() {
  if (!client) return [];
  const { data, error } = await client
    .from('contributions').select('*')
    .order('created_at', { ascending: false }).limit(2000);
  if (error) { console.warn('contributions load failed:', error.message); return []; }
  return data ?? [];
}

export async function pushContribution({ kind, placeId, payload, place }) {
  if (!client || !currentUser) return null;
  const { data, error } = await client.from('contributions').insert({
    user_id: currentUser.id,
    place_id: placeId,
    kind,                       // fact | feature | review | place
    payload,
    place: place ?? null,       // identity of the place, so others can find it
  }).select().single();
  if (error) { console.warn('contribution save failed:', error.message); return null; }
  return data;
}

export async function deleteContribution(id) {
  if (!client || !currentUser) return;
  const { error } = await client.from('contributions').delete().eq('id', id);
  if (error) console.warn('contribution delete failed:', error.message);
}
