// Sign-in and cloud sync, via Supabase.
//
// CONFIGURE IT in js/config.js (SUPABASE.url and SUPABASE.anonKey), and run the
// SQL in supabase-schema.sql against your project. Until then the app runs in
// local-only mode: everything still works, it is just kept in this browser and
// nothing is shared between people.
//
// Sign-in is email + password. Passwords go straight to Supabase over HTTPS and
// are never stored, logged or kept by this app. The anon key is a public key,
// safe to ship in the page — Row Level Security is what protects the data.

import { SUPABASE } from './config.js';

let client = null;
let currentUser = null;
const authListeners = new Set();

export const isConfigured = () =>
  Boolean(SUPABASE.url && SUPABASE.anonKey && !SUPABASE.url.includes('YOUR-PROJECT'));

export const getUser = () => currentUser;
export const onAuthChange = fn => { authListeners.add(fn); return () => authListeners.delete(fn); };
const emitAuth = () => { for (const fn of authListeners) fn(currentUser); };

/** Boot the client and pick up an existing session. Safe to call when unconfigured. */
export async function initAuth() {
  if (!isConfigured()) return null;

  const lib = window.supabase;
  if (!lib?.createClient) {
    console.warn('Supabase library did not load — staying in local-only mode.');
    return null;
  }

  client = lib.createClient(SUPABASE.url, SUPABASE.anonKey);

  const { data } = await client.auth.getSession();
  currentUser = data?.session?.user ?? null;

  client.auth.onAuthStateChange((_event, session) => {
    currentUser = session?.user ?? null;
    emitAuth();
  });

  emitAuth();
  return currentUser;
}

const requireClient = () => {
  if (!client) throw new Error('Cloud sign-in is not configured yet.');
  return client;
};

/**
 * Create an account. If the project requires email confirmation, Supabase
 * returns no session and sends one confirmation mail — after that it is
 * password-only, with no further email.
 */
export async function signUpWithPassword(email, password) {
  const { data, error } = await requireClient().auth.signUp({
    email: email.trim(),
    password,
    options: { emailRedirectTo: location.href.split('#')[0] },
  });
  if (error) throw error;
  return { needsConfirmation: !data.session, user: data.user };
}

/** Sign in with a password. No email involved. */
export async function signInWithPassword(email, password) {
  const { data, error } = await requireClient().auth.signInWithPassword({
    email: email.trim(),
    password,
  });
  if (error) throw error;
  return data.user;
}

/** The one case that still needs email: a forgotten password. */
export async function sendPasswordReset(email) {
  const { error } = await requireClient().auth.resetPasswordForEmail(email.trim(), {
    redirectTo: location.href.split('#')[0],
  });
  if (error) throw error;
}

export async function signOutCloud() {
  await client?.auth.signOut();
  currentUser = null;
  emitAuth();
}

// ---- profile + contributions --------------------------------------------

/** Read this user's saved profile. */
export async function loadProfile() {
  if (!client || !currentUser) return null;
  const { data, error } = await client
    .from('profiles').select('name, needs, custom_needs')
    .eq('id', currentUser.id).maybeSingle();
  if (error) { console.warn('profile load failed:', error.message); return null; }
  return data ? { name: data.name, needs: data.needs ?? [], custom: data.custom_needs ?? [] } : null;
}

export async function saveProfile({ name, needs, custom }) {
  if (!client || !currentUser) return;
  const { error } = await client.from('profiles').upsert({
    id: currentUser.id,
    name,
    needs,
    custom_needs: custom ?? [],
    updated_at: new Date().toISOString(),
  });
  if (error) console.warn('profile save failed:', error.message);
}

/**
 * Everyone's contributions, not just this user's — that is the point of putting
 * them in a shared database rather than localStorage.
 */
export async function loadContributions() {
  if (!client) return [];
  const { data, error } = await client
    .from('contributions').select('*')
    .order('created_at', { ascending: false }).limit(2000);
  if (error) { console.warn('contributions load failed:', error.message); return []; }
  return data ?? [];
}

export async function pushContribution({ kind, placeId, payload, place }) {
  if (!client || !currentUser) return null;
  const { data, error } = await client.from('contributions').insert({
    user_id: currentUser.id,
    place_id: placeId,
    kind,                       // fact | feature | review | place
    payload,
    place: place ?? null,       // identity of the place, so others can find it
  }).select().single();
  if (error) { console.warn('contribution save failed:', error.message); return null; }
  return data;
}

export async function deleteContribution(id) {
  if (!client || !currentUser) return;
  const { error } = await client.from('contributions').delete().eq('id', id);
  if (error) console.warn('contribution delete failed:', error.message);
}
