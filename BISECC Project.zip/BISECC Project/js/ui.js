// Small shared UI helpers: element building, star display, dialogs, toasts.

/** Terse DOM builder. h('p', { class: 'x', onclick: fn }, ['text', node]) */
export function h(tag, props = {}, kids = []) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (v === false || v === null || v === undefined) continue;
    if (k === 'class') node.className = v;
    else if (k === 'html') node.innerHTML = v;
    else if (k === 'text') node.textContent = v;
    else if (k.startsWith('on')) node.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'dataset') Object.assign(node.dataset, v);
    else node.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of [].concat(kids)) {
    if (kid === null || kid === undefined || kid === false) continue;
    node.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }
  return node;
}

export const $ = sel => document.querySelector(sel);

/** Five stars with a partial fill, e.g. 4.3 of 5. */
export function stars(value) {
  const pct = value === null || value === undefined ? 0 : (value / 5) * 100;
  return h('span', {
    class: 'stars', role: 'img',
    'aria-label': value === null || value === undefined ? 'Not rated' : `${value} out of 5`,
  }, [
    h('span', { class: 'stars__bg', 'aria-hidden': 'true', text: '★★★★★' }),
    h('span', { class: 'stars__fg', 'aria-hidden': 'true', style: `width:${pct}%`, text: '★★★★★' }),
  ]);
}

/**
 * A modal dialog with a sticky header and optional sticky footer.
 * Returns { dialog, close } — the dialog removes itself when closed.
 */
export function dialogShell({ title, subtitle, content = [], footer = null, onClose }) {
  const close = () => dialog.close();

  const dialog = h('dialog', { class: 'sheet' }, [
    h('div', { class: 'dialog__head' }, [
      h('div', { class: 'dialog__titles' }, [
        h('h2', { text: title }),
        subtitle ? h('p', { class: 'hint', text: subtitle }) : null,
      ]),
      h('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Close', text: '✕', onclick: close }),
    ]),
    ...[].concat(content),
    footer ? h('div', { class: 'dialog__foot' }, footer) : null,
  ]);

  dialog.addEventListener('close', () => {
    onClose?.();
    dialog.remove();
  });
  // Clicking the backdrop (outside the panel) closes it.
  dialog.addEventListener('click', e => { if (e.target === dialog) close(); });

  document.body.append(dialog);
  dialog.showModal();
  return { dialog, close };
}

/** Brief confirmation message. Announced to screen readers as well as shown. */
let toastTimer = null;
export function toast(message) {
  let el = $('#toast');
  if (!el) {
    el = h('div', { id: 'toast', class: 'toast', role: 'status', 'aria-live': 'polite' });
    document.body.append(el);
  }
  el.textContent = message;
  el.classList.add('is-on');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('is-on'), 2600);
}
