// Everything a user can add.
//
// With no seeded accessibility data, this is the centre of the app: facts about
// a place, precisely-located features, reviews, and places that are missing from
// the map entirely.

import { NEEDS, needShort } from './data/needs.js';
import { ATTRIBUTES, ATTR_BY_ID, GROUPS, appliesToVenue } from './data/attributes.js';
import { CATEGORIES, FEATURE_KINDS } from './data/venues.js';
import * as store from './store.js';
import { createPicker } from './map.js';
import { h, dialogShell, toast } from './ui.js';

/** Relevance of an attribute to the signed-in person, 0 if irrelevant. */
function relevanceOf(attr, needs) {
  const active = needs.length ? needs : NEEDS.map(n => n.id);
  return Math.max(0, ...active.map(id => attr.needs[id]?.w ?? 0));
}

// ---- facts ---------------------------------------------------------------

export function factsPanel(venue, onChange) {
  const needs = store.getNeeds();
  const relevant = ATTRIBUTES.filter(a => appliesToVenue(a, venue));

  const answered = relevant.filter(a => venue.attrs[a.id] !== undefined).length;

  const panel = h('div', { class: 'cform' }, [
    h('p', { class: 'cform__lead', text: `${answered} of ${relevant.length} answered. Tap an answer — it saves straight away, and you can change it later.` }),
  ]);

  // Questions that matter to the signed-in person come first, then the rest by group.
  const mine = relevant.filter(a => relevanceOf(a, needs) > 0)
    .sort((a, b) => relevanceOf(b, needs) - relevanceOf(a, needs));
  const others = relevant.filter(a => relevanceOf(a, needs) === 0);

  if (mine.length) {
    panel.append(
      h('h3', { class: 'cform__head', text: needs.length ? 'Questions that affect you' : 'Questions' }),
      ...mine.map(attr => question(venue, attr, onChange)),
    );
  }
  if (others.length) {
    const more = h('details', { class: 'cform__more' }, [
      h('summary', { text: `Everything else (${others.length}) — not relevant to your profile, but useful to others` }),
      ...others.map(attr => question(venue, attr, onChange)),
    ]);
    panel.append(more);
  }
  return panel;
}

function question(venue, attr, onChange) {
  const current = venue.attrs[attr.id];
  const currentValue = Array.isArray(current) ? current[0] : current;
  const isMine = store.myAnswer(venue.id, attr.id) !== null;

  const opts = h('div', { class: 'qopts' }, Object.entries(attr.values).map(([value, text]) =>
    h('button', {
      class: `qopt${value === currentValue ? ' is-on' : ''}`,
      type: 'button',
      'aria-pressed': String(value === currentValue),
      onclick: () => {
        // Tapping the current answer clears it, so a mistake is undoable.
        store.contribute(venue.id, attr.id, value === currentValue && isMine ? null : value);
        toast(value === currentValue && isMine ? 'Answer removed' : 'Saved — thank you');
        onChange();
      },
    }, text)));

  return h('div', { class: `question${currentValue ? ' is-answered' : ''}` }, [
    h('div', { class: 'question__head' }, [
      h('span', { class: 'question__label', text: attr.label }),
      h('span', { class: 'question__group', text: attr.group }),
    ]),
    opts,
    // Undo was there all along but invisible — nobody guesses that tapping the
    // highlighted answer again removes it.
    isMine ? h('p', { class: 'question__undo', text: 'You answered this — tap it again to remove your answer' }) : null,
  ]);
}

/** A few questions rendered inline on the venue page, outside the dialog. */
export function quickQuestions(venue, attrIds, onChange) {
  return attrIds.map(id => question(venue, ATTR_BY_ID[id], onChange));
}

// ---- a located feature ---------------------------------------------------

export function featurePanel(venue, onChange) {
  let kind = 'entrance';
  let picker = null;

  const kindRow = h('div', { class: 'chip-grid chip-grid--tight' },
    Object.entries(FEATURE_KINDS).map(([id, meta]) => {
      const btn = h('button', {
        class: `chip chip--sm${id === kind ? ' is-on' : ''}`, type: 'button',
        'aria-pressed': String(id === kind),
        onclick: () => {
          kind = id;
          for (const b of kindRow.children) b.classList.remove('is-on');
          btn.classList.add('is-on');
          if (!name.value) name.placeholder = defaultName(id);
        },
      }, [h('span', { 'aria-hidden': 'true', text: meta.icon }), meta.label]);
      return btn;
    }));

  const name = h('input', { class: 'field', type: 'text', id: 'feat-name', placeholder: defaultName('entrance') });
  const detail = h('textarea', {
    class: 'field', id: 'feat-detail', rows: '3',
    placeholder: 'Describe it precisely. Width, number of steps, which side, opening hours, whether staff help. "Step-free, door about 90cm, on the Soi 19 side" beats "accessible".',
  });

  const mapBox = h('div', { class: 'picker__map' });
  const coordLabel = h('p', { class: 'hint picker__coords' });

  const panel = h('div', { class: 'cform' }, [
    h('p', { class: 'cform__lead', text: 'Entrances, lifts, toilets and obstacles each get their own point on the map — so the app can send someone to the right door rather than to the middle of the building.' }),

    h('p', { class: 'label', text: 'What is it?' }),
    kindRow,

    h('label', { class: 'label', for: 'feat-name', text: 'Name it' }),
    name,

    h('label', { class: 'label', for: 'feat-detail', text: 'Details' }),
    detail,

    h('p', { class: 'label', text: 'Where exactly?' }),
    h('p', { class: 'hint', text: 'Move the map so the crosshair sits on it. Zoom right in — this is the whole point.' }),
    h('div', { class: 'picker' }, [mapBox, h('span', { class: 'picker__cross', 'aria-hidden': 'true' })]),
    h('div', { class: 'picker__actions' }, [
      h('button', {
        class: 'btn btn--small btn--ghost', type: 'button', text: '📍 Use my location',
        onclick: e => useMyLocation(picker, e.target),
      }),
      coordLabel,
    ]),

    h('button', {
      class: 'btn btn--primary cform__save', type: 'button', text: 'Add this detail',
      onclick: () => {
        if (!name.value.trim()) { name.focus(); toast('Give it a name first'); return; }
        const { lat, lng } = picker.getValue();
        store.addFeature(venue.id, { kind, name: name.value, detail: detail.value, lat, lng });
        toast('Added to the map — thank you');
        onChange();
      },
    }),
  ]);

  // The map needs to exist in the document before Leaflet can measure it.
  queueMicrotask(() => {
    picker = createPicker(mapBox, { lat: venue.lat, lng: venue.lng });
    const update = () => {
      const { lat, lng } = picker.getValue();
      coordLabel.textContent = `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
    };
    picker.map?.on('move', update);
    update();
    panel.cleanup = () => picker?.destroy();
  });

  return panel;
}

const defaultName = kind => ({
  entrance: 'e.g. Side entrance on Soi 19',
  toilet: 'e.g. Accessible toilet, 2nd floor',
  lift: 'e.g. Lift to the BTS concourse',
  ramp: 'e.g. Ramp at the north gate',
  parking: 'e.g. Accessible parking bays',
  seating: 'e.g. Benches with armrests',
  quiet: 'e.g. Quiet room near the library',
  counter: 'e.g. Lowered service counter',
  obstacle: 'e.g. Broken kerb, no dropped edge',
}[kind] ?? 'Name this feature');

function useMyLocation(picker, btn) {
  if (!navigator.geolocation) { toast('This browser cannot find your location'); return; }
  const original = btn.textContent;
  btn.textContent = 'Finding you…';
  btn.disabled = true;
  navigator.geolocation.getCurrentPosition(
    pos => {
      picker?.setValue(pos.coords.latitude, pos.coords.longitude);
      btn.textContent = original;
      btn.disabled = false;
    },
    () => {
      toast('Could not get your location — move the map instead');
      btn.textContent = original;
      btn.disabled = false;
    },
    { enableHighAccuracy: true, timeout: 8000 },
  );
}

// ---- review --------------------------------------------------------------

export function reviewPanel(venue, onChange) {
  const account = store.getAccount();
  let rating = 0;

  const starRow = h('div', { class: 'star-pick', role: 'radiogroup', 'aria-label': 'Your rating' },
    [1, 2, 3, 4, 5].map(n => h('button', {
      class: 'star-pick__btn', type: 'button', role: 'radio',
      'aria-checked': 'false', 'aria-label': `${n} star${n > 1 ? 's' : ''}`,
      text: '★',
      onclick: () => {
        rating = n;
        [...starRow.children].forEach((b, i) => {
          b.classList.toggle('is-on', i < n);
          b.setAttribute('aria-checked', String(i + 1 === n));
        });
      },
    })));

  const body = h('textarea', {
    class: 'field', id: 'review-body', rows: '5',
    placeholder: 'What was getting in like? The toilets? Ordering, signage, staff? Say what you found, not just whether you liked it.',
  });

  return h('div', { class: 'cform' }, [
    h('p', { class: 'cform__lead' }, [
      'Your review is signed with your access needs, so readers know whose experience this is. Posting as ',
      h('b', { text: account?.name ?? 'Guest' }),
      account?.needs?.length
        ? h('span', { class: 'need-chips' }, account.needs.map(n => h('span', { class: 'need-chip', text: needShort(n) })))
        : ' — no access needs set.',
    ]),

    h('p', { class: 'label', text: 'Your rating' }),
    starRow,

    h('label', { class: 'label', for: 'review-body', text: 'Your review' }),
    body,

    h('button', {
      class: 'btn btn--primary cform__save', type: 'button', text: 'Post review',
      onclick: () => {
        if (!rating) { toast('Pick a rating first'); return; }
        if (body.value.trim().length < 10) { body.focus(); toast('Add a little more detail'); return; }
        store.addReview(venue.id, { stars: rating, body: body.value });
        toast('Review posted — thank you');
        onChange();
      },
    }),
  ]);
}

// ---- the contribute dialog ----------------------------------------------

const TABS = [
  { id: 'facts', label: 'Accessibility facts', build: factsPanel },
  { id: 'feature', label: 'Add a detail to the map', build: featurePanel },
  { id: 'review', label: 'Write a review', build: reviewPanel },
];

export function openContribute(venueId, startTab = 'facts', onChange = () => {}) {
  const venue = store.venueById(venueId);
  if (!venue) return;

  let active = startTab;
  let current = null;

  const body = h('div', { class: 'dialog__body' });
  const tabRow = h('div', { class: 'tabs', role: 'tablist' }, TABS.map(t =>
    h('button', {
      class: `tab${t.id === active ? ' is-on' : ''}`, type: 'button', role: 'tab',
      'aria-selected': String(t.id === active), text: t.label,
      onclick: () => { active = t.id; paint(); },
    })));

  const { dialog, close } = dialogShell({
    title: venue.name,
    subtitle: `${CATEGORIES[venue.category]?.label ?? ''} · ${venue.address}`,
    content: [tabRow, body],
    onClose: () => current?.cleanup?.(),
  });

  function paint() {
    current?.cleanup?.();
    for (const btn of tabRow.children) {
      const on = btn.textContent === TABS.find(t => t.id === active).label;
      btn.classList.toggle('is-on', on);
      btn.setAttribute('aria-selected', String(on));
    }
    const fresh = store.venueById(venueId);
    current = TABS.find(t => t.id === active).build(fresh, () => {
      onChange();
      if (active === 'facts') paint();  // refresh the counter and highlights
      else { close(); }
    });
    body.replaceChildren(current);
    body.scrollTop = 0;
  }

  paint();
  return dialog;
}

// ---- add a missing place -------------------------------------------------

export function openAddPlace(center, onAdded = () => {}) {
  let category = 'cafe';
  let picker = null;

  const name = h('input', { class: 'field', type: 'text', id: 'place-name', placeholder: 'e.g. Somtam Nua, Siam Square' });
  const address = h('input', { class: 'field', type: 'text', id: 'place-address', placeholder: 'Street and district, e.g. Siam Square Soi 5, Pathum Wan' });

  const catRow = h('div', { class: 'chip-grid chip-grid--tight' },
    Object.entries(CATEGORIES).map(([id, meta]) => {
      const btn = h('button', {
        class: `chip chip--sm${id === category ? ' is-on' : ''}`, type: 'button',
        'aria-pressed': String(id === category),
        onclick: () => {
          category = id;
          for (const b of catRow.children) b.classList.remove('is-on');
          btn.classList.add('is-on');
        },
      }, [h('span', { 'aria-hidden': 'true', text: meta.icon }), meta.label]);
      return btn;
    }));

  const mapBox = h('div', { class: 'picker__map' });
  const coordLabel = h('p', { class: 'hint picker__coords' });

  const content = h('div', { class: 'cform' }, [
    h('p', { class: 'cform__lead', text: 'Missing somewhere? Put it on the map. You can then start adding what you know about getting into it.' }),

    h('label', { class: 'label', for: 'place-name', text: 'Name' }),
    name,

    h('p', { class: 'label', text: 'What kind of place?' }),
    catRow,

    h('label', { class: 'label', for: 'place-address', text: 'Address' }),
    address,

    h('p', { class: 'label', text: 'Where is it?' }),
    h('p', { class: 'hint', text: 'Move the map so the crosshair sits on the building.' }),
    h('div', { class: 'picker' }, [mapBox, h('span', { class: 'picker__cross', 'aria-hidden': 'true' })]),
    h('div', { class: 'picker__actions' }, [
      h('button', {
        class: 'btn btn--small btn--ghost', type: 'button', text: '📍 Use my location',
        onclick: e => useMyLocation(picker, e.target),
      }),
      coordLabel,
    ]),
  ]);

  const save = h('button', { class: 'btn btn--primary', type: 'button', text: 'Add this place' });

  const { close } = dialogShell({
    title: 'Add a place',
    subtitle: 'It appears on the map straight away',
    content: [content],
    footer: [save],
    onClose: () => picker?.destroy(),
  });

  save.addEventListener('click', () => {
    if (!name.value.trim()) { name.focus(); toast('Give the place a name'); return; }
    const { lat, lng } = picker.getValue();
    const place = store.addPlace({ name: name.value, category, address: address.value, lat, lng });
    picker?.destroy();
    close();
    toast(`${place.name} added — thank you`);
    onAdded(place);
  });

  queueMicrotask(() => {
    picker = createPicker(mapBox, center);
    const update = () => {
      const { lat, lng } = picker.getValue();
      coordLabel.textContent = `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
    };
    picker.map?.on('move', update);
    update();
  });
}
