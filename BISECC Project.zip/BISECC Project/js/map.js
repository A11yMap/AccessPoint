// Real map: Leaflet over OpenStreetMap tiles.
//
// Deliberately raster + DOM tiles rather than a WebGL vector map. Tiles are
// plain <img> elements, so the map paints on any machine and in any embed with
// no GPU requirement — a blank map in front of an audience is not a risk worth
// taking for slightly crisper labels.
//
// Venue pins are coloured by how the place scores FOR THE CURRENT USER, so
// changing your access profile visibly repaints the neighbourhood.
//
// Feature pins (entrances, toilets, lifts, parking) sit at their own real
// coordinates — that is what lets the app point at the step-free door rather
// than at the middle of the building.

import { STATUS_META } from './scoring.js';
import { CATEGORIES, FEATURE_KINDS } from './data/venues.js';
import { BASEMAP, MAP_VIEW } from './config.js';

export function createMap(container, { onSelectVenue, onSelectFeature, interactive = true } = {}) {
  const L = window.L;
  if (!L) {
    container.innerHTML = '<p class="map-error">Map library did not load. Check your connection and reload.</p>';
    return stub();
  }

  const map = L.map(container, {
    center: [MAP_VIEW.center[1], MAP_VIEW.center[0]],
    zoom: Math.round(MAP_VIEW.zoom),
    minZoom: MAP_VIEW.minZoom,
    maxZoom: MAP_VIEW.maxZoom,
    zoomControl: false,
    dragging: interactive,
    scrollWheelZoom: interactive,
  });

  if (interactive) L.control.zoom({ position: 'bottomright' }).addTo(map);

  L.tileLayer(BASEMAP.tiles, {
    attribution: BASEMAP.attribution,
    maxZoom: MAP_VIEW.maxZoom,
    // detectRetina doubles the tile count for a sharpness nobody is asking for
    // on a map full of pins.
    detectRetina: false,

    // Tile buffering. Leaflet's defaults are tuned to spare the tile server,
    // which shows up as grey edges appearing as you drag.
    keepBuffer: 4,            // rows/columns kept loaded beyond the viewport (default 2)
    updateWhenIdle: false,    // fetch while panning, not only once you stop
    updateWhenZooming: false, // one update at the end of a zoom, instead of thrashing mid-animation
    updateInterval: 100,      // react twice as often as the 200ms default
  }).addTo(map);

  if (interactive) prefetchNeighbouringZooms(map);

  // Leaflet measures its container on creation; if it has not been laid out yet
  // (or the pane is resized later) the tile grid is wrong, so keep them in step.
  const ro = new ResizeObserver(() => map.invalidateSize());
  ro.observe(container);
  // Layout can settle after creation (web fonts, late grid sizing, a hidden tab
  // becoming visible). Without this the tile grid is computed for the wrong box
  // and the map paints as a half-loaded strip.
  const nudges = [0, 120, 400, 1000].map(t => setTimeout(() => map.invalidateSize(), t));
  map.whenReady(() => map.invalidateSize());

  let venueMarkers = new Map();
  let featureMarkers = [];
  let selectedId = null;

  function pinIcon({ icon, colour, kind }) {
    const size = kind === 'venue' ? [34, 42] : [28, 34];
    return L.divIcon({
      className: '',
      html: `<span class="pin pin--${kind}" style="--pin-colour:${colour}">
               <span class="pin__dot"><span class="pin__icon">${icon}</span></span>
             </span>`,
      iconSize: size,
      iconAnchor: [size[0] / 2, size[1]],
    });
  }

  function clearFeatures() {
    for (const m of featureMarkers) m.remove();
    featureMarkers = [];
  }

  return {
    map,

    /**
     * Reconcile the pins rather than rebuilding them.
     *
     * This used to remove every marker and make new ones on each call, which
     * meant tearing down and recreating fifty-odd DOM nodes for a repaint where
     * usually nothing had moved. Now: keep what is still there, restyle only the
     * pins whose status actually changed, add what is new, drop what is gone.
     */
    render(venues, scoreFn) {
      const wanted = new Set();

      for (const v of venues) {
        wanted.add(v.id);
        const { status } = scoreFn(v);
        const meta = STATUS_META[status];
        const existing = venueMarkers.get(v.id);

        if (existing) {
          if (existing.pinStatus !== status) {
            existing.setIcon(pinIcon({ icon: CATEGORIES[v.category]?.icon ?? '\u{1F4CD}', colour: meta.pin, kind: 'venue' }));
            existing.pinStatus = status;
            if (v.id === selectedId) existing.getElement()?.classList.add('is-selected');
          }
          continue;
        }

        const marker = L.marker([v.lat, v.lng], {
          icon: pinIcon({ icon: CATEGORIES[v.category]?.icon ?? '\u{1F4CD}', colour: meta.pin, kind: 'venue' }),
          keyboard: true,
          title: `${v.name} — ${meta.label}`,
          alt: `${v.name} — ${meta.label}`,
          riseOnHover: true,
        }).addTo(map);
        marker.pinStatus = status;
        marker.on('click', () => onSelectVenue?.(v.id));
        marker.on('keypress', e => {
          if (e.originalEvent?.key === 'Enter') onSelectVenue?.(v.id);
        });
        if (v.id === selectedId) marker.getElement()?.classList.add('is-selected');
        venueMarkers.set(v.id, marker);
      }

      for (const [id, marker] of venueMarkers) {
        if (!wanted.has(id)) { marker.remove(); venueMarkers.delete(id); }
      }
    },

    setSelected(id) {
      selectedId = id;
      for (const [vid, marker] of venueMarkers) {
        marker.getElement()?.classList.toggle('is-selected', vid === id);
      }
    },

    /** Drop a pin on every located feature of this venue. */
    setFocus(venue) {
      clearFeatures();
      if (!venue) return;
      for (const f of venue.features) {
        const meta = FEATURE_KINDS[f.kind] ?? { label: f.kind, icon: '\u{1F4CD}' };
        const marker = L.marker([f.lat, f.lng], {
          icon: pinIcon({ icon: meta.icon, colour: 'var(--feature-pin)', kind: 'feature' }),
          title: `${f.name} — ${venue.name}`,
          alt: `${f.name} — ${venue.name}`,
        }).addTo(map);
        marker.bindTooltip(f.name, { direction: 'top', offset: [0, -34] });
        marker.on('click', () => onSelectFeature?.(venue, f));
        marker.featureName = f.name;
        featureMarkers.push(marker);
      }
    },

    highlightFeature(name) {
      for (const m of featureMarkers) {
        const on = m.featureName === name;
        m.getElement()?.classList.toggle('is-selected', on);
        if (on) m.openTooltip();
      }
    },

    flyTo(lng, lat, zoom = 19) {
      map.flyTo([lat, lng], Math.min(zoom, MAP_VIEW.maxZoom), { duration: 0.9 });
    },

    fitTo(points, padding = 60) {
      if (!points.length) return;
      const bounds = L.latLngBounds(points.map(p => [p.lat, p.lng]));
      map.fitBounds(bounds, { padding: [padding, padding], maxZoom: 18, animate: false });
    },

    reset() {
      map.flyTo([MAP_VIEW.center[1], MAP_VIEW.center[0]], Math.round(MAP_VIEW.zoom), { duration: 0.9 });
    },
    resize() { map.invalidateSize(); },
    destroy() {
      clearFeatures();
      ro.disconnect();
      for (const id of nudges) clearTimeout(id);
      map.remove();
    },
  };
}

/**
 * A small map for choosing a point: the crosshair is fixed in the middle of the
 * box (drawn in CSS) and you move the map under it. Same pattern as every "drop
 * a pin" flow on a phone, and far easier one-handed than dragging a marker.
 */
export function createPicker(container, start) {
  const L = window.L;
  if (!L) {
    container.innerHTML = '<p class="map-error">Map library did not load.</p>';
    return { getValue: () => ({ ...start }), setValue() {}, destroy() {} };
  }

  const map = L.map(container, {
    center: [start.lat, start.lng],
    zoom: 18,
    zoomControl: true,
    attributionControl: false,
  });

  L.tileLayer(BASEMAP.tiles, { attribution: BASEMAP.attribution, maxZoom: MAP_VIEW.maxZoom }).addTo(map);

  const ro = new ResizeObserver(() => map.invalidateSize());
  ro.observe(container);
  const nudges = [0, 120, 400].map(t => setTimeout(() => map.invalidateSize(), t));

  return {
    map,
    getValue() {
      const c = map.getCenter();
      return { lat: Number(c.lat.toFixed(6)), lng: Number(c.lng.toFixed(6)) };
    },
    setValue(lat, lng, zoom = 19) { map.setView([lat, lng], zoom); },
    destroy() {
      ro.disconnect();
      for (const id of nudges) clearTimeout(id);
      map.remove();
    },
  };
}

/**
 * Warm the browser cache with the zoom levels either side of the current one.
 *
 * Leaflet only ever requests tiles for the zoom you are on, so the first moment
 * of a zoom is always a cold fetch and looks blank. Once the map has been still
 * for a moment, quietly pull the tiles one level in and one level out so the
 * next zoom is already in cache.
 *
 * Deliberately modest: it runs only when idle, skips if the user has Data Saver
 * on, never re-requests a tile it has already asked for, and is capped — this
 * is someone else's tile server, and someone else's mobile data.
 */
function prefetchNeighbouringZooms(map) {
  const template = BASEMAP.tiles;
  const asked = new Set();
  const MAX_PER_IDLE = 48;
  let timer = null;

  const saveData = () => navigator.connection?.saveData === true;

  const lngToX = (lng, z) => Math.floor(((lng + 180) / 360) * 2 ** z);
  const latToY = (lat, z) => {
    const r = (lat * Math.PI) / 180;
    return Math.floor(((1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2) * 2 ** z);
  };

  function tilesFor(bounds, z) {
    const max = 2 ** z;
    const clamp = n => Math.max(0, Math.min(max - 1, n));
    const x1 = clamp(lngToX(bounds.getWest(), z));
    const x2 = clamp(lngToX(bounds.getEast(), z));
    const y1 = clamp(latToY(bounds.getNorth(), z));
    const y2 = clamp(latToY(bounds.getSouth(), z));
    const out = [];
    for (let x = x1; x <= x2; x++) for (let y = y1; y <= y2; y++) out.push({ x, y, z });
    return out;
  }

  function warm() {
    if (saveData()) return;

    const z = map.getZoom();
    const bounds = map.getBounds();
    const wanted = [];

    // One level out is cheap — a quarter of the tiles cover the same ground.
    if (z - 1 >= map.getMinZoom()) wanted.push(...tilesFor(bounds, z - 1));

    // One level in is four times as many, so only warm the middle of the view:
    // that is where a zoom lands.
    if (z + 1 <= map.getMaxZoom()) wanted.push(...tilesFor(bounds.pad(-0.25), z + 1));

    let sent = 0;
    for (const t of wanted) {
      if (sent >= MAX_PER_IDLE) break;
      const url = template
        .replace('{z}', t.z).replace('{x}', t.x).replace('{y}', t.y)
        .replace('{s}', 'a').replace('{r}', '');
      if (asked.has(url)) continue;
      asked.add(url);
      sent++;
      const img = new Image();
      img.decoding = 'async';
      img.src = url;   // fetched into the HTTP cache, never added to the DOM
    }

    // Do not let the guard set grow without bound over a long session.
    if (asked.size > 3000) asked.clear();
  }

  const schedule = () => {
    clearTimeout(timer);
    timer = setTimeout(warm, 500);   // only once the map has actually settled
  };

  map.on('moveend zoomend', schedule);
  map.whenReady(schedule);
  map.on('unload', () => clearTimeout(timer));
}

const noop = () => {};
const stub = () => ({
  render: noop, setSelected: noop, setFocus: noop, highlightFeature: noop,
  flyTo: noop, fitTo: noop, reset: noop, resize: noop, destroy: noop,
});
