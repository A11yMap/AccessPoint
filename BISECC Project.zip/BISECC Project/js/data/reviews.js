// Reviews are stamped with the reviewer's own access needs.
// "Reviewed by a power wheelchair user" tells you far more than four stars does,
// and it lets the app float reviews from people like you to the top.
//
// Seeded empty on purpose — every review in the app is written by a real user.
// Anything added through the app lives in localStorage (see store.js).

export const REVIEWS = [];

/** Reviews from people who share at least one of your needs come first. */
export function sortReviewsForProfile(reviews, needIds) {
  const mine = new Set(needIds ?? []);
  return [...reviews].sort((a, b) => {
    const aShared = a.needs.filter(n => mine.has(n)).length;
    const bShared = b.needs.filter(n => mine.has(n)).length;
    if (aShared !== bShared) return bShared - aShared;
    return b.date.localeCompare(a.date);
  });
}
