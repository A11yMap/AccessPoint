// Categories and feature kinds.
//
// There is NO built-in list of places. Places come from searching the live
// OpenStreetMap database (see search.js), exactly as in a maps app — so every
// shop, temple, station and hospital in and around Bangkok is reachable without
// anyone hand-typing it here.
//
// Accessibility information is likewise empty until users add it. A venue record
// holds `attrs` (facts) and `features` (entrances, lifts, toilets — each with
// their own coordinates, so the app can point at the step-free door rather than
// at the middle of the building).
//
// attrs values are either 'value' (inherits the venue's `updated`/`source`) or
// ['value', 'YYYY-MM-DD', 'source'].  Sources: community | venue | audit | osm

export const CATEGORIES = {
  mall:       { label: 'Shopping mall', icon: '🛍' },
  market:     { label: 'Market',        icon: '🧺' },
  temple:     { label: 'Place of worship', icon: '🛕' },
  museum:     { label: 'Museum',        icon: '🏛' },
  park:       { label: 'Park',          icon: '🌳' },
  transport:  { label: 'Station',       icon: '🚉' },
  airport:    { label: 'Airport',       icon: '✈️' },
  pier:       { label: 'Pier',          icon: '⛴' },
  hospital:   { label: 'Hospital',      icon: '🏥' },
  university: { label: 'University',    icon: '🎓' },
  library:    { label: 'Library',       icon: '📚' },
  cinema:     { label: 'Cinema',        icon: '🎬' },
  convention: { label: 'Convention centre', icon: '🏢' },
  attraction: { label: 'Attraction',    icon: '🎡' },
  cafe:       { label: 'Café',          icon: '☕' },
  restaurant: { label: 'Restaurant',    icon: '🍽' },
  government: { label: 'Public office', icon: '🏛' },
  shop:       { label: 'Shop',          icon: '🏪' },
  school:     { label: 'School',        icon: '🏫' },
  pharmacy:   { label: 'Pharmacy',      icon: '💊' },
  bank:       { label: 'Bank',          icon: '🏦' },
  hotel:      { label: 'Hotel',         icon: '🏨' },
  sports:     { label: 'Sports centre', icon: '🏟' },
  place:      { label: 'Place',         icon: '📍' },
};

export const FEATURE_KINDS = {
  entrance: { label: 'Entrance',    icon: '🚪' },
  toilet:   { label: 'Toilet',      icon: '🚻' },
  lift:     { label: 'Lift',        icon: '🛗' },
  ramp:     { label: 'Ramp',        icon: '🛝' },
  parking:  { label: 'Parking',     icon: '🅿️' },
  seating:  { label: 'Seating',     icon: '🪑' },
  quiet:    { label: 'Quiet space', icon: '🤫' },
  counter:  { label: 'Counter',     icon: '🧾' },
  obstacle: { label: 'Obstacle',    icon: '⚠️' },
};

/** No seeded places: everything is found by search, or added by a user. */
export const VENUES = [];

/** Normalise the shorthand attr format into { value, verified, source }. */
export function readAttr(venue, attrId) {
  const raw = venue.attrs[attrId];
  if (raw === undefined) return null;
  return Array.isArray(raw)
    ? { value: raw[0], verified: raw[1], source: raw[2] }
    : { value: raw, verified: venue.updated, source: venue.source };
}
