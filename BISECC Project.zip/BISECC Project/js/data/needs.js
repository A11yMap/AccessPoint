// The access needs a person can have on their profile.
// Everything in the app is scored relative to whichever of these are switched on.
//
// Each need carries SYNONYMS so people can describe themselves in their own
// words — "can't do stairs", "guide dog", "ผู้ใช้รถเข็น", "autism" — instead of
// hunting through a list for the official term. Anything that matches nothing
// can still be saved as a free-text note on the profile (see store.customNeeds);
// those notes are shown on your reviews but cannot affect scoring, because the
// engine has no weights for them. The app says so rather than pretending.

export const NEEDS = [
  {
    id: 'wheelchair', label: 'Wheelchair user', short: 'Wheelchair', icon: '♿',
    synonyms: ['wheelchair', 'powerchair', 'power chair', 'electric chair', 'mobility scooter',
      'scooter', 'cannot walk', "can't walk", 'paraplegic', 'quadriplegic', 'tetraplegic',
      'spinal injury', 'รถเข็น', 'วีลแชร์', 'ผู้ใช้รถเข็น'],
  },
  {
    id: 'mobility', label: 'Limited mobility or fatigue', short: 'Mobility', icon: '🦯',
    synonyms: ['walking stick', 'cane', 'crutches', 'walker', 'walking frame', 'rollator',
      'cannot do stairs', "can't do stairs", 'stairs are hard', 'arthritis', 'chronic pain',
      'chronic fatigue', 'me/cfs', 'fibromyalgia', 'long covid', 'heart condition', 'copd',
      'breathless', 'elderly', 'old age', 'pregnant', 'amputee', 'prosthetic', 'limp',
      'เดินลำบาก', 'ไม้เท้า'],
  },
  {
    id: 'blind', label: 'Blind', short: 'Blind', icon: '🦮',
    synonyms: ['blind', 'no sight', 'no vision', 'guide dog', 'assistance dog', 'white cane',
      'braille', 'screen reader', 'ตาบอด', 'คนตาบอด'],
  },
  {
    id: 'lowvision', label: 'Low vision', short: 'Low vision', icon: '🔍',
    synonyms: ['low vision', 'partially sighted', 'visually impaired', 'poor eyesight',
      'bad eyesight', 'glaucoma', 'macular', 'cataract', 'tunnel vision', 'colour blind',
      'color blind', 'สายตาเลือนราง', 'สายตาไม่ดี'],
  },
  {
    id: 'deaf', label: 'Deaf', short: 'Deaf', icon: '🤟',
    synonyms: ['deaf', 'sign language', 'bsl', 'asl', 'thai sign language', 'signing',
      'profoundly deaf', 'หูหนวก', 'ภาษามือ'],
  },
  {
    id: 'hoh', label: 'Hard of hearing', short: 'Hard of hearing', icon: '👂',
    synonyms: ['hard of hearing', 'hearing loss', 'hearing aid', 'hearing aids', 'cochlear',
      'cochlear implant', 'partially deaf', 'tinnitus', 'hoh', 'หูตึง', 'เครื่องช่วยฟัง'],
  },
  {
    id: 'mute', label: 'Non-speaking', short: 'Non-speaking', icon: '💬',
    synonyms: ['non-speaking', 'nonspeaking', 'non verbal', 'nonverbal', 'mute', 'cannot speak',
      "can't speak", 'speech impairment', 'stammer', 'stutter', 'aphasia', 'selective mutism',
      'aac', 'laryngectomy', 'พูดไม่ได้', 'บกพร่องทางการพูด'],
  },
  {
    id: 'sensory', label: 'Autistic or sensory sensitivity', short: 'Sensory', icon: '🌊',
    synonyms: ['autistic', 'autism', 'asd', 'aspergers', 'neurodivergent', 'sensory',
      'sensory processing', 'overstimulation', 'overwhelmed by noise', 'noise sensitive',
      'light sensitive', 'migraine', 'ptsd', 'anxiety', 'panic', 'agoraphobia', 'adhd',
      'ออทิสติก', 'ไวต่อเสียง'],
  },
  {
    id: 'cognitive', label: 'Learning disability or cognitive', short: 'Cognitive', icon: '🧠',
    synonyms: ['learning disability', 'learning difficulty', 'intellectual disability',
      'down syndrome', 'dementia', 'alzheimers', 'memory', 'brain injury', 'dyslexia',
      'dyscalculia', 'confused by signs', 'easy read', 'บกพร่องทางการเรียนรู้', 'ความจำ'],
  },
];

export const NEED_BY_ID = Object.fromEntries(NEEDS.map(n => [n.id, n]));

export const needLabel = id => NEED_BY_ID[id]?.short ?? id;

/**
 * Find needs matching what someone typed, best first.
 * Matches the label, the short name and every synonym, in either direction, so
 * "chair" finds Wheelchair and "I use a walking stick" finds Limited mobility.
 */
export function matchNeeds(text) {
  const q = text.trim().toLowerCase();
  if (!q) return [];

  const scored = [];
  for (const need of NEEDS) {
    const haystacks = [need.label, need.short, ...need.synonyms].map(x => x.toLowerCase());
    let best = 0;
    for (const hay of haystacks) {
      if (hay === q) best = Math.max(best, 100);
      else if (hay.startsWith(q)) best = Math.max(best, 80);
      else if (hay.includes(q)) best = Math.max(best, 60);
      else if (q.includes(hay) && hay.length >= 4) best = Math.max(best, 50);
    }
    if (best) scored.push({ need, score: best });
  }
  return scored.sort((a, b) => b.score - a.score).map(s => s.need);
}
