// What a person needs, in useful detail.
//
// An earlier version had nine broad boxes — "limited mobility or fatigue" held
// a cane user, someone with chronic fatigue and someone who cannot stand in a
// queue, who need completely different things. These are specific instead.
//
// Each need maps to one or more SCORING DIMENSIONS (the nine profiles that
// js/data/attributes.js holds weights for), with a factor, plus BOOSTS that
// raise particular attributes for that need. So "photosensitive epilepsy" is
// mostly a lighting question, and "cannot stand for long" is mostly a seating
// question, even though both borrow a general profile underneath.
//
// Adding a need is data only: give it dimensions, boosts and the words people
// actually use for it.

export const NEED_GROUPS = [
  'Moving around', 'Seeing', 'Hearing', 'Speaking', 'Sensory & neurodivergent',
  'Thinking & memory', 'Health & stamina',
];

export const NEEDS = [
  // ---- Moving around ----
  {
    id: 'manual-wheelchair', label: 'Manual wheelchair', group: 'Moving around', icon: '♿',
    dimensions: { wheelchair: 1 },
    terms: ['manual wheelchair', 'wheelchair', 'self propel', 'chair user', 'รถเข็น', 'วีลแชร์'],
  },
  {
    id: 'powerchair', label: 'Powerchair or electric wheelchair', group: 'Moving around', icon: '🔋',
    dimensions: { wheelchair: 1 },
    boosts: { door_width: 3, lift: 3, aisle_width: 2 },
    terms: ['powerchair', 'power chair', 'electric wheelchair', 'motorised wheelchair', 'power wheelchair'],
    why: 'wider and heavier, so doorways and lift size matter more',
  },
  {
    id: 'mobility-scooter', label: 'Mobility scooter', group: 'Moving around', icon: '🛵',
    dimensions: { wheelchair: 0.9, mobility: 0.3 },
    boosts: { aisle_width: 3, accessible_parking: 2 },
    terms: ['mobility scooter', 'scooter', 'buggy'],
    why: 'long turning circle, so aisles and parking matter more',
  },
  {
    id: 'walking-aid', label: 'Walking stick, crutches or frame', group: 'Moving around', icon: '🦯',
    dimensions: { mobility: 1 },
    terms: ['walking stick', 'cane', 'crutches', 'crutch', 'walker', 'walking frame', 'rollator',
      'zimmer', 'ไม้เท้า', 'เดินลำบาก'],
  },
  {
    id: 'no-stairs', label: 'Cannot manage stairs', group: 'Moving around', icon: '🪜',
    dimensions: { mobility: 0.7, wheelchair: 0.5 },
    boosts: { step_free_entrance: 4, step_free_inside: 4, lift: 4 },
    terms: ['cannot do stairs', 'no stairs', 'stairs are hard', 'cant climb stairs', 'steps are hard',
      'knee', 'hip replacement', 'bad knees'],
  },
  {
    id: 'limited-standing', label: 'Cannot stand for long', group: 'Moving around', icon: '🪑',
    dimensions: { mobility: 0.6 },
    boosts: { seating: 5 },
    terms: ['cannot stand', 'cant stand for long', 'need to sit', 'need a seat', 'queueing is hard',
      'standing hurts', 'pots', 'dizzy standing'],
  },
  {
    id: 'limited-reach', label: 'Limited reach, grip or dexterity', group: 'Moving around', icon: '🤲',
    dimensions: { wheelchair: 0.3, mobility: 0.3 },
    boosts: { door_type: 4, ordering: 2, counter: 2 },
    terms: ['limited grip', 'weak grip', 'dexterity', 'cannot open heavy doors', 'arthritis in hands',
      'tremor', 'shaky hands', 'one handed', 'amputee arm'],
  },
  {
    id: 'assistance-dog', label: 'Assistance dog handler', group: 'Moving around', icon: '🦮',
    dimensions: { blind: 0.3 },
    boosts: { guide_dog: 6 },
    terms: ['assistance dog', 'service dog', 'guide dog', 'seeing eye dog', 'hearing dog', 'สุนัขนำทาง'],
  },

  // ---- Seeing ----
  {
    id: 'blind', label: 'Blind', group: 'Seeing', icon: '👁',
    dimensions: { blind: 1 },
    terms: ['blind', 'no sight', 'no vision', 'white cane', 'braille', 'screen reader',
      'totally blind', 'ตาบอด', 'คนตาบอด'],
  },
  {
    id: 'low-vision', label: 'Low vision', group: 'Seeing', icon: '🔍',
    dimensions: { lowvision: 1 },
    terms: ['low vision', 'partially sighted', 'visually impaired', 'poor eyesight', 'bad eyesight',
      'glaucoma', 'macular degeneration', 'cataract', 'tunnel vision', 'สายตาเลือนราง'],
  },
  {
    id: 'light-sensitive', label: 'Light sensitivity', group: 'Seeing', icon: '🔆',
    dimensions: { sensory: 0.5, lowvision: 0.3 },
    boosts: { lighting: 5 },
    terms: ['light sensitive', 'photophobia', 'bright lights hurt', 'glare', 'migraine from light'],
  },
  {
    id: 'colour-vision', label: 'Colour vision deficiency', group: 'Seeing', icon: '🎨',
    dimensions: { lowvision: 0.3 },
    boosts: { clear_signage: 4 },
    terms: ['colour blind', 'color blind', 'colour vision', 'deuteranopia', 'protanopia', 'ตาบอดสี'],
  },

  // ---- Hearing ----
  {
    id: 'deaf-signing', label: 'Deaf, uses sign language', group: 'Hearing', icon: '🤟',
    dimensions: { deaf: 1 },
    boosts: { deaf_comms: 3 },
    terms: ['deaf', 'sign language', 'bsl', 'asl', 'thai sign language', 'signing', 'หูหนวก', 'ภาษามือ'],
  },
  {
    id: 'hard-of-hearing', label: 'Hard of hearing', group: 'Hearing', icon: '👂',
    dimensions: { hoh: 1 },
    terms: ['hard of hearing', 'hearing loss', 'partially deaf', 'hoh', 'tinnitus', 'หูตึง'],
  },
  {
    id: 'hearing-aid', label: 'Hearing aid or cochlear implant', group: 'Hearing', icon: '🔊',
    dimensions: { hoh: 1 },
    boosts: { hearing_loop: 5, noise: 2 },
    terms: ['hearing aid', 'hearing aids', 'cochlear', 'cochlear implant', 'induction loop',
      'เครื่องช่วยฟัง'],
    why: 'a working induction loop changes everything',
  },
  {
    id: 'deafblind', label: 'Deafblind', group: 'Hearing', icon: '🫱',
    dimensions: { deaf: 0.9, blind: 0.9 },
    boosts: { staff_training: 4, tactile_paving: 2 },
    terms: ['deafblind', 'deaf blind', 'dual sensory loss', 'ushers syndrome'],
  },

  // ---- Speaking ----
  {
    id: 'non-speaking', label: 'Non-speaking', group: 'Speaking', icon: '💬',
    dimensions: { mute: 1 },
    terms: ['non speaking', 'nonverbal', 'non verbal', 'mute', 'cannot speak', 'selective mutism',
      'พูดไม่ได้'],
  },
  {
    id: 'speech-difficulty', label: 'Speech difficulty', group: 'Speaking', icon: '🗣',
    dimensions: { mute: 0.7 },
    boosts: { staff_training: 4 },
    terms: ['stammer', 'stutter', 'speech impairment', 'aphasia', 'dysarthria', 'hard to understand me',
      'laryngectomy', 'บกพร่องทางการพูด'],
  },
  {
    id: 'aac-user', label: 'Uses a communication device', group: 'Speaking', icon: '📱',
    dimensions: { mute: 1 },
    boosts: { ordering: 3, staff_training: 3 },
    terms: ['aac', 'communication device', 'communication board', 'text to speech', 'type to talk'],
  },

  // ---- Sensory & neurodivergent ----
  {
    id: 'autistic', label: 'Autistic', group: 'Sensory & neurodivergent', icon: '🌊',
    dimensions: { sensory: 1, cognitive: 0.4 },
    terms: ['autistic', 'autism', 'asd', 'aspergers', 'neurodivergent', 'ออทิสติก'],
  },
  {
    id: 'noise-sensitive', label: 'Noise sensitivity', group: 'Sensory & neurodivergent', icon: '🔇',
    dimensions: { sensory: 0.8 },
    boosts: { noise: 5, quiet_space: 3 },
    terms: ['noise sensitive', 'hyperacusis', 'misophonia', 'loud places are hard', 'ear defenders',
      'overwhelmed by noise', 'ไวต่อเสียง'],
  },
  {
    id: 'crowds', label: 'Crowds and queues are hard', group: 'Sensory & neurodivergent', icon: '👥',
    dimensions: { sensory: 0.7 },
    boosts: { quiet_space: 4, aisle_width: 2, seating: 2 },
    terms: ['crowds', 'agoraphobia', 'panic attacks', 'anxiety', 'ptsd', 'claustrophobia', 'busy places'],
  },
  {
    id: 'photosensitive-epilepsy', label: 'Photosensitive epilepsy', group: 'Sensory & neurodivergent', icon: '⚡',
    dimensions: { sensory: 0.4 },
    boosts: { lighting: 6 },
    terms: ['photosensitive epilepsy', 'epilepsy', 'seizures', 'flashing lights', 'strobe',
      'flicker', 'ลมชัก'],
    why: 'flickering and strobe lighting is the risk, not noise',
  },
  {
    id: 'adhd', label: 'ADHD', group: 'Sensory & neurodivergent', icon: '🌀',
    dimensions: { cognitive: 0.5, sensory: 0.5 },
    boosts: { clear_signage: 2 },
    terms: ['adhd', 'add', 'attention deficit', 'easily distracted'],
  },

  // ---- Thinking & memory ----
  {
    id: 'learning-disability', label: 'Learning disability', group: 'Thinking & memory', icon: '🧠',
    dimensions: { cognitive: 1 },
    terms: ['learning disability', 'intellectual disability', 'down syndrome', 'learning difficulty',
      'บกพร่องทางการเรียนรู้'],
  },
  {
    id: 'memory', label: 'Memory loss or dementia', group: 'Thinking & memory', icon: '🕰',
    dimensions: { cognitive: 0.9 },
    boosts: { clear_signage: 4, staff_training: 3 },
    terms: ['dementia', 'alzheimers', 'memory loss', 'brain injury', 'get lost easily', 'ความจำ'],
  },
  {
    id: 'dyslexia', label: 'Dyslexia or reading difficulty', group: 'Thinking & memory', icon: '📖',
    dimensions: { cognitive: 0.6 },
    boosts: { clear_signage: 5 },
    terms: ['dyslexia', 'dyslexic', 'reading is hard', 'cannot read signs', 'dyscalculia'],
  },
  {
    id: 'processing-time', label: 'Needs extra time to process', group: 'Thinking & memory', icon: '⏳',
    dimensions: { cognitive: 0.7 },
    boosts: { staff_training: 4, ordering: 3 },
    terms: ['processing time', 'need more time', 'slow processing', 'dont rush me', 'feel rushed'],
  },

  // ---- Health & stamina ----
  {
    id: 'limited-stamina', label: 'Limited stamina or chronic fatigue', group: 'Health & stamina', icon: '🔋',
    dimensions: { mobility: 0.9 },
    boosts: { seating: 4, accessible_parking: 2 },
    terms: ['chronic fatigue', 'me/cfs', 'fibromyalgia', 'long covid', 'tired easily', 'low energy',
      'chronic illness', 'chronic pain', 'lupus', 'ms', 'multiple sclerosis'],
  },
  {
    id: 'toilet-urgency', label: 'Needs a toilet quickly or often', group: 'Health & stamina', icon: '🚻',
    dimensions: { mobility: 0.2 },
    boosts: { accessible_toilet: 6, changing_places: 2 },
    terms: ['toilet urgency', 'ibd', 'crohns', 'colitis', 'ostomy', 'stoma', 'incontinence',
      'bladder', 'need toilets often', 'cant wait'],
  },
  {
    id: 'breathing', label: 'Breathing or heart condition', group: 'Health & stamina', icon: '🫁',
    dimensions: { mobility: 0.6 },
    boosts: { seating: 3, step_free_entrance: 2 },
    terms: ['asthma', 'copd', 'breathless', 'heart condition', 'angina', 'oxygen', 'lung'],
  },
];

export const NEED_BY_ID = Object.fromEntries(NEEDS.map(n => [n.id, n]));

// Defensive on purpose: a label lookup is decoration, and it should never be
// able to take a whole page down if something hands it the wrong shape.
export const needLabel = id => NEED_BY_ID[id]?.label ?? (typeof id === 'string' ? id : '');
export const needShort = id => needLabel(id).split(/[,(]/)[0].trim();

// ---- interpreting what someone typed --------------------------------------

const strip = s => s.toLowerCase()
  .normalize('NFKD').replace(/[̀-ͯ]/g, '')
  .replace(/['’]/g, '')
  .replace(/[^a-z0-9฀-๿\s]/g, ' ')
  .replace(/\s+/g, ' ')
  .trim();

const STOPWORDS = new Set(['i', 'im', 'ive', 'a', 'an', 'the', 'my', 'me', 'is', 'am', 'are', 'have',
  'has', 'with', 'and', 'or', 'of', 'to', 'in', 'on', 'for', 'use', 'uses', 'using', 'user', 'cant',
  'cannot', 'not', 'very', 'really', 'bit', 'quite', 'some', 'get', 'got', 'need', 'needs', 'it',
  'be', 'been', 'do', 'does', 'so', 'that', 'this', 'as', 'at', 'from', 'by', 'but']);

const tokens = s => strip(s).split(' ').filter(t => t && !STOPWORDS.has(t));

/** Edit distance, capped — enough to forgive a typo, not to invent a match. */
function within(a, b, max) {
  if (Math.abs(a.length - b.length) > max) return false;
  let prev = [...Array(b.length + 1).keys()];
  for (let i = 1; i <= a.length; i++) {
    const row = [i];
    for (let j = 1; j <= b.length; j++) {
      row[j] = Math.min(prev[j] + 1, row[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    }
    if (Math.min(...row) > max) return false;
    prev = row;
  }
  return prev[b.length] <= max;
}

/**
 * Work out which needs someone is describing.
 *
 * This is not a filter over labels. It reads a whole sentence, scores every
 * need on how much of its vocabulary is present, forgives typos, and returns
 * everything that fits — so "I'm deafblind and use a power chair" returns three
 * needs, and "fibromyalgia" returns limited stamina even though that word
 * appears in no label.
 */
export function interpret(text) {
  const raw = strip(text);
  if (!raw) return [];
  const words = tokens(text);
  if (!words.length) return [];

  const hits = [];

  for (const need of NEEDS) {
    const phrases = [need.label, ...(need.terms ?? [])].map(strip);
    let score = 0;
    let reason = null;

    for (const phrase of phrases) {
      if (!phrase) continue;

      if (raw === phrase) { score = Math.max(score, 120); reason = null; continue; }

      // The typed text contains a known phrase: "i use a walking stick daily".
      if (phrase.length >= 4 && raw.includes(phrase)) {
        const gain = 70 + Math.min(25, phrase.length);
        if (gain > score) { score = gain; reason = phrase === strip(need.label) ? null : phrase; }
        continue;
      }

      if (phrase.startsWith(raw) && raw.length >= 2) {
        if (60 > score) { score = 60; reason = phrase === strip(need.label) ? null : phrase; }
        continue;
      }

      // Word overlap, so "stick walking" works as well as "walking stick".
      const pw = phrase.split(' ').filter(t => !STOPWORDS.has(t));
      if (!pw.length) continue;
      // Short words carry no signal: "long" must not drag in "long covid".
      const shared = pw.filter(t => t.length >= 5 && words.includes(t));
      const coverage = shared.length / pw.length;
      if (shared.length && coverage >= 0.4) {
        const gain = 35 + 25 * coverage;
        if (gain > score) { score = gain; reason = phrase; }
        continue;
      }

      // Last resort: a typo. One edit for short words, two only for long ones,
      // otherwise "lights" starts matching "sight".
      const fuzzy = pw.some(t => t.length >= 5 && words.some(w =>
        w.length >= 5 && within(w, t, t.length >= 8 ? 2 : 1)));
      if (fuzzy && 30 > score) { score = 30; reason = phrase; }
    }

    if (score > 0) hits.push({ need, score, reason });
  }

  return hits
    .sort((a, b) => b.score - a.score)
    .map(h => ({ ...h.need, matchScore: h.score, matchedOn: h.reason }));
}

/** Kept for older call sites. */
export const matchNeeds = text => interpret(text);
