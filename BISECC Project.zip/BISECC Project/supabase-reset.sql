-- ============================================================================
-- RESET TEST DATA
--
-- Run in Supabase: SQL Editor → New query → paste → Run.
--
-- This deletes contributions — facts, features, reviews and added places that
-- people (probably you) recorded through the app.
--
-- It CANNOT touch the imported OpenStreetMap data, because that never lived in
-- the database: it is baked into js/data/seed.js in the app itself and reloads
-- from there every time. So testing freely is safe — invent whatever facts you
-- like, then run this and you are back to a clean import.
-- ============================================================================


-- ---------------------------------------------------------------- option 1
-- Wipe every contribution, keep accounts (you stay signed in). The usual one.

delete from public.contributions;


-- ---------------------------------------------------------------- option 2
-- Wipe only YOUR OWN contributions, leaving other testers' alone.
-- Uncomment to use.

-- delete from public.contributions where user_id = auth.uid();


-- ---------------------------------------------------------------- option 3
-- Full reset: contributions AND saved profiles. Accounts themselves survive,
-- so you can still sign in; you just get the onboarding again.
-- Uncomment to use.

-- delete from public.contributions;
-- delete from public.profiles;


-- ---------------------------------------------------------------- check
select 'contributions left' as what, count(*) from public.contributions
union all
select 'profiles left', count(*) from public.profiles;


-- ============================================================================
-- OPTIONAL: a one-click button instead of pasting SQL each time.
--
-- Creates reset_test_data(), callable from the SQL editor as
--     select public.reset_test_data();
--
-- Only signed-in users can run it, never anonymous visitors. It is still a
-- "delete everything" switch, so BEFORE this is ever public, run:
--     revoke execute on function public.reset_test_data() from authenticated;
-- ============================================================================

create or replace function public.reset_test_data()
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  removed integer;
begin
  delete from public.contributions;
  get diagnostics removed = row_count;
  return 'Deleted ' || removed || ' contributions. Imported places are in the app, not the database, so they are untouched.';
end;
$$;

revoke execute on function public.reset_test_data() from anon;
grant execute on function public.reset_test_data() to authenticated;
