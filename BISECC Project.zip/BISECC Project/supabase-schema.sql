-- Accessibility map — database setup.
--
-- Run this in your Supabase project:  SQL Editor → New query → paste → Run.
-- Then put the project URL and the anon key into SUPABASE in js/config.js.
--
-- Safe to run more than once: it drops and recreates the policies each time,
-- and never drops your tables or data.

-- ---------------------------------------------------------------- profiles
create table if not exists public.profiles (
  id            uuid primary key references auth.users on delete cascade,
  name          text,
  needs         jsonb not null default '[]'::jsonb,
  custom_needs  jsonb not null default '[]'::jsonb,
  updated_at    timestamptz not null default now()
);

alter table public.profiles enable row level security;

-- A profile is private: only its owner can read or write it.
drop policy if exists "own profile readable"  on public.profiles;
drop policy if exists "own profile writable"  on public.profiles;
drop policy if exists "own profile updatable" on public.profiles;

create policy "own profile readable"  on public.profiles for select using (auth.uid() = id);
create policy "own profile writable"  on public.profiles for insert with check (auth.uid() = id);
create policy "own profile updatable" on public.profiles for update using (auth.uid() = id);

-- ----------------------------------------------------------- contributions
-- Accessibility information is public by design: the whole point is that what
-- one person records helps the next person.
create table if not exists public.contributions (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references auth.users on delete cascade,
  place_id    text not null,          -- e.g. osm:W157656710
  kind        text not null check (kind in ('fact', 'feature', 'review', 'place')),
  payload     jsonb not null,
  place       jsonb,                  -- name/category/address/lat/lng of the place
  created_at  timestamptz not null default now()
);

create index if not exists contributions_place_idx on public.contributions (place_id);
create index if not exists contributions_user_idx  on public.contributions (user_id);

alter table public.contributions enable row level security;

-- Anyone may read; you may only write or delete your own.
drop policy if exists "contributions are public" on public.contributions;
drop policy if exists "insert own contributions" on public.contributions;
drop policy if exists "update own contributions" on public.contributions;
drop policy if exists "delete own contributions" on public.contributions;

create policy "contributions are public" on public.contributions for select using (true);
create policy "insert own contributions" on public.contributions for insert with check (auth.uid() = user_id);
create policy "update own contributions" on public.contributions for update using (auth.uid() = user_id);
create policy "delete own contributions" on public.contributions for delete using (auth.uid() = user_id);

-- ---------------------------------------------------------------- check it
-- After running, these should both return a row.
select 'profiles ready'      as status, count(*) from public.profiles;
select 'contributions ready' as status, count(*) from public.contributions;
