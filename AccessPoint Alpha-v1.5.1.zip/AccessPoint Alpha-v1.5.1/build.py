#!/usr/bin/env python3
"""Build the app into single .html files you can publish anywhere.

Inlines src/styles.css, src/app.js and src/places.js into one page, so the
result works from a web host, a static file server, or by double-clicking.
Leaflet, Supabase and the font still come from a CDN, and map tiles come from
Esri, so the page needs an internet connection — any map would.

    python3 build.py

Writes two files, from the same source:

    accessibility-map.html           places arrive with the OpenStreetMap data
    accessibility-map-no-data.html   the same places, nothing known about access
"""
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).parent
SRC = ROOT / 'src'


def read(name):
    path = SRC / name
    if not path.exists():
        sys.exit(f'ERROR: {path} is missing.')
    return path.read_text()


def bundle():
    """app.js and its one import, flattened into a single script."""
    places = read('places.js')
    app = read('app.js')

    # places.js is the only module app.js imports; inline it and drop the import.
    places = re.sub(r'^export\s+', '', places, flags=re.M)
    app = re.sub(r'^import\s+\{[^}]*\}\s+from\s+[\'"]\./places\.js[\'"];\s*$', '', app, flags=re.M)

    return f'{places}\n\n{app}'


def build(with_data, out):
    html = read('index.html')
    css = read('styles.css')

    head = re.search(r'<head>(.*)</head>', html, re.S).group(1)
    head = head.replace('<link rel="stylesheet" href="styles.css">', '')

    body = re.search(r'<body>(.*)</body>', html, re.S).group(1)
    body = re.sub(r'\s*<script type="module".*?</script>', '', body, flags=re.S)

    script = bundle()
    if not with_data:
        before = script
        script = script.replace('const USE_IMPORTED_DATA = true;',
                                'const USE_IMPORTED_DATA = false;')
        if script == before:
            sys.exit('ERROR: could not switch USE_IMPORTED_DATA off for the blank build.')

    page = (
        '<!doctype html>\n<html lang="en">\n<head>'
        + head.rstrip()
        + '\n  <style>\n' + css.strip() + '\n  </style>\n</head>\n<body>'
        + body.rstrip()
        + '\n\n<script type="module">\n' + script + '\n</script>\n</body>\n</html>\n'
    )
    out.write_text(page)

    label = 'with imported OSM data' if with_data else 'blank — no accessibility data'
    print(f'wrote {out.name:34} ({len(page):>8,} bytes)  {label}')


def main():
    build(with_data=True, out=ROOT / 'accessibility-map.html')
    build(with_data=False, out=ROOT / 'accessibility-map-no-data.html')


if __name__ == '__main__':
    main()
