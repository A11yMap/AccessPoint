#!/usr/bin/env python3
"""Import Bangkok's notable places, and whatever accessibility data OSM holds.

    python3 tools/import-osm.py            # writes src/places.js

NOTHING HERE IS INVENTED. Every fact comes from an OpenStreetMap tag, is marked
with source 'osm', and carries the date that tag was last edited — so a fact
mapped in 2019 shows as stale in the app rather than looking freshly checked.

Most places have no accessibility data at all. That is the true state of the
data, and the app is built to show it as unknown rather than guess.
"""

import json, math, re, sys, time, urllib.parse, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'src' / 'places.js'
# Overpass is free and often busy; 504s are routine, so try mirrors in turn.
ENDPOINTS = [
    'https://overpass-api.de/api/interpreter',
    'https://overpass.kumi.systems/api/interpreter',
    'https://overpass.private.coffee/api/interpreter',
]
BBOX = '13.55,100.30,14.10,100.95'          # Bangkok and the ring of provinces
TARGET = 120                                 # roughly the "top 100" plus headroom

# OSM tag -> (category, notability weight)
CATEGORIES = [
    ('aeroway', 'aerodrome',        'airport',    6),
    ('railway', 'station',          'transport',  4),
    ('public_transport', 'station', 'transport',  4),
    ('amenity', 'bus_station',      'transport',  3),
    ('amenity', 'ferry_terminal',   'pier',       3),
    ('shop', 'mall',                'mall',       4),
    ('shop', 'department_store',    'mall',       3),
    ('amenity', 'hospital',         'hospital',   4),
    ('amenity', 'university',       'university', 3),
    ('amenity', 'library',          'library',    3),
    ('amenity', 'cinema',           'cinema',     2),
    ('amenity', 'theatre',          'cinema',     2),
    ('amenity', 'marketplace',      'market',     3),
    ('amenity', 'place_of_worship', 'temple',     2),
    ('tourism', 'museum',           'museum',     4),
    ('tourism', 'gallery',          'museum',     2),
    ('tourism', 'attraction',       'attraction', 3),
    ('tourism', 'zoo',              'attraction', 3),
    ('tourism', 'theme_park',       'attraction', 3),
    ('leisure', 'park',             'park',       2),
]
CAT_BY_TAG = {(k, v): (cat, w) for k, v, cat, w in CATEGORIES}

# Every OSM key that tells us something about access. Used both to decide
# whether a place counts as "has any data" and to drive attrs_from().
A11Y_TAGS = (
    'wheelchair', 'wheelchair:description', 'wheelchair:description:en',
    'toilets:wheelchair', 'tactile_paving', 'tactile_writing',
    'automatic_door', 'door', 'entrance:width', 'door:width', 'width',
    'ramp', 'ramp:wheelchair', 'handrail', 'step_count', 'kerb',
    'elevator', 'highway',            # highway=elevator
    'hearing_loop', 'induction_loop', 'audio_loop',
    'braille', 'blind:description', 'deaf:description',
    'sign_language', 'sign_language:th', 'changing_table',
    'changing_table:adult', 'changing_table:location',
    'capacity:disabled', 'parking:disabled',
    'audio_description', 'subtitles', 'quiet_room',
)


def overpass(query, label, attempts=2):
    print(f'  querying {label}…', end=' ', flush=True)
    last = None
    for attempt in range(attempts):
        for endpoint in ENDPOINTS:
            url = endpoint + '?' + urllib.parse.urlencode({'data': query})
            req = urllib.request.Request(url, headers={'User-Agent': 'AccessMapPrototype/0.1'})
            try:
                with urllib.request.urlopen(req, timeout=240) as r:
                    data = json.load(r)
                print(f'{len(data["elements"])} elements')
                return data['elements']
            except Exception as err:
                last = err
                print('·', end='', flush=True)
                time.sleep(8)   # Overpass rate-limits per IP; give it room
    print(f'\n  ! {label} failed after trying every mirror: {last}')
    return []


def fetch_places():
    clauses = '\n  '.join(
        f'nwr["name"]["{k}"="{v}"]({BBOX});' for k, v, _, _ in CATEGORIES)
    return overpass(f'[out:json][timeout:240];\n(\n  {clauses}\n);\nout center tags meta;', 'places')


def fetch_features():
    """Accessibility that OSM records as its own node rather than on the venue.

    A mall's step-free door, its lift and its accessible toilet are usually
    separate nodes sitting inside the building outline, so a query that only
    looks at the venue itself finds none of them — which is most of why the
    first import came back so thin.
    """
    q = f'''[out:json][timeout:300];
(
  node["entrance"]["wheelchair"]({BBOX});
  node["entrance"]["automatic_door"]({BBOX});
  node["entrance"]["ramp"]({BBOX});
  node["highway"="elevator"]({BBOX});
  node["amenity"="toilets"]["wheelchair"]({BBOX});
  node["amenity"="toilets"]["changing_table:adult"]({BBOX});
  node["tactile_paving"="yes"]["railway"="platform"]({BBOX});
  node["amenity"="parking_space"]["parking_space"="disabled"]({BBOX});
);
out tags meta;'''
    return overpass(q, 'entrances, lifts, toilets and bays')


def centre(el):
    if 'center' in el:
        return el['center']['lat'], el['center']['lon']
    if 'lat' in el:
        return el['lat'], el['lon']
    return None


def category_of(tags):
    for key, value in tags.items():
        hit = CAT_BY_TAG.get((key, value))
        if hit:
            return hit
    return None


def station_name(tags, category):
    """OSM calls the BTS stop at Siam just "Siam". Say what it is."""
    name = tags.get('name:en') or tags.get('name') or ''
    if category != 'transport':
        return name
    if re.search(r'station|สถานี|airport|terminal|pier', name, re.I):
        return name
    network = tags.get('network:short') or tags.get('network') or ''
    network = re.sub(r'\s*\(.*\)', '', network).strip()
    if network and len(network) <= 12 and network.lower() not in name.lower():
        return f'{name} {network} Station'
    return f'{name} Station'


def notability(tags, weight, has_a11y):
    """A rough stand-in for how well known a place is.

    OSM has no popularity field, so this leans on the traces that being notable
    leaves behind: a Wikidata item, a Wikipedia article, an English name for
    visitors, a brand or operator. Crude, but it reliably sorts ICONSIAM above
    an unnamed shophouse.
    """
    score = weight
    if 'wikidata' in tags: score += 4
    if 'wikipedia' in tags: score += 3
    if 'name:en' in tags: score += 1
    if 'brand' in tags or 'operator' in tags: score += 1
    if 'website' in tags or 'contact:website' in tags: score += 1
    if 'opening_hours' in tags: score += 1
    if has_a11y: score += 2          # data-rich places are worth showing first
    return score


def day(el):
    """The date the tag was last edited — the honest 'last verified'."""
    ts = el.get('timestamp')
    return ts[:10] if ts else None


YES = ('yes', 'designated', 'only', 'limited')


def truthy(v):
    return v in ('yes', 'designated', 'only')


def attrs_from(tags, when):
    """Map OSM tags onto the app's attributes.

    Conservative on purpose: a tag is only translated where the OSM meaning and
    ours genuinely line up. Where OSM is vague ("wheelchair=limited" can mean
    almost anything) we record the weaker claim rather than the flattering one.
    """
    out = {}

    def put(attr, value):
        out.setdefault(attr, [value, when, 'osm'])

    # ---- getting in ----
    wc = tags.get('wheelchair')
    if wc == 'yes':
        put('step_free_entrance', 'yes')
        put('step_free_inside', 'yes')
    elif wc == 'no':
        put('step_free_entrance', 'no')
    elif wc == 'limited':
        put('step_free_inside', 'partial')

    # A ramp contradicts a bare "no": there are steps, but a way around them.
    if truthy(tags.get('ramp:wheelchair')) or truthy(tags.get('ramp')):
        out['step_free_entrance'] = ['alt', when, 'osm']

    steps = tags.get('step_count')
    if steps and steps.isdigit():
        if int(steps) == 0:
            put('step_free_entrance', 'yes')
        elif not truthy(tags.get('ramp:wheelchair')):
            put('step_free_entrance', 'no')

    auto = tags.get('automatic_door')
    if auto in ('yes', 'motion', 'button', 'serviced', 'slowdown'):
        put('door_type', 'auto')
    elif auto == 'no':
        door = tags.get('door')
        put('door_type', 'heavy' if door in ('hinged', 'revolving') else 'light')
    elif tags.get('door') == 'sliding':
        put('door_type', 'auto')
    elif tags.get('door') == 'revolving':
        put('door_type', 'heavy')

    # Widths are metres in OSM, centimetres in the app's thresholds.
    for key in ('door:width', 'entrance:width', 'width'):
        raw = tags.get(key)
        if not raw:
            continue
        try:
            cm = float(str(raw).replace('m', '').strip()) * 100
        except ValueError:
            continue
        if cm >= 90:
            put('door_width', 'wide')
        elif cm >= 75:
            put('door_width', 'standard')
        else:
            put('door_width', 'narrow')
        break

    tp = tags.get('tactile_paving')
    if tp in ('yes', 'no'):
        put('tactile_paving', tp)

    kerb = tags.get('kerb')
    if kerb in ('lowered', 'flush'):
        put('dropped_kerb', 'yes')
    elif kerb == 'raised':
        put('dropped_kerb', 'no')

    # ---- moving around ----
    if truthy(tags.get('elevator')) or tags.get('highway') == 'elevator':
        put('lift', 'accessible')

    # ---- toilets ----
    toilet = tags.get('toilets:wheelchair')
    if toilet == 'yes':
        put('accessible_toilet', 'full')
    elif toilet == 'no':
        put('accessible_toilet', 'none')
    elif toilet == 'limited':
        put('accessible_toilet', 'basic')

    # An adult changing bench is what "Changing Places" means; a baby table is not.
    if truthy(tags.get('changing_table:adult')):
        put('changing_places', 'yes')

    # ---- hearing ----
    if any(truthy(tags.get(k)) for k in ('hearing_loop', 'induction_loop', 'audio_loop')):
        put('hearing_loop', 'yes')
    elif 'hearing_loop' in tags and tags['hearing_loop'] == 'no':
        put('hearing_loop', 'no')

    if truthy(tags.get('sign_language')) or tags.get('sign_language:th'):
        put('deaf_comms', 'bsl')

    if truthy(tags.get('subtitles')):
        put('captions', 'yes')

    # ---- sight ----
    if truthy(tags.get('braille')) or truthy(tags.get('tactile_writing')):
        put('braille_signage', 'yes')

    if truthy(tags.get('audio_description')):
        put('audio_description', 'yes')

    # ---- other ----
    if truthy(tags.get('quiet_room')):
        put('quiet_space', 'yes')

    disabled_bays = tags.get('capacity:disabled')
    if disabled_bays and disabled_bays not in ('no', '0'):
        put('accessible_parking', 'onsite')
    elif disabled_bays in ('no', '0'):
        put('accessible_parking', 'none')

    return out


def feature_kind(tags):
    """What sort of thing this node is, in the app's vocabulary."""
    if tags.get('highway') == 'elevator':
        return 'lift', 'Lift'
    if tags.get('amenity') == 'toilets':
        return 'toilet', 'Accessible toilet'
    if tags.get('parking_space') == 'disabled':
        return 'parking', 'Blue badge bay'
    if tags.get('railway') == 'platform':
        return 'entrance', 'Platform'
    return 'entrance', 'Entrance'


def metres(a, b):
    (lat1, lng1), (lat2, lng2) = a, b
    dx = (lng2 - lng1) * 111320 * math.cos(math.radians((lat1 + lat2) / 2))
    dy = (lat2 - lat1) * 111320
    return math.hypot(dx, dy)


def main():
    print('Importing from OpenStreetMap…')
    raw = fetch_places()

    places = []
    for el in raw:
        tags = el.get('tags', {})
        pos = centre(el)
        hit = category_of(tags)
        if not pos or not hit:
            continue
        cat, weight = hit
        has_a11y = any(t in tags for t in A11Y_TAGS)
        places.append({
            'id': f'osm:{el["type"][0].upper()}{el["id"]}',
            'name': station_name(tags, hit[0]),
            'category': cat,
            'address': ', '.join(filter(None, [
                tags.get('addr:street'), tags.get('addr:suburb'), tags.get('addr:city'),
            ])) or 'Bangkok',
            'lat': round(pos[0], 6), 'lng': round(pos[1], 6),
            'attrs': attrs_from(tags, day(el)),
            'note': tags.get('wheelchair:description:en') or tags.get('wheelchair:description'),
            'score': notability(tags, weight, has_a11y),
        })

    # Deduplicate: OSM often holds a place as both a node and a building way.
    best = {}
    for p in places:
        key = (p['name'] or '').lower() + f'@{p["lat"]:.3f},{p["lng"]:.3f}'
        if key not in best or p['score'] > best[key]['score'] or len(p['attrs']) > len(best[key]['attrs']):
            best[key] = p

    # Rail stations are by far the best-tagged things in OSM, so a pure ranking
    # returns a list of BTS stops. Cap each category so the result looks like a
    # list of Bangkok's notable places rather than a transit timetable.
    CAPS = {'transport': 28, 'mall': 20, 'temple': 12, 'museum': 12, 'hospital': 10,
            'attraction': 12, 'university': 8, 'park': 8, 'market': 8, 'library': 6,
            'cinema': 5, 'airport': 4, 'pier': 6}
    chosen, used = [], {}
    for p in sorted(best.values(), key=lambda p: -p['score']):
        cat = p['category']
        if used.get(cat, 0) >= CAPS.get(cat, 6):
            continue
        used[cat] = used.get(cat, 0) + 1
        chosen.append(p)
        if len(chosen) >= TARGET:
            break
    places = chosen
    if not places:
        sys.exit('No places came back — Overpass is rate-limiting or down. '
                 'Wait a few minutes and run this again; src/places.js is untouched.')
    print(f'  selected {len(places)} places '
          f'({sum(1 for p in places if p["attrs"])} with accessibility data)')

    # Attach mapped entrances and lifts to whichever selected place they sit in.
    feats = fetch_features()
    attached = 0
    for el in feats:
        pos = centre(el)
        if not pos:
            continue
        tags = el.get('tags', {})
        near = min(places, key=lambda p: metres(pos, (p['lat'], p['lng'])))
        if metres(pos, (near['lat'], near['lng'])) > 80:
            continue
        kind, label = feature_kind(tags)
        bits = []
        if tags.get('entrance') in ('main', 'yes'): bits.append('Main entrance')
        wc = tags.get('wheelchair')
        if wc == 'yes': bits.append('marked step-free in OpenStreetMap')
        elif wc == 'no': bits.append('marked as NOT step-free in OpenStreetMap')
        elif wc == 'limited': bits.append('marked partly accessible in OpenStreetMap')
        if truthy(tags.get('automatic_door')): bits.append('automatic door')
        if truthy(tags.get('ramp:wheelchair')) or truthy(tags.get('ramp')): bits.append('ramp')
        if truthy(tags.get('changing_table:adult')): bits.append('adult changing bench')
        if truthy(tags.get('tactile_paving')): bits.append('tactile paving')
        if tags.get('door'): bits.append(f'{tags["door"]} door')
        if tags.get('width'): bits.append(f'width {tags["width"]}m')
        if tags.get('step_count'): bits.append(f'{tags["step_count"]} steps')

        near.setdefault('features', []).append({
            'kind': kind,
            'name': tags.get('name') or label,
            'detail': '. '.join(bits) or 'Mapped in OpenStreetMap; no details recorded.',
            'lat': round(pos[0], 6), 'lng': round(pos[1], 6),
            'added': day(el), 'source': 'osm',
        })

        # A located feature also tells us something about the venue as a whole.
        for attr, value in attrs_from(tags, day(el)).items():
            if attr in ('lift', 'accessible_toilet', 'changing_places', 'tactile_paving',
                        'accessible_parking') and attr not in near['attrs']:
                near['attrs'][attr] = value

        attached += 1
    print(f'  attached {attached} entrances/lifts')

    body = []
    for p in places:
        entry = {
            'id': p['id'], 'name': p['name'], 'category': p['category'],
            'address': p['address'], 'lat': p['lat'], 'lng': p['lng'],
            'attrs': p['attrs'], 'features': p.get('features', []),
            'rank': p['score'],
            'source': 'osm',
        }
        if p['note']:
            entry['note'] = re.sub(r'\s+', ' ', p['note']).strip()[:280]
        body.append(entry)

    OUT.write_text(
        '// GENERATED by tools/import-osm.py — do not edit by hand.\n'
        '//\n'
        '// The most notable places in and around Bangkok, with whatever accessibility\n'
        '// data OpenStreetMap actually holds for them. Nothing here is invented: every\n'
        "// fact is an OSM tag, marked source 'osm', dated to when that tag was last\n"
        '// edited. Most places have no data at all — that is the real state of it, and\n'
        '// the app shows those as unknown rather than guessing.\n'
        '//\n'
        f'// {len(body)} places, {sum(1 for p in body if p["attrs"])} of them with any accessibility fact.\n\n'
        'export const SEED_PLACES = '
        + json.dumps(body, ensure_ascii=False, indent=2) + ';\n')
    print(f'wrote {OUT.relative_to(ROOT)}  ({len(body)} places)')


if __name__ == '__main__':
    main()
